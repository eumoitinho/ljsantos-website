import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Droplets, Recycle, Shield, BarChart, Settings } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function EnglishTreatmentStations() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-[#435a52] mb-6">Effluent Treatment Stations</h1>
              <p className="text-lg text-gray-700 mb-8">
                Complete and efficient solutions for industrial effluent treatment, ensuring environmental compliance
                and resource savings.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/en/solicite-orcamento"
                  className="request-button inline-block rounded-xl hover:shadow-lg transition-all duration-300"
                >
                  Request a quote
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">High-Efficiency Effluent Treatment</h2>
                <p className="text-gray-700 mb-4">
                  LJ Santos develops Effluent Treatment Stations (ETSs) with high technology and efficiency, designed to
                  meet the specific needs of each client and ensure compliance with current environmental standards.
                </p>
                <p className="text-gray-700 mb-4">
                  We offer two main treatment systems: the Batch system and the Continuous system. Each has specific
                  characteristics that make them more suitable for different applications and effluent volumes.
                </p>
                <p className="text-gray-700">
                  Our solutions are developed with a focus on sustainability, operational efficiency, and ease of
                  maintenance, ensuring the best cost-benefit for our customers.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/estacao-tratamento-hero.jpg"
                  alt="LJ Santos Effluent Treatment Stations"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Systems Comparison */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Discover Our Systems
            </h2>
          </ScrollAnimation>

          <Tabs defaultValue="batelada" className="w-full">
            <ScrollAnimation animation="animate-zoomIn">
              <TabsList className="grid w-full grid-cols-2 mb-8 bg-white shadow-lg rounded-xl overflow-hidden">
                <TabsTrigger
                  value="batelada"
                  className="text-lg py-4 data-[state=active]:bg-[#435a52] data-[state=active]:text-white transition-all duration-300"
                >
                  Batch System
                </TabsTrigger>
                <TabsTrigger
                  value="continuo"
                  className="text-lg py-4 data-[state=active]:bg-[#435a52] data-[state=active]:text-white transition-all duration-300"
                >
                  Continuous System
                </TabsTrigger>
              </TabsList>
            </ScrollAnimation>

            {/* Batelada Content */}
            <TabsContent value="batelada" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <ScrollAnimation animation="animate-fadeInRight">
                  <div>
                    <Image
                      src="/images/estacao-batelada-1.jpeg"
                      alt="Batch Treatment Station"
                      width={600}
                      height={400}
                      className="rounded-2xl shadow-lg"
                    />
                  </div>
                </ScrollAnimation>
                <ScrollAnimation animation="animate-fadeInLeft">
                  <div>
                    <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Batch System</h3>
                    <p className="text-gray-700 mb-6">
                      The Batch treatment system operates in complete cycles, treating specific batches of effluents.
                      This method allows precise control of each stage of the process, from equalization to final
                      clarification.
                    </p>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Process Stages</h4>
                    <ul className="space-y-3 mb-6">
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">1</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Equalization:</strong> Homogenization of effluents to ensure uniformity.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">2</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Reaction:</strong> Controlled addition of chemical reagents for treatment.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">3</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Flocculation:</strong> Formation of flocs for contaminant separation.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">4</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Clarification:</strong> Separation of treated water from formed sludge.
                        </span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Ideal for:</h4>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Smaller volumes of effluents</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Effluents with high variability of characteristics</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Processes that require rigorous control of each batch</span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Image Gallery</h4>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <Image
                        src="/images/estacao-batelada-2.jpeg"
                        alt="Batch Station - Detail 1"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-batelada-3.jpeg"
                        alt="Batch Station - Detail 2"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-batelada-4.png"
                        alt="Batch Station - Detail 3"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-batelada-5.jpeg"
                        alt="Batch Station - Detail 4"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                    </div>
                  </div>
                </ScrollAnimation>
              </div>
            </TabsContent>

            {/* Contínuo Content */}
            <TabsContent value="continuo" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <ScrollAnimation animation="animate-fadeInRight">
                  <div>
                    <Image
                      src="/images/estacao-continua-1.jpeg"
                      alt="Continuous Treatment Station"
                      width={600}
                      height={400}
                      className="rounded-2xl shadow-lg"
                    />
                  </div>
                </ScrollAnimation>
                <ScrollAnimation animation="animate-fadeInLeft">
                  <div>
                    <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Continuous System</h3>
                    <p className="text-gray-700 mb-6">
                      The Continuous treatment system operates uninterruptedly, receiving and treating effluents
                      constantly. This method is ideal for industrial processes that generate effluents continuously and
                      in large volumes.
                    </p>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Process Stages</h4>
                    <ul className="space-y-3 mb-6">
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">1</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Continuous reception:</strong> Constant input of effluents into the system.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">2</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Physicochemical treatment:</strong> Automatic addition of reagents.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">3</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Decantation:</strong> Continuous separation of solids and liquids.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">4</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Disposal/reuse:</strong> Constant output of treated water.
                        </span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Ideal for:</h4>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Large volumes of effluents</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Continuous industrial processes</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Effluents with more constant characteristics</span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Image Gallery</h4>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <Image
                        src="/images/estacao-continua-2.png"
                        alt="Continuous Station - Detail 1"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-continua-3.png"
                        alt="Continuous Station - Detail 2"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-continua-4.png"
                        alt="Continuous Station - Detail 3"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-continua-5.png"
                        alt="Continuous Station - Detail 4"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                    </div>
                  </div>
                </ScrollAnimation>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              System Comparison
            </h2>
          </ScrollAnimation>

          <ScrollAnimation animation="animate-zoomIn">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse serious-table rounded-xl overflow-hidden shadow-lg">
                <thead>
                  <tr>
                    <th className="text-left bg-[#435a52] text-white">Characteristics</th>
                    <th className="text-center bg-[#435a52] text-white">Batch System</th>
                    <th className="text-center bg-[#435a52] text-white">Continuous System</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="font-medium">Effluent Volume</td>
                    <td className="text-center">Small to medium</td>
                    <td className="text-center">Medium to large</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Operation</td>
                    <td className="text-center">By cycles</td>
                    <td className="text-center">Uninterrupted</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Flexibility</td>
                    <td className="text-center">High</td>
                    <td className="text-center">Medium</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Process Control</td>
                    <td className="text-center">Precise by batch</td>
                    <td className="text-center">Constant</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Required Space</td>
                    <td className="text-center">Smaller</td>
                    <td className="text-center">Larger</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Energy Consumption</td>
                    <td className="text-center">Intermittent</td>
                    <td className="text-center">Constant</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Maintenance</td>
                    <td className="text-center">Simpler</td>
                    <td className="text-center">More complex</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Common Benefits
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Droplets className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Water Savings</h3>
                <p className="text-gray-700">
                  Possibility of reusing treated water, reducing water resource consumption and operational costs.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Shield className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Legal Compliance</h3>
                <p className="text-gray-700">
                  Guarantee of compliance with current environmental legislation, avoiding fines and penalties.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Recycle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Sustainability</h3>
                <p className="text-gray-700">
                  Contribution to environmental preservation and to the company's sustainable image.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Settings className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Advanced Automation</h3>
                <p className="text-gray-700">
                  Automated systems that ensure precision, repeatability, and less need for manual intervention.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <BarChart className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">High Efficiency</h3>
                <p className="text-gray-700">
                  High efficiency in contaminant removal, ensuring compliance with discharge standards.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <CheckCircle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Customization</h3>
                <p className="text-gray-700">
                  Custom projects according to the specific needs of each client and type of effluent.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Which system is ideal for your company?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Contact us for a personalized assessment and discover which effluent treatment system is most suitable for
              your company's needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/en/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Request a quote
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      <Footer />
    </main>
  )
}
