import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Shield, Settings, BarChart, Zap, Recycle } from "lucide-react"

export default function EnglishChromePlating() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-[#435a52] mb-6">Chrome Plating Lines</h1>
              <p className="text-lg text-gray-700 mb-8">
                Complete solutions for industrial chrome plating processes with high efficiency and superior quality.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/en/solicite-orcamento"
                  className="request-button inline-block rounded-xl hover:shadow-lg transition-all duration-300"
                >
                  Request a quote
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">High-Performance Chrome Plating</h2>
                <p className="text-gray-700 mb-4">
                  LJ Santos develops complete chrome plating lines, designed to meet the specific needs of each client,
                  ensuring high-quality finishes and exceptional durability.
                </p>
                <p className="text-gray-700 mb-4">
                  Our chrome plating lines are equipped with advanced technology to ensure efficient, safe, and
                  environmentally responsible processes, meeting all industry standards and regulations.
                </p>
                <p className="text-gray-700 mb-4">
                  We offer complete solutions that include everything from the initial design to installation and
                  maintenance, ensuring the best performance and longevity of the equipment.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/cromagem-4.webp"
                  alt="LJ Santos Chrome Plating Line"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Features and Benefits
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <BarChart className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">High Productivity</h3>
                <p className="text-gray-700">
                  Systems designed to maximize operational efficiency and increase the productivity of your production
                  line.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <CheckCircle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Superior Quality</h3>
                <p className="text-gray-700">
                  High-quality finishes with exceptional uniformity and brilliance, ensuring excellent final products.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Recycle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Sustainability</h3>
                <p className="text-gray-700">
                  Optimized processes to reduce water and energy consumption, minimizing environmental impact.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Settings className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Automation</h3>
                <p className="text-gray-700">
                  Advanced automation systems that increase process precision and reduce operational costs.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Shield className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Safety</h3>
                <p className="text-gray-700">
                  Equipment designed with the highest safety standards, protecting both operators and the environment.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Zap className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Energy Efficiency</h3>
                <p className="text-gray-700">
                  Systems optimized for lower energy consumption, reducing operational costs and environmental impact.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">Technical Specifications</h2>
                <p className="text-gray-700 mb-6">
                  Our chrome plating lines are designed with high-quality components and advanced technology to ensure
                  optimal performance and durability.
                </p>

                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Tanks in high chemical resistance polypropylene</strong>
                      <p className="text-gray-700">
                        Manufactured with materials that ensure durability and resistance to chemical agents used in the
                        chrome plating process.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Efficient heating and cooling systems</strong>
                      <p className="text-gray-700">
                        Temperature control systems that ensure process stability and energy efficiency.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">High-frequency rectifiers with digital control</strong>
                      <p className="text-gray-700">
                        Advanced power systems that provide precise control of the electroplating process.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Continuous filtration systems</strong>
                      <p className="text-gray-700">
                        Ensures greater durability of the baths and consistent quality of the chrome plating.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Complete automation with intuitive interface</strong>
                      <p className="text-gray-700">
                        User-friendly control systems that simplify operation and monitoring of the process.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Exhaust and vapor treatment systems</strong>
                      <p className="text-gray-700">
                        Environmental protection systems that ensure compliance with environmental regulations.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/cromagem-5.webp"
                  alt="Chrome Plating Line Technical Details"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg mb-6"
                />
                <Image
                  src="/images/cromagem-6.webp"
                  alt="Chrome Plating Line Components"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Chrome Plating Process
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Process Steps</h3>
                <p className="text-gray-700 mb-6">
                  The chrome plating process carried out in our lines follows a rigorous flow of steps to ensure
                  high-quality finishes and exceptional durability.
                </p>

                <ol className="space-y-4">
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">1</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Surface Preparation</strong>
                      <p className="text-gray-700">
                        Cleaning and initial treatment of parts to remove impurities, oils, and oxidation that could
                        compromise the quality of the finish.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">2</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Nickel Bath</strong>
                      <p className="text-gray-700">
                        Application of a nickel layer that serves as a base for the chrome, improving adhesion and
                        providing greater corrosion resistance.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">3</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Chrome Plating</strong>
                      <p className="text-gray-700">
                        Electrodeposition of chrome over the nickel layer, carried out in special tanks with precise
                        control of temperature, electric current, and immersion time.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">4</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Washing and Neutralization</strong>
                      <p className="text-gray-700">
                        Removal of chemical residues from parts through washing and neutralization, ensuring the safety
                        of the final product.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">5</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Drying and Final Inspection</strong>
                      <p className="text-gray-700">
                        Controlled drying of parts and rigorous inspection to ensure the quality of the finish, shine,
                        and uniformity of the chrome layer.
                      </p>
                    </div>
                  </li>
                </ol>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="grid grid-cols-1 gap-6">
                <Image
                  src="/images/cromagem-12.webp"
                  alt="Chrome Plating Process in Action"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg mb-6"
                />
                <Image
                  src="/images/cromagem-17.webp"
                  alt="Parts Transport System"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="grid grid-cols-2 gap-4">
                <Image
                  src="/images/cromagem-14.webp"
                  alt="Chrome Plated Parts"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/cromagem-15.webp"
                  alt="Chrome Plating Process Detail"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/cromagem-13.webp"
                  alt="Before and After Chrome Plating"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/cromagem-1.webp"
                  alt="Final Chrome Plated Product"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Quality Control</h3>
                <p className="text-gray-700 mb-6">
                  Our chrome plating process undergoes rigorous quality controls at all stages, ensuring exceptional and
                  consistent results.
                </p>

                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Adhesion Tests</strong>
                      <p className="text-gray-700">
                        Verification of the quality of chrome adhesion to the substrate, ensuring durability and
                        resistance.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Visual Inspection</strong>
                      <p className="text-gray-700">
                        Detailed analysis of the finish to identify imperfections, stains, or irregularities.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Thickness Tests</strong>
                      <p className="text-gray-700">
                        Precise measurement of the chrome layer thickness to ensure compliance with specifications.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Corrosion Tests</strong>
                      <p className="text-gray-700">
                        Evaluation of corrosion resistance through salt spray chamber tests.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Environmental Control</strong>
                      <p className="text-gray-700">
                        Constant monitoring of the process environmental parameters, including proper treatment of
                        effluents and emissions.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Applications</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Automotive Industry</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Chrome plating of automotive parts and accessories</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Decorative finishes for interior and exterior components</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Functional chrome plating for wear resistance</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Furniture and Decoration</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Chrome plating of furniture components</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Decorative elements for interior design</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Bathroom and kitchen fixtures</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Industrial Equipment</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Hard chrome plating for industrial components</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Wear and corrosion resistance for machinery parts</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Surface treatment for hydraulic components</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Electronics</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Chrome plating of electronic components</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Conductive surfaces for electronic applications</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Protective coatings for electronic devices</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Environmental Systems */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Environmental Treatment Systems
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <Image
                  src="/images/cromagem-11.webp"
                  alt="Emissions Treatment System"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Commitment to Sustainability</h3>
                <p className="text-gray-700 mb-6">
                  Our chrome plating lines are equipped with advanced effluent and emission treatment systems, ensuring
                  compliance with the most stringent environmental standards and minimizing environmental impact.
                </p>

                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Gas Scrubbers</strong>
                      <p className="text-gray-700">
                        High-efficiency systems for capturing and neutralizing vapors and gases generated during the
                        chrome plating process, preventing the release of pollutants into the atmosphere.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Effluent Treatment Station</strong>
                      <p className="text-gray-700">
                        Complete treatment of liquid effluents generated in the process, including neutralization, metal
                        precipitation, and filtration, allowing water reuse or safe disposal.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Metal Recovery</strong>
                      <p className="text-gray-700">
                        Systems for recovering metals present in effluents, reducing raw material consumption and
                        minimizing waste generation.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Continuous Monitoring</strong>
                      <p className="text-gray-700">
                        Automated monitoring systems to ensure the efficiency of treatment processes and compliance with
                        established environmental parameters.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Gallery</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <Image
                src="/images/cromagem-2.webp"
                alt="Chrome Plating Line - Structure"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <Image
                src="/images/cromagem-3.webp"
                alt="Chrome Plating Line - Overview"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <Image
                src="/images/cromagem-7.webp"
                alt="Chrome Plating Line - Tanks"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <Image
                src="/images/cromagem-14.webp"
                alt="Chrome Plated Parts - Final Result"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <Image
                src="/images/cromagem-15.webp"
                alt="Parts in Chrome Plating Process"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <Image
                src="/images/cromagem-1.webp"
                alt="Finished Chrome Plated Product"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <Image
                src="/images/cromagem-12.webp"
                alt="Chrome Plating Process in Action"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <Image
                src="/images/cromagem-13.webp"
                alt="Before and After Chrome Plating"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <Image
                src="/images/cromagem-16.webp"
                alt="Chrome Plating Line Corridor View"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Interested in our chrome plating solutions?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Contact us for more information and a customized quote for your specific needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/en/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Request a quote
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      <Footer />
    </main>
  )
}
