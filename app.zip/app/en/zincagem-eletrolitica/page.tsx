import Image from "next/image"
import { ScrollAnimation } from "@/components/scroll-animation"

export default function ElectrolyticZincPlating() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      {/* Hero Section */}
      <section className="w-full bg-gradient-to-r from-gray-900 to-gray-800 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold text-white sm:text-5xl md:text-6xl">Electrolytic Zinc Plating</h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-300 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              High-quality anticorrosive protection for metal components
            </p>
          </div>
        </div>
      </section>

      {/* Overview */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div>
              <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
                High-Performance Electrolytic Zinc Plating
              </h2>
              <p className="mt-4 text-lg text-gray-600">
                Electrolytic zinc plating is a coating process that applies a layer of zinc to metal surfaces through
                electrodeposition, offering excellent corrosion protection and superior aesthetic finish.
              </p>
              <p className="mt-4 text-lg text-gray-600">
                At LJ Santos, we use cutting-edge technology and rigorously controlled processes to ensure uniform,
                adherent, and high-quality coatings that meet the most demanding technical and environmental standards.
              </p>
            </div>
            <div className="mt-10 lg:mt-0 relative">
              <ScrollAnimation>
                <Image
                  src="/images/zincagem-4.png"
                  alt="LJ Santos Electrolytic Zinc Plating Line"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl"
                />
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      {/* Features and Benefits */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Features and Benefits</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Our electrolytic zinc plating line offers significant advantages for various industrial sectors.
            </p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Anticorrosive Protection</h3>
              <p className="mt-2 text-gray-600">
                Excellent corrosion resistance, significantly extending the service life of metal components.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Uniform Finish</h3>
              <p className="mt-2 text-gray-600">
                Homogeneous and controlled coating, ensuring uniform thickness across the entire surface of the part.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Versatility</h3>
              <p className="mt-2 text-gray-600">
                Applicable to a wide variety of parts and components, from small screws to larger structures.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Colored Passivation</h3>
              <p className="mt-2 text-gray-600">
                Options for blue, yellow, black, or clear passivation, meeting different aesthetic and technical
                requirements.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Environmental Compliance</h3>
              <p className="mt-2 text-gray-600">
                Hexavalent chromium-free processes, meeting the most stringent environmental standards, including RoHS
                and REACH.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Quality Control</h3>
              <p className="mt-2 text-gray-600">
                Rigorous quality control at all stages of the process, ensuring consistent and reliable results.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Zinc Plating Process */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Electrolytic Zinc Plating Process</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Learn about the steps of our high-quality electrolytic zinc plating process.
            </p>
          </div>

          <div className="mt-12">
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="mt-10 lg:mt-0 relative order-first lg:order-last">
                <ScrollAnimation>
                  <Image
                    src="/images/zincagem-2.png"
                    alt="Electrolytic Zinc Plating Line"
                    width={600}
                    height={400}
                    className="rounded-lg shadow-xl"
                  />
                </ScrollAnimation>
              </div>
              <div>
                <ol className="space-y-6">
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        1
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Surface Preparation</h3>
                      <p className="mt-2 text-gray-600">
                        Cleaning, degreasing, and pickling to remove impurities and ensure perfect coating adhesion.
                      </p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        2
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Electrodeposition</h3>
                      <p className="mt-2 text-gray-600">
                        Immersion of parts in an electrolytic bath containing zinc salts, where controlled metal
                        deposition occurs.
                      </p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        3
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Passivation</h3>
                      <p className="mt-2 text-gray-600">
                        Chemical treatment that increases corrosion resistance and can give different colors to the
                        coating.
                      </p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        4
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Drying and Finishing</h3>
                      <p className="mt-2 text-gray-600">
                        Controlled drying and final inspection to ensure coating quality and compliance with
                        specifications.
                      </p>
                    </div>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Image Gallery */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Our Infrastructure</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Discover our modern electrolytic zinc plating line, designed to deliver exceptional results.
            </p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-2">
            <div className="relative">
              <ScrollAnimation>
                <Image
                  src="/images/zincagem-1.png"
                  alt="Rotating barrel for zinc plating of small parts"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl"
                />
                <p className="mt-2 text-sm text-gray-500 text-center">
                  Rotating barrel for bulk zinc plating of small parts
                </p>
              </ScrollAnimation>
            </div>
            <div className="relative">
              <ScrollAnimation>
                <Image
                  src="/images/zincagem-3.png"
                  alt="Barrel system for electrolytic zinc plating"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl"
                />
                <p className="mt-2 text-sm text-gray-500 text-center">
                  Detail of the barrel system for electrolytic zinc plating
                </p>
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Technical Specifications</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Our electrolytic zinc plating line meets the most rigorous quality standards.
            </p>
          </div>

          <div className="mt-12 bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Characteristic
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Specification
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Coating Thickness</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    5 to 25 μm (according to specification)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Passivation Types</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Blue, Yellow, Black, Clear (Trivalent)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Corrosion Resistance
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    96 to 720 hours in salt spray (ASTM B117)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Production Capacity</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Up to 5 tons/day (depending on part type)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Maximum Part Dimensions
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    2000 x 800 x 500 mm (length x width x height)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Compliance</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    RoHS, REACH, ISO 9001, ISO 14001
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Applications</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Our electrolytic zinc plating is used in various industrial sectors.
            </p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Automotive Industry</h3>
              <p className="mt-2 text-gray-600">
                Fasteners, structural parts, brake systems, suspension elements, and chassis components.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Construction</h3>
              <p className="mt-2 text-gray-600">
                Screws, nuts, washers, brackets, fasteners, and structural elements for construction.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Home Appliances</h3>
              <p className="mt-2 text-gray-600">
                Internal and external components of appliances that require corrosion protection.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Electrical Industry</h3>
              <p className="mt-2 text-gray-600">
                Distribution boxes, brackets, fasteners, and electrical panel components.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Machinery and Equipment</h3>
              <p className="mt-2 text-gray-600">
                Parts and components for industrial, agricultural, and construction machinery.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Metal Furniture</h3>
              <p className="mt-2 text-gray-600">
                Components for office, hospital, and industrial furniture that need protection.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-green-700">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Need high-quality electrolytic zinc plating?
          </h2>
          <p className="mt-4 text-xl text-green-100">
            Contact us to discuss your project and get a customized solution.
          </p>
          <div className="mt-8">
            <a
              href="#"
              className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-green-700 bg-white hover:bg-green-50"
            >
              Request a Quote
            </a>
          </div>
        </div>
      </section>
    </main>
  )
}
