import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { Calendar, User, ArrowRight } from "lucide-react"

// Datos simulados para las entradas del blog
const blogPosts = [
  {
    id: 1,
    title: "Sostenibilidad en la industria: prácticas para reducir el impacto ambiental",
    excerpt:
      "Descubra cómo implementar prácticas sostenibles en procesos industriales y reducir el impacto ambiental de su empresa.",
    image: "/images/blog-sustainability.jpg",
    date: "15 de Abril, 2023",
    author: "Carlos Silva",
    category: "Sostenibilidad",
    slug: "sostenibilidad-en-la-industria",
  },
  {
    id: 2,
    title: "Innovaciones en el tratamiento de efluentes industriales",
    excerpt:
      "Conozca las tecnologías e innovaciones más recientes en el tratamiento de efluentes industriales y cómo pueden beneficiar a su empresa.",
    image: "/images/blog-innovation.jpg",
    date: "28 de Marzo, 2023",
    author: "Ana Rodrigues",
    category: "Tecnología",
    slug: "innovaciones-tratamiento-efluentes",
  },
  {
    id: 3,
    title: "Legislación ambiental: lo que su empresa necesita saber",
    excerpt: "Una guía completa sobre las principales leyes y regulaciones ambientales que afectan a las industrias.",
    image: "/images/blog-legislation.jpg",
    date: "10 de Marzo, 2023",
    author: "Roberto Mendes",
    category: "Legislación",
    slug: "legislacion-ambiental-empresas",
  },
  {
    id: 4,
    title: "Economía circular en la industria: transformando residuos en recursos",
    excerpt:
      "Cómo implementar principios de economía circular en procesos industriales y transformar residuos en nuevos recursos.",
    image: "/images/blog-circular.jpg",
    date: "22 de Febrero, 2023",
    author: "Mariana Costa",
    category: "Economía Circular",
    slug: "economia-circular-industria",
  },
  {
    id: 5,
    title: "Mantenimiento preventivo en estaciones de tratamiento de efluentes",
    excerpt:
      "Consejos y mejores prácticas para el mantenimiento preventivo de estaciones de tratamiento de efluentes, aumentando su vida útil y eficiencia.",
    image: "/images/blog-maintenance.jpg",
    date: "05 de Febrero, 2023",
    author: "Paulo Ribeiro",
    category: "Mantenimiento",
    slug: "mantenimiento-preventivo-ete",
  },
  {
    id: 6,
    title: "Casos de éxito: empresas que transformaron su gestión ambiental",
    excerpt:
      "Conozca historias de empresas que implementaron con éxito sistemas de gestión ambiental y los beneficios que obtuvieron.",
    image: "/images/blog-success.jpg",
    date: "18 de Enero, 2023",
    author: "Juliana Santos",
    category: "Casos de Éxito",
    slug: "casos-exito-gestion-ambiental",
  },
]

// Categorías para filtro
const categories = [
  "Todas",
  "Sostenibilidad",
  "Tecnología",
  "Legislación",
  "Economía Circular",
  "Mantenimiento",
  "Casos de Éxito",
]

export default function SpanishBlog() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-[#435a52] mb-6">Blog</h1>
              <p className="text-lg text-gray-700 mb-8">
                Manténgase al día con las últimas noticias, tendencias e información sobre sostenibilidad, tratamiento
                de efluentes y soluciones industriales.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Blog Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <ScrollAnimation animation="animate-fadeInRight">
                <div className="sticky top-32">
                  <div className="bg-[#f2f7f5] p-6 rounded-xl mb-8">
                    <h3 className="text-xl font-bold text-[#435a52] mb-4">Categorías</h3>
                    <ul className="space-y-2">
                      {categories.map((category, index) => (
                        <li key={index}>
                          <a
                            href="#"
                            className={`block py-2 px-3 rounded-lg transition-colors ${
                              index === 0
                                ? "bg-[#448b13] text-white"
                                : "hover:bg-[#e6f0eb] text-[#435a52] hover:text-[#448b13]"
                            }`}
                          >
                            {category}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="bg-[#f2f7f5] p-6 rounded-xl">
                    <h3 className="text-xl font-bold text-[#435a52] mb-4">Newsletter</h3>
                    <p className="text-gray-700 mb-4">
                      Suscríbase para recibir las últimas actualizaciones y artículos directamente en su correo
                      electrónico.
                    </p>
                    <form>
                      <input
                        type="email"
                        placeholder="Su correo electrónico"
                        className="w-full p-3 mb-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#448b13]"
                      />
                      <button
                        type="submit"
                        className="w-full bg-[#448b13] text-white font-semibold py-3 px-4 rounded-lg hover:bg-[#3a7510] transition-colors"
                      >
                        Suscribirse
                      </button>
                    </form>
                  </div>
                </div>
              </ScrollAnimation>
            </div>

            {/* Blog Posts */}
            <div className="lg:col-span-3">
              <ScrollAnimation animation="animate-fadeInLeft">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {blogPosts.map((post) => (
                    <div
                      key={post.id}
                      className="bg-white border border-gray-100 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
                    >
                      <div className="relative h-48 overflow-hidden">
                        <Image
                          src={post.image || "/placeholder.svg"}
                          alt={post.title}
                          width={600}
                          height={300}
                          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                        />
                        <div className="absolute top-4 left-4 bg-[#448b13] text-white text-xs font-semibold py-1 px-2 rounded">
                          {post.category}
                        </div>
                      </div>
                      <div className="p-6">
                        <h3 className="text-xl font-bold text-[#435a52] mb-3 line-clamp-2">{post.title}</h3>
                        <p className="text-gray-600 mb-4 line-clamp-3">{post.excerpt}</p>
                        <div className="flex items-center text-sm text-gray-500 mb-4">
                          <div className="flex items-center mr-4">
                            <Calendar className="w-4 h-4 mr-1" />
                            <span>{post.date}</span>
                          </div>
                          <div className="flex items-center">
                            <User className="w-4 h-4 mr-1" />
                            <span>{post.author}</span>
                          </div>
                        </div>
                        <Link
                          href={`/es/blog/${post.slug}`}
                          className="inline-flex items-center text-[#448b13] font-semibold hover:text-[#3a7510] transition-colors"
                        >
                          Leer más <ArrowRight className="w-4 h-4 ml-1" />
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Pagination */}
                <div className="mt-12 flex justify-center">
                  <nav className="flex items-center space-x-2">
                    <a
                      href="#"
                      className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                      Anterior
                    </a>
                    <a
                      href="#"
                      className="px-4 py-2 border border-gray-300 rounded-lg bg-[#448b13] text-white hover:bg-[#3a7510] transition-colors"
                    >
                      1
                    </a>
                    <a
                      href="#"
                      className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                      2
                    </a>
                    <a
                      href="#"
                      className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                      3
                    </a>
                    <a
                      href="#"
                      className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                      Siguiente
                    </a>
                  </nav>
                </div>
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
