import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Shield, Settings, BarChart, Zap, Recycle } from "lucide-react"

export default function SpanishChromePlating() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-[#435a52] mb-6">Líneas de Cromado</h1>
              <p className="text-lg text-gray-700 mb-8">
                Soluciones completas para procesos de cromado industrial con alta eficiencia y calidad superior.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/es/solicite-orcamento"
                  className="request-button inline-block rounded-xl hover:shadow-lg transition-all duration-300"
                >
                  Solicitar presupuesto
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">Cromado de Alto Rendimiento</h2>
                <p className="text-gray-700 mb-4">
                  LJ Santos desarrolla líneas de cromado completas, diseñadas para satisfacer las necesidades
                  específicas de cada cliente, garantizando acabados de alta calidad y durabilidad excepcional.
                </p>
                <p className="text-gray-700 mb-4">
                  Nuestras líneas de cromado están equipadas con tecnología avanzada para garantizar procesos
                  eficientes, seguros y ambientalmente responsables, cumpliendo con todas las normas y regulaciones del
                  sector.
                </p>
                <p className="text-gray-700 mb-4">
                  Ofrecemos soluciones completas que incluyen desde el diseño inicial hasta la instalación y
                  mantenimiento, garantizando el mejor rendimiento y longevidad de los equipos.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/cromagem-4.webp"
                  alt="Línea de Cromado LJ Santos"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Características y Beneficios
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <BarChart className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Alta Productividad</h3>
                <p className="text-gray-700">
                  Sistemas diseñados para maximizar la eficiencia operativa y aumentar la productividad de su línea de
                  producción.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <CheckCircle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Calidad Superior</h3>
                <p className="text-gray-700">
                  Acabados de alta calidad con uniformidad y brillo excepcional, garantizando productos finales de
                  excelencia.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Recycle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Sostenibilidad</h3>
                <p className="text-gray-700">
                  Procesos optimizados para reducir el consumo de agua y energía, minimizando el impacto ambiental.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Settings className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Automatización</h3>
                <p className="text-gray-700">
                  Sistemas de automatización avanzados que aumentan la precisión del proceso y reducen los costos
                  operativos.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Shield className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Seguridad</h3>
                <p className="text-gray-700">
                  Equipos diseñados con los más altos estándares de seguridad, protegiendo tanto a los operadores como
                  al medio ambiente.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Zap className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Eficiencia Energética</h3>
                <p className="text-gray-700">
                  Sistemas optimizados para un menor consumo de energía, reduciendo los costos operativos y el impacto
                  ambiental.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">Especificaciones Técnicas</h2>
                <p className="text-gray-700 mb-6">
                  Nuestras líneas de cromado están diseñadas con componentes de alta calidad y tecnología avanzada para
                  garantizar un rendimiento óptimo y durabilidad.
                </p>

                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Tanques en polipropileno de alta resistencia química</strong>
                      <p className="text-gray-700">
                        Fabricados con materiales que garantizan durabilidad y resistencia a los agentes químicos
                        utilizados en el proceso de cromado.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Sistemas de calentamiento y enfriamiento eficientes</strong>
                      <p className="text-gray-700">
                        Sistemas de control de temperatura que garantizan la estabilidad del proceso y la eficiencia
                        energética.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Rectificadores de alta frecuencia con control digital</strong>
                      <p className="text-gray-700">
                        Sistemas de potencia avanzados que proporcionan un control preciso del proceso de
                        electrodeposición.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Sistemas de filtración continua</strong>
                      <p className="text-gray-700">
                        Garantiza una mayor durabilidad de los baños y una calidad consistente del cromado.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Automatización completa con interfaz intuitiva</strong>
                      <p className="text-gray-700">
                        Sistemas de control fáciles de usar que simplifican la operación y el monitoreo del proceso.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Sistemas de extracción y tratamiento de vapores</strong>
                      <p className="text-gray-700">
                        Sistemas de protección ambiental que garantizan el cumplimiento de las normativas ambientales.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/cromagem-5.webp"
                  alt="Detalles Técnicos de la Línea de Cromado"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg mb-6"
                />
                <Image
                  src="/images/cromagem-6.webp"
                  alt="Componentes de la Línea de Cromado"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Proceso de Cromado
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Etapas del Proceso</h3>
                <p className="text-gray-700 mb-6">
                  El proceso de cromado realizado en nuestras líneas sigue un flujo riguroso de etapas para garantizar
                  acabados de alta calidad y durabilidad excepcional.
                </p>

                <ol className="space-y-4">
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">1</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Preparación de la Superficie</strong>
                      <p className="text-gray-700">
                        Limpieza y tratamiento inicial de las piezas para eliminar impurezas, aceites y oxidaciones que
                        puedan comprometer la calidad del acabado.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">2</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Baño de Níquel</strong>
                      <p className="text-gray-700">
                        Aplicación de una capa de níquel que sirve como base para el cromo, mejorando la adherencia y
                        proporcionando mayor resistencia a la corrosión.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">3</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Cromado</strong>
                      <p className="text-gray-700">
                        Electrodeposición de cromo sobre la capa de níquel, realizada en tanques especiales con control
                        preciso de temperatura, corriente eléctrica y tiempo de inmersión.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">4</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Lavado y Neutralización</strong>
                      <p className="text-gray-700">
                        Eliminación de residuos químicos de las piezas mediante lavado y neutralización, garantizando la
                        seguridad del producto final.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">5</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Secado e Inspección Final</strong>
                      <p className="text-gray-700">
                        Secado controlado de las piezas e inspección rigurosa para garantizar la calidad del acabado,
                        brillo y uniformidad de la capa de cromo.
                      </p>
                    </div>
                  </li>
                </ol>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="grid grid-cols-1 gap-6">
                <Image
                  src="/images/cromagem-12.webp"
                  alt="Proceso de Cromado en Acción"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg mb-6"
                />
                <Image
                  src="/images/cromagem-17.webp"
                  alt="Sistema de Transporte de Piezas"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="grid grid-cols-2 gap-4">
                <Image
                  src="/images/cromagem-14.webp"
                  alt="Piezas Cromadas"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/cromagem-15.webp"
                  alt="Detalle del Proceso de Cromado"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/cromagem-13.webp"
                  alt="Antes y Después del Cromado"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/cromagem-1.webp"
                  alt="Producto Final Cromado"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Control de Calidad</h3>
                <p className="text-gray-700 mb-6">
                  Nuestro proceso de cromado se somete a rigurosos controles de calidad en todas las etapas,
                  garantizando resultados excepcionales y consistentes.
                </p>

                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Pruebas de Adherencia</strong>
                      <p className="text-gray-700">
                        Verificación de la calidad de la adherencia del cromo al sustrato, garantizando durabilidad y
                        resistencia.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Inspección Visual</strong>
                      <p className="text-gray-700">
                        Análisis detallado del acabado para identificar imperfecciones, manchas o irregularidades.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Pruebas de Espesor</strong>
                      <p className="text-gray-700">
                        Medición precisa del espesor de la capa de cromo para garantizar el cumplimiento de las
                        especificaciones.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Pruebas de Corrosión</strong>
                      <p className="text-gray-700">
                        Evaluación de la resistencia a la corrosión mediante pruebas en cámara de niebla salina.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Control Ambiental</strong>
                      <p className="text-gray-700">
                        Monitoreo constante de los parámetros ambientales del proceso, incluyendo el tratamiento
                        adecuado de efluentes y emisiones.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Aplicaciones</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Industria Automotriz</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Cromado de piezas y accesorios automotrices</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Acabados decorativos para componentes interiores y exteriores</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Cromado funcional para resistencia al desgaste</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Muebles y Decoración</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Cromado de componentes de muebles</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Elementos decorativos para diseño de interiores</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Accesorios para baño y cocina</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Equipos Industriales</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Cromado duro para componentes industriales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">
                      Resistencia al desgaste y a la corrosión para piezas de maquinaria
                    </span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Tratamiento de superficies para componentes hidráulicos</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Electrónica</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Cromado de componentes electrónicos</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Superficies conductoras para aplicaciones electrónicas</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recubrimientos protectores para dispositivos electrónicos</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Environmental Systems */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Sistemas de Tratamiento Ambiental
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <Image
                  src="/images/cromagem-11.webp"
                  alt="Sistema de Tratamiento de Emisiones"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">
                  Compromiso con la Sostenibilidad
                </h3>
                <p className="text-gray-700 mb-6">
                  Nuestras líneas de cromado están equipadas con sistemas avanzados de tratamiento de efluentes y
                  emisiones, garantizando el cumplimiento de las normas ambientales más estrictas y minimizando el
                  impacto al medio ambiente.
                </p>

                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Lavadores de Gases</strong>
                      <p className="text-gray-700">
                        Sistemas de alta eficiencia para capturar y neutralizar vapores y gases generados durante el
                        proceso de cromado, evitando la liberación de contaminantes a la atmósfera.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Estación de Tratamiento de Efluentes</strong>
                      <p className="text-gray-700">
                        Tratamiento completo de los efluentes líquidos generados en el proceso, incluyendo
                        neutralización, precipitación de metales y filtración, permitiendo la reutilización del agua o
                        su descarga segura.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Recuperación de Metales</strong>
                      <p className="text-gray-700">
                        Sistemas para la recuperación de metales presentes en los efluentes, reduciendo el consumo de
                        materias primas y minimizando la generación de residuos.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Monitoreo Continuo</strong>
                      <p className="text-gray-700">
                        Sistemas automatizados de monitoreo para garantizar la eficiencia de los procesos de tratamiento
                        y el cumplimiento de los parámetros ambientales establecidos.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Galería</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <Image
                src="/images/cromagem-2.webp"
                alt="Línea de Cromado - Estructura"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <Image
                src="/images/cromagem-3.webp"
                alt="Línea de Cromado - Vista General"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <Image
                src="/images/cromagem-7.webp"
                alt="Línea de Cromado - Tanques"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <Image
                src="/images/cromagem-14.webp"
                alt="Piezas Cromadas - Resultado Final"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <Image
                src="/images/cromagem-15.webp"
                alt="Piezas en Proceso de Cromado"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <Image
                src="/images/cromagem-1.webp"
                alt="Producto Cromado Finalizado"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <Image
                src="/images/cromagem-12.webp"
                alt="Proceso de Cromado en Acción"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <Image
                src="/images/cromagem-13.webp"
                alt="Antes y Después del Cromado"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <Image
                src="/images/cromagem-16.webp"
                alt="Vista del Corredor de la Línea de Cromado"
                width={400}
                height={300}
                className="rounded-md shadow-md h-64 object-cover"
              />
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">¿Interesado en nuestras soluciones de cromado?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Contáctenos para obtener más información y un presupuesto personalizado para sus necesidades específicas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/es/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Solicitar presupuesto
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      <Footer />
    </main>
  )
}
