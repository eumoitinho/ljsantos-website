import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Filter, Droplets, Recycle, Settings, BarChart } from "lucide-react"

export default function FiltroPrensa() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-30"></div>
          <Image src="/images/filtro-prensa-3.png" alt="Filtro Prensa" fill className="object-cover" priority />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Filtro Prensa</h1>
              <p className="text-lg text-white/90 mb-8">
                Soluções eficientes para separação sólido-líquido, garantindo alta performance e economia operacional
                para diversos processos industriais.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/solicite-orcamento"
                  className="inline-block bg-white text-[#435a52] font-bold py-3 px-6 rounded-xl hover:bg-gray-100 transition-all duration-300 hover:shadow-lg"
                >
                  Solicite um orçamento
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">Tecnologia Avançada em Filtração</h2>
                <p className="text-gray-700 mb-4">
                  O Filtro Prensa da LJ Santos é um equipamento de alta eficiência projetado para a separação de sólidos
                  e líquidos em diversos processos industriais. Utilizando um sistema de placas e quadros, nosso filtro
                  prensa proporciona uma filtração de alta performance com baixo custo operacional.
                </p>
                <p className="text-gray-700 mb-4">
                  Desenvolvido com materiais de alta qualidade e tecnologia avançada, nosso filtro prensa é ideal para
                  aplicações em tratamento de efluentes, indústria química, mineração, galvanoplastia, entre outros
                  setores que necessitam de processos eficientes de desaguamento de lodo.
                </p>
                <p className="text-gray-700">
                  Cada filtro prensa é projetado de acordo com as necessidades específicas do cliente, garantindo a
                  melhor solução para cada aplicação e proporcionando resultados superiores em termos de eficiência e
                  economia.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src="/images/filtro-prensa-3.png"
                  alt="Filtro Prensa LJ Santos"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Como Funciona</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src="/images/filtro-prensa-4.jpeg"
                  alt="Filtro Prensa em Operação"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Princípio de Funcionamento</h3>
                <p className="text-gray-700 mb-6">
                  O filtro prensa opera através da aplicação de pressão mecânica sobre uma suspensão contendo sólidos e
                  líquidos, forçando o líquido a passar através de placas filtrantes enquanto retém os sólidos.
                </p>

                <h4 className="text-xl font-semibold text-[#435a52] mb-3">Etapas do Processo</h4>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">1</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Alimentação:</strong> A suspensão é bombeada para o interior do filtro prensa.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">2</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Filtração:</strong> O líquido passa através das placas filtrantes, enquanto os sólidos
                      ficam retidos.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">3</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Compressão:</strong> A pressão é mantida para maximizar a remoção de líquidos.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">4</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Descarga:</strong> As placas são separadas e a torta de filtro (material sólido) é
                      removida.
                    </span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Componentes Principais</h3>
                <p className="text-gray-700 mb-6">
                  Nossos filtros prensa são compostos por componentes de alta qualidade, projetados para garantir
                  durabilidade e eficiência operacional.
                </p>

                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Placas Filtrantes:</strong>
                      <p className="text-gray-700">
                        Fabricadas em polipropileno de alta resistência, com design otimizado para máxima eficiência de
                        filtração.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Estrutura de Suporte:</strong>
                      <p className="text-gray-700">
                        Construída em aço carbono com pintura epóxi ou aço inoxidável, garantindo resistência à corrosão
                        e durabilidade.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Sistema Hidráulico:</strong>
                      <p className="text-gray-700">
                        Proporciona a pressão necessária para o fechamento e operação do filtro, com controles
                        automatizados para maior segurança.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Telas Filtrantes:</strong>
                      <p className="text-gray-700">
                        Disponíveis em diferentes materiais e aberturas, adaptadas às necessidades específicas de cada
                        aplicação.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="/images/filtro-prensa-1.jpeg"
                    alt="Placa Filtrante"
                    width={300}
                    height={300}
                    className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="/images/filtro-prensa-2.jpeg"
                    alt="Detalhe da Placa Filtrante"
                    width={300}
                    height={300}
                    className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="/images/filtro-prensa-5.png"
                    alt="Telas Filtrantes"
                    width={300}
                    height={300}
                    className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="rounded-lg overflow-hidden shadow-md">
                  <Image
                    src="/images/filtro-prensa-6.png"
                    alt="Estrutura do Filtro Prensa"
                    width={300}
                    height={300}
                    className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Benefícios e Vantagens
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Filter className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Alta Eficiência de Filtração</h3>
                <p className="text-gray-700">
                  Proporciona uma separação eficiente de sólidos e líquidos, com capacidade para atingir até 80% de
                  secagem na torta de filtro.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Droplets className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Economia de Água</h3>
                <p className="text-gray-700">
                  Permite a recuperação e reuso da água filtrada, contribuindo para a sustentabilidade e redução de
                  custos operacionais.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Recycle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Gestão de Resíduos</h3>
                <p className="text-gray-700">
                  Facilita o manuseio e disposição dos resíduos sólidos, reduzindo custos de transporte e disposição
                  final.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Settings className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Operação Automatizada</h3>
                <p className="text-gray-700">
                  Sistemas com controle automatizado que reduzem a necessidade de intervenção manual e aumentam a
                  segurança operacional.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <BarChart className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Baixo Custo Operacional</h3>
                <p className="text-gray-700">
                  Menor consumo de energia e insumos químicos em comparação com outros sistemas de desaguamento,
                  resultando em economia significativa.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <CheckCircle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Versatilidade</h3>
                <p className="text-gray-700">
                  Adaptável a diferentes tipos de lodo e aplicações industriais, com possibilidade de customização para
                  atender necessidades específicas.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Aplicações</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Tratamento de Efluentes</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Desaguamento de lodo de estações de tratamento</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Separação de sólidos em efluentes industriais</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recuperação de água para reuso</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Indústria Química</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Filtração de produtos químicos</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recuperação de matérias-primas</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Separação de cristais e precipitados</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Galvanoplastia</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Tratamento de efluentes com metais pesados</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recuperação de metais valiosos</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Redução do volume de resíduos para disposição</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Mineração</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Desaguamento de rejeitos</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recuperação de água de processo</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Concentração de minérios</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Especificações Técnicas
            </h2>
          </ScrollAnimation>

          <ScrollAnimation animation="animate-zoomIn">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse serious-table rounded-xl overflow-hidden shadow-lg">
                <thead>
                  <tr>
                    <th className="text-left bg-[#435a52] text-white">Modelo</th>
                    <th className="text-center bg-[#435a52] text-white">Área de Filtração</th>
                    <th className="text-center bg-[#435a52] text-white">Número de Placas</th>
                    <th className="text-center bg-[#435a52] text-white">Pressão de Operação</th>
                    <th className="text-center bg-[#435a52] text-white">Capacidade</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="font-medium">FP-400</td>
                    <td className="text-center">4 m²</td>
                    <td className="text-center">20</td>
                    <td className="text-center">Até 10 bar</td>
                    <td className="text-center">100-200 kg/ciclo</td>
                  </tr>
                  <tr>
                    <td className="font-medium">FP-800</td>
                    <td className="text-center">8 m²</td>
                    <td className="text-center">40</td>
                    <td className="text-center">Até 12 bar</td>
                    <td className="text-center">200-400 kg/ciclo</td>
                  </tr>
                  <tr>
                    <td className="font-medium">FP-1200</td>
                    <td className="text-center">12 m²</td>
                    <td className="text-center">60</td>
                    <td className="text-center">Até 15 bar</td>
                    <td className="text-center">300-600 kg/ciclo</td>
                  </tr>
                  <tr>
                    <td className="font-medium">FP-2000</td>
                    <td className="text-center">20 m²</td>
                    <td className="text-center">100</td>
                    <td className="text-center">Até 15 bar</td>
                    <td className="text-center">500-1000 kg/ciclo</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-sm text-gray-500 mt-4 text-center">
              * As especificações podem variar de acordo com as necessidades específicas de cada projeto.
            </p>
          </ScrollAnimation>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Solicite um Filtro Prensa Personalizado</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Entre em contato conosco para uma avaliação personalizada e descubra qual modelo de Filtro Prensa é mais
              adequado para as necessidades da sua empresa.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Solicite um orçamento
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      <Footer />
    </main>
  )
}
