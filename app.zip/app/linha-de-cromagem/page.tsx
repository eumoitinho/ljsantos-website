import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Shield, Settings, BarChart, Zap, Recycle } from "lucide-react"

export default function LinhaDeChromagem() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-30"></div>
          <Image src="/images/cromagem-4.webp" alt="Linha de Cromagem" fill className="object-cover" priority />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Linha de Cromagem</h1>
              <p className="text-lg text-white/90 mb-8">
                Soluções completas para processos de cromagem industrial com alta eficiência e qualidade superior.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/solicite-orcamento"
                  className="inline-block bg-white text-[#435a52] font-bold py-3 px-6 rounded-xl hover:bg-gray-100 transition-all duration-300 hover:shadow-lg"
                >
                  Solicite um orçamento
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">Cromagem de Alta Performance</h2>
                <p className="text-gray-700 mb-4">
                  A LJ Santos desenvolve linhas de cromagem completas, projetadas para atender às necessidades
                  específicas de cada cliente, garantindo acabamentos de alta qualidade e durabilidade excepcional.
                </p>
                <p className="text-gray-700 mb-4">
                  Nossas linhas de cromagem são equipadas com tecnologia avançada para garantir processos eficientes,
                  seguros e ambientalmente responsáveis, atendendo a todas as normas e regulamentações do setor.
                </p>
                <p className="text-gray-700 mb-4">
                  Oferecemos soluções completas que incluem desde o projeto inicial até a instalação e manutenção,
                  garantindo o melhor desempenho e longevidade dos equipamentos.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src="/images/cromagem-4.webp"
                  alt="Linha de Cromagem LJ Santos"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Características e Benefícios
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <BarChart className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Alta Produtividade</h3>
                <p className="text-gray-700">
                  Sistemas projetados para maximizar a eficiência operacional e aumentar a produtividade da sua linha de
                  produção.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <CheckCircle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Qualidade Superior</h3>
                <p className="text-gray-700">
                  Acabamentos de alta qualidade com uniformidade e brilho excepcional, garantindo produtos finais de
                  excelência.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Recycle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Sustentabilidade</h3>
                <p className="text-gray-700">
                  Processos otimizados para reduzir o consumo de água e energia, minimizando o impacto ambiental.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Settings className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Automação</h3>
                <p className="text-gray-700">
                  Sistemas de automação avançados que aumentam a precisão do processo e reduzem os custos operacionais.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Shield className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Segurança</h3>
                <p className="text-gray-700">
                  Equipamentos projetados com os mais altos padrões de segurança, protegendo tanto os operadores quanto
                  o meio ambiente.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Zap className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Eficiência Energética</h3>
                <p className="text-gray-700">
                  Sistemas otimizados para menor consumo de energia, reduzindo custos operacionais e impacto ambiental.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Gallery */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Galeria</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="rounded-lg overflow-hidden shadow-md">
                <Image
                  src="/images/cromagem-2.webp"
                  alt="Linha de Cromagem - Estrutura"
                  width={400}
                  height={300}
                  className="w-full h-64 object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="rounded-lg overflow-hidden shadow-md">
                <Image
                  src="/images/cromagem-3.webp"
                  alt="Linha de Cromagem - Visão Geral"
                  width={400}
                  height={300}
                  className="w-full h-64 object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="rounded-lg overflow-hidden shadow-md">
                <Image
                  src="/images/cromagem-7.webp"
                  alt="Linha de Cromagem - Tanques"
                  width={400}
                  height={300}
                  className="w-full h-64 object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="rounded-lg overflow-hidden shadow-md">
                <Image
                  src="/images/cromagem-14.webp"
                  alt="Peças Cromadas - Resultado Final"
                  width={400}
                  height={300}
                  className="w-full h-64 object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="rounded-lg overflow-hidden shadow-md">
                <Image
                  src="/images/cromagem-15.webp"
                  alt="Peças em Processo de Cromagem"
                  width={400}
                  height={300}
                  className="w-full h-64 object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="rounded-lg overflow-hidden shadow-md">
                <Image
                  src="/images/cromagem-1.webp"
                  alt="Produto Cromado Finalizado"
                  width={400}
                  height={300}
                  className="w-full h-64 object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Processo de Cromagem
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Etapas do Processo</h3>
                <p className="text-gray-700 mb-6">
                  O processo de cromagem realizado em nossas linhas segue um fluxo rigoroso de etapas para garantir
                  acabamentos de alta qualidade e durabilidade excepcional.
                </p>

                <ol className="space-y-4">
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">1</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Preparação da Superfície</strong>
                      <p className="text-gray-700">
                        Limpeza e tratamento inicial das peças para remover impurezas, óleos e oxidações que possam
                        comprometer a qualidade do acabamento.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">2</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Banho de Níquel</strong>
                      <p className="text-gray-700">
                        Aplicação de uma camada de níquel que serve como base para o cromo, melhorando a aderência e
                        proporcionando maior resistência à corrosão.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">3</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Cromagem</strong>
                      <p className="text-gray-700">
                        Eletrodeposição de cromo sobre a camada de níquel, realizada em tanques especiais com controle
                        preciso de temperatura, corrente elétrica e tempo de imersão.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">4</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Lavagem e Neutralização</strong>
                      <p className="text-gray-700">
                        Remoção de resíduos químicos das peças através de lavagem e neutralização, garantindo a
                        segurança do produto final.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">5</span>
                    </div>
                    <div>
                      <strong className="text-[#435a52]">Secagem e Inspeção Final</strong>
                      <p className="text-gray-700">
                        Secagem controlada das peças e inspeção rigorosa para garantir a qualidade do acabamento, brilho
                        e uniformidade da camada de cromo.
                      </p>
                    </div>
                  </li>
                </ol>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src="/images/cromagem-12.webp"
                  alt="Processo de Cromagem em Andamento"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Interessado em nossas soluções de cromagem?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Entre em contato conosco para obter mais informações e um orçamento personalizado para suas necessidades
              específicas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Solicitar orçamento
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      <Footer />
    </main>
  )
}
