import Image from "next/image"
import ScrollAnimation from "@/components/scroll-animation"
import ImageCarousel from "@/components/image-carousel"
import SectionTitle from "@/components/section-title"
import CTAButton from "@/components/cta-button"
import AnimatedCounter from "@/components/animated-counter"
import Header from "@/components/header"
import Footer from "@/components/footer"

export default function TanquesPolipropileno() {
  // Imagens para o carrossel
  const carouselImages = [
    { src: "/images/tanques-pp-1.jpeg", alt: "Tanques horizontais em polipropileno" },
    { src: "/images/tanques-pp-2.jpeg", alt: "Tanques em polipropileno em transporte" },
    { src: "/images/tanques-pp-3.jpeg", alt: "Interior de tanque com defletores" },
    { src: "/images/tanques-pp-4.jpeg", alt: "Vista frontal de tanque com divisórias" },
    { src: "/images/tanques-pp-5.jpeg", alt: "Vista aérea de tanques de polipropileno" },
    { src: "/images/tanques-pp-6.jpeg", alt: "Tanques horizontais instalados" },
    { src: "/images/tanques-pp-7.png", alt: "Tanque cilíndrico em polipropileno" },
    { src: "/images/tanques-pp-8.png", alt: "Tanque de processo em polipropileno" },
    { src: "/images/tanques-pp-9.png", alt: "Tanques verticais em polipropileno" },
  ]

  // Imagens para cada tipo de tanque
  const horizontalTankImages = [
    { src: "/images/tanques-pp-1.jpeg", alt: "Tanques horizontais em polipropileno" },
    { src: "/images/tanques-pp-2.jpeg", alt: "Tanques em polipropileno em transporte" },
    { src: "/images/tanques-pp-6.jpeg", alt: "Tanques horizontais instalados" },
  ]

  const verticalTankImages = [
    { src: "/images/tanques-pp-9.png", alt: "Tanques verticais em polipropileno" },
    { src: "/images/tanques-pp-7.png", alt: "Tanque cilíndrico em polipropileno" },
  ]

  const processTankImages = [{ src: "/images/tanques-pp-8.png", alt: "Tanque de processo em polipropileno" }]

  const specialTankImages = [
    { src: "/images/tanques-pp-3.jpeg", alt: "Interior de tanque com defletores" },
    { src: "/images/tanques-pp-4.jpeg", alt: "Vista frontal de tanque com divisórias" },
  ]

  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-green-800 to-green-600 text-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-30"></div>
          <Image
            src="/images/tanques-pp-5.jpeg"
            alt="Tanques em Polipropileno"
            fill
            className="object-cover"
            priority
          />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">Tanques em Polipropileno</h1>
              <p className="text-xl text-white/90 mb-8">
                Soluções duráveis e resistentes para armazenamento e processamento de produtos químicos, com alta
                resistência à corrosão e excelente custo-benefício.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-wrap gap-4">
                <CTAButton href="#contato" variant="primary">
                  Solicitar Orçamento
                </CTAButton>
                <CTAButton
                  href="#especificacoes"
                  variant="outline"
                  className="border-white text-white hover:bg-white/20"
                >
                  Especificações Técnicas
                </CTAButton>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Visão Geral */}
      <section className="py-16 px-4 md:px-8 lg:px-16 bg-white">
        <div className="container mx-auto">
          <SectionTitle
            title="Tanques em Polipropileno de Alta Performance"
            subtitle="Desenvolvidos para atender às mais exigentes demandas industriais com durabilidade e segurança."
            centered
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <ScrollAnimation animation="animate-fadeInRight">
                <p className="text-lg text-gray-700 mb-6">
                  A LJ Santos desenvolve e fabrica tanques em polipropileno (PP) de alta qualidade, projetados para
                  atender às mais exigentes demandas industriais. Nossos tanques são ideais para armazenamento e
                  processamento de produtos químicos agressivos, efluentes industriais e água tratada.
                </p>
                <p className="text-lg text-gray-700 mb-6">
                  O polipropileno é um material termoplástico com excelente resistência química, especialmente contra
                  ácidos, bases e solventes, tornando-o a escolha ideal para aplicações onde a resistência à corrosão é
                  fundamental.
                </p>

                <div className="grid grid-cols-2 gap-6 mt-8">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <AnimatedCounter end={25} suffix="+" className="text-3xl text-green-600" />
                    <p className="text-gray-700">Anos de experiência</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <AnimatedCounter end={5000} suffix="+" className="text-3xl text-green-600" />
                    <p className="text-gray-700">Tanques instalados</p>
                  </div>
                </div>
              </ScrollAnimation>
            </div>

            <ScrollAnimation animation="animate-fadeInLeft">
              <ImageCarousel images={carouselImages.slice(0, 4)} autoPlay={true} interval={4000} aspectRatio="video" />
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Características e Benefícios */}
      <section className="py-16 px-4 md:px-8 lg:px-16 bg-gray-50">
        <div className="container mx-auto">
          <SectionTitle
            title="Características e Benefícios"
            subtitle="Nossos tanques em polipropileno oferecem vantagens significativas em comparação com tanques convencionais."
            centered
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Alta Resistência Química</h3>
                <p className="text-gray-600">
                  Excelente resistência a ácidos, bases, sais e solventes orgânicos, permitindo o armazenamento seguro
                  de produtos químicos agressivos.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Durabilidade Superior</h3>
                <p className="text-gray-600">
                  Vida útil prolongada mesmo em condições adversas, com excelente resistência ao impacto e à fadiga,
                  reduzindo custos de manutenção e substituição.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Peso Reduzido</h3>
                <p className="text-gray-600">
                  Significativamente mais leves que tanques metálicos ou de concreto, facilitando o transporte,
                  instalação e reduzindo custos estruturais.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Personalização Total</h3>
                <p className="text-gray-600">
                  Fabricados sob medida com diferentes formatos, tamanhos, conexões e acessórios para atender às
                  necessidades específicas de cada aplicação.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Baixa Manutenção</h3>
                <p className="text-gray-600">
                  Não sofrem corrosão, não necessitam de pintura e são fáceis de limpar, resultando em custos
                  operacionais reduzidos ao longo da vida útil.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Excelente Custo-Benefício</h3>
                <p className="text-gray-600">
                  Combinação ideal de investimento inicial competitivo com baixos custos de manutenção e longa vida
                  útil, resultando em excelente retorno sobre o investimento.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Tipos de Tanques */}
      <section id="tipos" className="py-16 px-4 md:px-8 lg:px-16 bg-white">
        <div className="container mx-auto">
          <SectionTitle
            title="Tipos de Tanques em Polipropileno"
            subtitle="Oferecemos uma ampla variedade de tanques para atender às necessidades específicas de cada aplicação."
            centered
          />

          <div className="space-y-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <ScrollAnimation animation="animate-fadeInRight">
                <ImageCarousel images={horizontalTankImages} autoPlay={true} interval={5000} />
              </ScrollAnimation>

              <ScrollAnimation animation="animate-fadeInLeft">
                <div>
                  <h3 className="text-2xl font-semibold text-gray-800 mb-4">Tanques Horizontais</h3>
                  <p className="text-gray-600 mb-4">
                    Ideais para armazenamento de grandes volumes com limitação de altura. Disponíveis com ou sem berço
                    de sustentação, em diversos diâmetros e comprimentos.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Capacidades de 1.000 a 50.000 litros</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Opções com compartimentos internos</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Possibilidade de instalação subterrânea</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Conexões e acessórios personalizáveis</span>
                    </li>
                  </ul>

                  <CTAButton href="#contato" variant="outline" className="mt-6">
                    Solicitar Informações
                  </CTAButton>
                </div>
              </ScrollAnimation>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <ScrollAnimation animation="animate-fadeInRight" className="order-2 lg:order-1">
                <div>
                  <h3 className="text-2xl font-semibold text-gray-800 mb-4">Tanques Verticais</h3>
                  <p className="text-gray-600 mb-4">
                    Solução eficiente para otimização de espaço. Fabricados com fundo plano, cônico ou inclinado, com ou
                    sem tampa, de acordo com a aplicação.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Capacidades de 100 a 25.000 litros</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Opções com escadas e plataformas de acesso</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Sistemas de agitação e mistura</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Indicadores de nível e controles automatizados</span>
                    </li>
                  </ul>

                  <CTAButton href="#contato" variant="outline" className="mt-6">
                    Solicitar Informações
                  </CTAButton>
                </div>
              </ScrollAnimation>

              <ScrollAnimation animation="animate-fadeInLeft" className="order-1 lg:order-2">
                <ImageCarousel images={verticalTankImages} autoPlay={true} interval={5000} />
              </ScrollAnimation>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <ScrollAnimation animation="animate-fadeInRight">
                <ImageCarousel images={processTankImages.concat(specialTankImages)} autoPlay={true} interval={5000} />
              </ScrollAnimation>

              <ScrollAnimation animation="animate-fadeInLeft">
                <div>
                  <h3 className="text-2xl font-semibold text-gray-800 mb-4">Tanques de Processo e Especiais</h3>
                  <p className="text-gray-600 mb-4">
                    Projetados para processos químicos específicos, como neutralização, floculação, decantação e reações
                    químicas controladas. Também oferecemos soluções customizadas para aplicações especiais.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Sistemas completos com instrumentação</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Tanques com defletores internos e divisórias</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Sistemas de filtração integrados</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Projetos especiais conforme necessidade</span>
                    </li>
                  </ul>

                  <CTAButton href="#contato" variant="outline" className="mt-6">
                    Solicitar Informações
                  </CTAButton>
                </div>
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      {/* Especificações Técnicas */}
      <section id="especificacoes" className="py-16 px-4 md:px-8 lg:px-16 bg-gray-50">
        <div className="container mx-auto">
          <SectionTitle
            title="Especificações Técnicas"
            subtitle="Nossos tanques em polipropileno são fabricados seguindo rigorosos padrões de qualidade."
            centered
          />

          <ScrollAnimation animation="animate-fadeInUp">
            <div className="overflow-x-auto bg-white rounded-xl shadow-lg">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-green-700 text-white">
                    <th className="p-4 text-left rounded-tl-xl">Característica</th>
                    <th className="p-4 text-left">Especificação</th>
                    <th className="p-4 text-left rounded-tr-xl">Observações</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Material</td>
                    <td className="p-4">Polipropileno (PP) virgem</td>
                    <td className="p-4">Grau industrial, com aditivos UV quando necessário</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Espessura da parede</td>
                    <td className="p-4">6mm a 25mm</td>
                    <td className="p-4">Varia conforme dimensões e aplicação</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Temperatura de operação</td>
                    <td className="p-4">0°C a 90°C</td>
                    <td className="p-4">Consulte para aplicações com temperaturas específicas</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Resistência química</td>
                    <td className="p-4">Ácidos, bases, sais e solventes</td>
                    <td className="p-4">Consulte tabela de compatibilidade química específica</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Capacidades disponíveis</td>
                    <td className="p-4">100L a 50.000L</td>
                    <td className="p-4">Volumes maiores sob consulta</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Métodos de fabricação</td>
                    <td className="p-4">Soldagem por extrusão e termofusão</td>
                    <td className="p-4">Conforme normas internacionais</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Conexões</td>
                    <td className="p-4">Flanges, roscas, bocais</td>
                    <td className="p-4">Em PP, PVDF ou outros materiais compatíveis</td>
                  </tr>
                  <tr className="hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium rounded-bl-xl">Normas aplicáveis</td>
                    <td className="p-4">ASTM, DVS, ISO</td>
                    <td className="p-4 rounded-br-xl">Certificações disponíveis mediante solicitação</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Call to Action */}
      <section id="contato" className="py-16 bg-green-700 text-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <ScrollAnimation animation="animate-fadeInUp">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Precisa de tanques em polipropileno para sua indústria?
              </h2>
              <p className="text-xl mb-8">
                Entre em contato conosco para desenvolvermos uma solução personalizada que atenda às suas necessidades
                específicas.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <CTAButton
                  href="/solicite-orcamento"
                  variant="primary"
                  className="bg-white text-green-700 hover:bg-gray-100"
                >
                  Solicitar Orçamento
                </CTAButton>
                <CTAButton
                  href="tel:+551140028922"
                  variant="outline"
                  className="border-white text-white hover:bg-white/20"
                >
                  Fale Conosco
                </CTAButton>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
