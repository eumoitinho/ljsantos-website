import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle } from "lucide-react"

export default function ZincagemEletrolitica() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-[#435a52] mb-6">Zincagem Eletrolítica</h1>
              <p className="text-lg text-gray-700 mb-8">
                Proteção anticorrosiva de alta qualidade para componentes metálicos, garantindo durabilidade e
                resistência.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/solicite-orcamento"
                  className="request-button inline-block rounded-xl hover:shadow-lg transition-all duration-300"
                >
                  Solicite um orçamento
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Visão Geral */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">
                  Zincagem Eletrolítica de Alta Performance
                </h2>
                <p className="text-gray-700 mb-4">
                  A zincagem eletrolítica é um processo de revestimento que aplica uma camada de zinco sobre superfícies
                  metálicas através de eletrodeposição, oferecendo excelente proteção contra corrosão e um acabamento
                  estético superior.
                </p>
                <p className="text-gray-700 mb-4">
                  Na LJ Santos, utilizamos tecnologia de ponta e processos rigorosamente controlados para garantir
                  revestimentos uniformes, aderentes e de alta qualidade, atendendo às mais exigentes normas técnicas e
                  ambientais.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/zincagem-4.png"
                  alt="Linha de Zincagem Eletrolítica LJ Santos"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Características e Benefícios */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Características e Benefícios
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Proteção Anticorrosiva</h3>
                <p className="text-gray-700">
                  Excelente resistência à corrosão, prolongando significativamente a vida útil dos componentes
                  metálicos.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Acabamento Uniforme</h3>
                <p className="text-gray-700">
                  Revestimento homogêneo e controlado, garantindo espessura uniforme em toda a superfície da peça.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Versatilidade</h3>
                <p className="text-gray-700">
                  Aplicável a uma ampla variedade de peças e componentes, desde pequenos parafusos até estruturas
                  maiores.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Passivação Colorida</h3>
                <p className="text-gray-700">
                  Opções de passivação azul, amarela, preta ou transparente, atendendo a diferentes requisitos estéticos
                  e técnicos.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Conformidade Ambiental</h3>
                <p className="text-gray-700">
                  Processos livres de cromo hexavalente, atendendo às normas ambientais mais rigorosas, incluindo RoHS e
                  REACH.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Controle de Qualidade</h3>
                <p className="text-gray-700">
                  Rigoroso controle de qualidade em todas as etapas do processo, garantindo resultados consistentes e
                  confiáveis.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Processo de Zincagem */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Processo de Zincagem Eletrolítica
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <ol className="space-y-6">
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">1</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-[#435a52] mb-2">Preparação da Superfície</h3>
                      <p className="text-gray-700">
                        Limpeza, desengraxe e decapagem para remover impurezas e garantir aderência perfeita do
                        revestimento.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">2</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-[#435a52] mb-2">Eletrodeposição</h3>
                      <p className="text-gray-700">
                        Imersão das peças em banho eletrolítico contendo sais de zinco, onde ocorre a deposição
                        controlada do metal.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">3</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-[#435a52] mb-2">Passivação</h3>
                      <p className="text-gray-700">
                        Tratamento químico que aumenta a resistência à corrosão e pode conferir diferentes colorações ao
                        revestimento.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">4</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-[#435a52] mb-2">Secagem e Finalização</h3>
                      <p className="text-gray-700">
                        Secagem controlada e inspeção final para garantir a qualidade do revestimento e o atendimento às
                        especificações.
                      </p>
                    </div>
                  </li>
                </ol>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/zincagem-2.png"
                  alt="Linha de Zincagem Eletrolítica"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Galeria de Imagens */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Nossa Infraestrutura
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <Image
                  src="/images/zincagem-1.png"
                  alt="Tambor rotativo para zincagem de pequenas peças"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
                <p className="mt-4 text-center text-gray-700">
                  Tambor rotativo para zincagem de pequenas peças em massa
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/zincagem-3.png"
                  alt="Sistema de tambor para zincagem eletrolítica"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
                <p className="mt-4 text-center text-gray-700">
                  Detalhe do sistema de tambor para zincagem eletrolítica
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Aplicações */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Aplicações</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Indústria Automotiva</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Componentes de fixação</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Peças estruturais</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Sistemas de freio</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Construção Civil</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Parafusos e porcas</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Suportes e fixadores</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Elementos estruturais</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Eletrodomésticos</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Componentes internos</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Elementos de fixação</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Peças estruturais</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Precisa de zincagem eletrolítica de alta qualidade?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Entre em contato conosco para uma avaliação personalizada e descubra como nossos serviços de zincagem
              podem atender às necessidades da sua empresa.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Solicite um orçamento
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      <Footer />
    </main>
  )
}
