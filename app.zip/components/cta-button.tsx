import type React from "react"
import Link from "next/link"

interface CTAButtonProps {
  href: string
  variant?: "primary" | "outline" | "ghost"
  className?: string
  children: React.ReactNode
}

const CTAButton: React.FC<CTAButtonProps> = ({ href, variant = "primary", className = "", children }) => {
  const baseClasses = "inline-flex items-center justify-center px-6 py-3 rounded-md font-medium transition-all"

  const variantClasses = {
    primary: "bg-green-600 text-white hover:bg-green-700",
    outline: "border border-green-600 text-green-600 hover:bg-green-50",
    ghost: "text-green-600 hover:bg-green-50",
  }

  const classes = `${baseClasses} ${variantClasses[variant]} ${className}`

  return (
    <Link href={href} className={classes}>
      {children}
    </Link>
  )
}

export default CTAButton
