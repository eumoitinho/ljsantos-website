import Image from "next/image"
import Link from "next/link"
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin } from "lucide-react"

const Footer = () => {
  return (
    <footer className="bg-[rgb(68,139,19)] text-white">
      <div className="container mx-auto px-6 pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div className="flex flex-col items-center md:items-start">
            <Image src="/logo-white.png" alt="Santos Logo" width={262} height={75} className="h-16 w-auto mb-6" />
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-6">Links rápidos</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="hover:text-[#e6d54f] transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/quem-somos" className="hover:text-[#e6d54f] transition-colors">
                  Quem Somos
                </Link>
              </li>
              <li>
                <Link href="/solucoes" className="hover:text-[#e6d54f] transition-colors">
                  Soluções
                </Link>
              </li>
              <li>
                <Link href="/cases" className="hover:text-[#e6d54f] transition-colors">
                  Cases
                </Link>
              </li>
              <li>
                <Link href="/blog" className="hover:text-[#e6d54f] transition-colors">
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-6">Contato</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <Phone className="w-5 h-5 mr-3 mt-1 text-white" />
                <a href="tel:+554734275414" className="hover:text-[#e6d54f] transition-colors">
                  (47) 34275414
                </a>
              </li>
              <li className="flex items-start">
                <Mail className="w-5 h-5 mr-3 mt-1 text-white" />
                <span>comercial@ljsantos.ind.br</span>
              </li>
              <li className="flex items-start">
                <MapPin className="w-5 h-5 mr-3 mt-1 text-white" />
                <a
                  href="https://www.google.com/maps/place/R.+Ver.+Guilherme+Zuege,+1220+-+Centro+(Pirabeiraba),+Joinville+-+SC"
                  className="hover:text-[#e6d54f] transition-colors"
                >
                  Rua Vereador Guilherme Zuege, 1220 • Pirabeiraba • 89239-300 • Joinville • SC
                </a>
              </li>
            </ul>

            <div className="flex space-x-4 mt-6">
              <a
                href="https://www.facebook.com/people/L-J-Santos-Soluções-Industriais-Ltda/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#435a52] p-2 rounded-full hover:bg-[#e6d54f] transition-colors"
              >
                <Facebook className="w-5 h-5 text-white" />
              </a>
              <a
                href="https://www.instagram.com/ljsantos.ind/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#435a52] p-2 rounded-full hover:bg-[#e6d54f] transition-colors"
              >
                <Instagram className="w-5 h-5 text-white" />
              </a>
              <a
                href="https://www.linkedin.com/company/l-j-santos-soluções-industriais/"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-[#435a52] p-2 rounded-full hover:bg-[#e6d54f] transition-colors"
              >
                <Linkedin className="w-5 h-5 text-white" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-6 text-center">
          <p className="text-sm text-gray-400">
            Copyright © {new Date().getFullYear()}{" "}
            <a href="https://ljsantos.ind.br/" className="text-white hover:text-[#e6d54f]">
              LJ Santos Soluções Industriais
            </a>
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
