"use client"

import { useEffect, useState } from "react"
import ScrollAnimation from "@/components/scroll-animation"

const HeroSection = () => {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  return (
    <section className="relative h-screen flex items-center justify-center">
      <video className="hero-video" autoPlay muted loop playsInline>
        <source src="https://ljsantos.com/wp-content/uploads/2024/02/Home-Site-LJ-Santos.mp4" type="video/mp4" />
      </video>
      <div className="hero-overlay"></div>

      <div className="container mx-auto px-6 text-center z-10">
        <div className={`transition-opacity duration-1000 ${isLoaded ? "opacity-100" : "opacity-0"}`}>
          <ScrollAnimation animation="animate-fadeInUp">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-8 max-w-4xl mx-auto">
              Soluções industriais sustentáveis de qualidade e confiança comprovada
            </h1>
          </ScrollAnimation>
          <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
            <a
              href="/solicite-orcamento"
              className="inline-block bg-white text-[#435a52] font-bold py-3 px-6 rounded-md hover:bg-gray-100 transition-colors"
            >
              Solicite um orçamento hoje
            </a>
          </ScrollAnimation>
        </div>
      </div>
    </section>
  )
}

export default HeroSection
