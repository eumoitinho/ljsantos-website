import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.json()

    // Log the form data for debugging
    console.log("Form data received:", formData)

    // Send to RD Station
    const rdStationResponse = await sendToRDStation(formData)

    // Send to Google Sheets
    const googleSheetsResponse = await sendToGoogleSheets(formData)

    return NextResponse.json({
      success: true,
      rdStation: rdStationResponse,
      googleSheets: googleSheetsResponse,
    })
  } catch (error) {
    console.error("Error processing form submission:", error)
    return NextResponse.json({ success: false, error: "Failed to process form submission" }, { status: 500 })
  }
}

async function sendToRDStation(formData: any) {
  try {
    // RD Station API endpoint
    const rdStationEndpoint = "https://api.rd.services/platform/conversions"

    // Format data for RD Station
    const rdStationData = {
      event_type: "CONVERSION",
      event_family: "CDP",
      payload: {
        conversion_identifier: "formulario-contato-site",
        name: formData.name,
        email: formData.email,
        company_name: formData.company,
        job_title: formData.job,
        personal_phone: formData.phone,
        cf_message: formData.message,
        cf_product_interest: formData.product,
        cf_source: "website",
        legal_bases: [
          {
            category: "communications",
            type: "consent",
            status: "granted",
          },
        ],
      },
    }

    // RD Station API key
    const rdStationApiKey = process.env.RD_STATION_API_KEY || ""

    const response = await fetch(rdStationEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${rdStationApiKey}`,
      },
      body: JSON.stringify(rdStationData),
    })

    const responseData = await response.json()
    return { success: response.ok, data: responseData }
  } catch (error) {
    console.error("Error sending to RD Station:", error)
    return { success: false, error: "Failed to send to RD Station" }
  }
}

async function sendToGoogleSheets(formData: any) {
  try {
    // Format data for Google Sheets
    const timestamp = new Date().toISOString()

    // Google Sheets Web App URL (from Google Apps Script)
    const googleSheetsUrl = process.env.GOOGLE_SHEETS_URL || ""

    // Prepare data for Google Sheets
    const params = new URLSearchParams({
      timestamp,
      name: formData.name || "",
      email: formData.email || "",
      phone: formData.phone || "",
      company: formData.company || "",
      job: formData.job || "",
      product: formData.product || "",
      message: formData.message || "",
      source: "website",
    })

    // Send data to Google Sheets via GET request to the Web App URL
    const response = await fetch(`${googleSheetsUrl}?${params.toString()}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    const responseText = await response.text()
    return { success: response.ok, data: responseText }
  } catch (error) {
    console.error("Error sending to Google Sheets:", error)
    return { success: false, error: "Failed to send to Google Sheets" }
  }
}
