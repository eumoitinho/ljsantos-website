import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Droplets, Recycle, Shield, BarChart, Settings } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Effluent Treatment Stations | LJ Santos",
  description:
    "Complete and efficient solutions for industrial effluent treatment, ensuring environmental compliance and resource savings.",
  keywords: "effluent treatment station, ETS, industrial effluent treatment, batch system, continuous system",
}

export default function EnglishTreatmentStations() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-50"></div>
          <Image
            src="/images/estacao-tratamento-hero.jpg"
            alt="Effluent Treatment Stations"
            fill
            className="object-cover"
            priority
          />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Effluent Treatment Stations</h1>
              <p className="text-lg text-white mb-8">
                Complete and efficient solutions for industrial effluent treatment, ensuring environmental compliance
                and resource savings.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/en/solicite-orcamento"
                  className="inline-block bg-[#448b13] text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:bg-[#3a7510]"
                >
                  Request a quote
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">High-Efficiency Effluent Treatment</h2>
                <p className="text-gray-700 mb-4">
                  LJ Santos develops Effluent Treatment Stations (ETSs) with high technology and efficiency, designed to
                  meet the specific needs of each client and ensure compliance with current environmental standards.
                </p>
                <p className="text-gray-700 mb-4">
                  We offer two main treatment systems: the Batch system and the Continuous system. Each has specific
                  characteristics that make them more suitable for different applications and effluent volumes.
                </p>
                <p className="text-gray-700">
                  Our solutions are developed with a focus on sustainability, operational efficiency, and ease of
                  maintenance, ensuring the best cost-benefit for our customers.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="rounded-2xl overflow-hidden shadow-lg">
                <Image
                  src="/images/estacao-tratamento-hero.jpg"
                  alt="LJ Santos Effluent Treatment Stations"
                  width={600}
                  height={400}
                  className="w-full h-auto object-cover"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Redesigned Systems Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-12 text-center">Discover Our Systems</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Batch System Card */}
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden transition-transform duration-300 hover:shadow-xl hover:-translate-y-2">
                <div className="relative h-64">
                  <Image src="/images/estacao-batelada-1.jpeg" alt="Batch System" fill className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <h3 className="text-2xl font-bold text-white p-6">Batch System</h3>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-700 mb-6">
                    The Batch treatment system operates in complete cycles, treating specific batches of effluents. This
                    method allows precise control of each stage of the process, from equalization to final
                    clarification.
                  </p>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-[#f2f7f5] p-4 rounded-lg">
                      <h4 className="font-semibold text-[#435a52] mb-2">Ideal for</h4>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Smaller volumes of effluents</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">High variability of characteristics</span>
                        </li>
                      </ul>
                    </div>
                    <div className="bg-[#f2f7f5] p-4 rounded-lg">
                      <h4 className="font-semibold text-[#435a52] mb-2">Advantages</h4>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Precise control by batch</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">High operational flexibility</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="flex space-x-2">
                      <Image
                        src="/images/estacao-batelada-2.jpeg"
                        alt="Batch System Detail"
                        width={60}
                        height={60}
                        className="rounded-md object-cover"
                      />
                      <Image
                        src="/images/estacao-batelada-3.jpeg"
                        alt="Batch System Detail"
                        width={60}
                        height={60}
                        className="rounded-md object-cover"
                      />
                      <Image
                        src="/images/estacao-batelada-4.png"
                        alt="Batch System Detail"
                        width={60}
                        height={60}
                        className="rounded-md object-cover"
                      />
                    </div>
                    <Link
                      href="/en/estacao-batelada"
                      className="inline-flex items-center text-[#448b13] font-semibold hover:text-[#3a7510] transition-colors"
                    >
                      Learn more
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 ml-1"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              </div>
            </ScrollAnimation>

            {/* Continuous System Card */}
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden transition-transform duration-300 hover:shadow-xl hover:-translate-y-2">
                <div className="relative h-64">
                  <Image src="/images/estacao-continua-1.jpeg" alt="Continuous System" fill className="object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <h3 className="text-2xl font-bold text-white p-6">Continuous System</h3>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-700 mb-6">
                    The Continuous treatment system operates uninterruptedly, receiving and treating effluents
                    constantly. This method is ideal for industrial processes that generate effluents continuously and
                    in large volumes.
                  </p>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-[#f2f7f5] p-4 rounded-lg">
                      <h4 className="font-semibold text-[#435a52] mb-2">Ideal for</h4>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Large volumes of effluents</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Continuous industrial processes</span>
                        </li>
                      </ul>
                    </div>
                    <div className="bg-[#f2f7f5] p-4 rounded-lg">
                      <h4 className="font-semibold text-[#435a52] mb-2">Advantages</h4>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Uninterrupted operation</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Greater treatment capacity</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="flex justify-between items-center">
                    <div className="flex space-x-2">
                      <Image
                        src="/images/estacao-continua-2.png"
                        alt="Continuous System Detail"
                        width={60}
                        height={60}
                        className="rounded-md object-cover"
                      />
                      <Image
                        src="/images/estacao-continua-3.png"
                        alt="Continuous System Detail"
                        width={60}
                        height={60}
                        className="rounded-md object-cover"
                      />
                      <Image
                        src="/images/estacao-continua-4.png"
                        alt="Continuous System Detail"
                        width={60}
                        height={60}
                        className="rounded-md object-cover"
                      />
                    </div>
                    <Link
                      href="/en/estacao-continua"
                      className="inline-flex items-center text-[#448b13] font-semibold hover:text-[#3a7510] transition-colors"
                    >
                      Learn more
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 ml-1"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>

          {/* Comparison Table */}
          <div className="mt-16">
            <ScrollAnimation animation="animate-fadeInUp">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className="p-6 bg-[#435a52] text-white">
                  <h3 className="text-xl font-bold">System Comparison</h3>
                  <p className="text-white/80 mt-1">Choose the ideal system for your needs</p>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="text-left p-4 font-semibold text-[#435a52]">Characteristics</th>
                        <th className="text-center p-4 font-semibold text-[#435a52]">Batch System</th>
                        <th className="text-center p-4 font-semibold text-[#435a52]">Continuous System</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-t border-gray-100">
                        <td className="p-4 font-medium">Effluent Volume</td>
                        <td className="p-4 text-center">Small to medium</td>
                        <td className="p-4 text-center">Medium to large</td>
                      </tr>
                      <tr className="border-t border-gray-100 bg-gray-50">
                        <td className="p-4 font-medium">Operation</td>
                        <td className="p-4 text-center">By cycles</td>
                        <td className="p-4 text-center">Uninterrupted</td>
                      </tr>
                      <tr className="border-t border-gray-100">
                        <td className="p-4 font-medium">Flexibility</td>
                        <td className="p-4 text-center">High</td>
                        <td className="p-4 text-center">Medium</td>
                      </tr>
                      <tr className="border-t border-gray-100 bg-gray-50">
                        <td className="p-4 font-medium">Process Control</td>
                        <td className="p-4 text-center">Precise by batch</td>
                        <td className="p-4 text-center">Constant</td>
                      </tr>
                      <tr className="border-t border-gray-100">
                        <td className="p-4 font-medium">Required Space</td>
                        <td className="p-4 text-center">Smaller</td>
                        <td className="p-4 text-center">Larger</td>
                      </tr>
                      <tr className="border-t border-gray-100 bg-gray-50">
                        <td className="p-4 font-medium">Energy Consumption</td>
                        <td className="p-4 text-center">Intermittent</td>
                        <td className="p-4 text-center">Constant</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center">Common Benefits</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <Droplets className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Water Savings</h3>
                <p className="text-gray-700">
                  Possibility of reusing treated water, reducing water resource consumption and operational costs.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <Shield className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Legal Compliance</h3>
                <p className="text-gray-700">
                  Guarantee of compliance with current environmental legislation, avoiding fines and penalties.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <Recycle className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Sustainability</h3>
                <p className="text-gray-700">
                  Contribution to environmental preservation and to the company's sustainable image.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <Settings className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Advanced Automation</h3>
                <p className="text-gray-700">
                  Automated systems that ensure precision, repeatability, and less need for manual intervention.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <BarChart className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">High Efficiency</h3>
                <p className="text-gray-700">
                  High efficiency in contaminant removal, ensuring compliance with discharge standards.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <CheckCircle className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Customization</h3>
                <p className="text-gray-700">
                  Custom projects according to the specific needs of each client and type of effluent.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Which system is ideal for your company?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Contact us for a personalized assessment and discover which effluent treatment system is most suitable for
              your company's needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/en/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Request a quote
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </main>
  )
}
