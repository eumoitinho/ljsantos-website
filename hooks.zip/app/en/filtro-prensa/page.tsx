import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Filter, Droplets, Recycle, Settings, BarChart } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Filter Press | LJ Santos",
  description:
    "Efficient solutions for solid-liquid separation, ensuring high performance and operational economy for various industrial processes.",
  keywords: "filter press, solid-liquid separation, sludge dewatering, effluent treatment, industrial filtration",
}

export default function EnglishFilterPress() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-50"></div>
          <Image src="/images/filtro-prensa-3.png" alt="Filter Press" fill className="object-cover" priority />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Filter Press</h1>
              <p className="text-lg text-white mb-8">
                Efficient solutions for solid-liquid separation, ensuring high performance and operational economy for
                various industrial processes.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/en/solicite-orcamento"
                  className="inline-block bg-white text-[#435a52] font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:bg-gray-100"
                >
                  Request a quote
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">Advanced Filtration Technology</h2>
                <p className="text-gray-700 mb-4">
                  LJ Santos Filter Press is a high-efficiency equipment designed for the separation of solids and
                  liquids in various industrial processes. Using a system of plates and frames, our filter press
                  provides high-performance filtration with low operational cost.
                </p>
                <p className="text-gray-700 mb-4">
                  Developed with high-quality materials and advanced technology, our filter press is ideal for
                  applications in effluent treatment, chemical industry, mining, electroplating, and other sectors that
                  require efficient sludge dewatering processes.
                </p>
                <p className="text-gray-700">
                  Each filter press is designed according to the specific needs of the client, ensuring the best
                  solution for each application and providing superior results in terms of efficiency and economy.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/filtro-prensa-3.png"
                  alt="LJ Santos Filter Press"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">How It Works</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <Image
                  src="/images/filtro-prensa-4.jpeg"
                  alt="Filter Press in Operation"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Operating Principle</h3>
                <p className="text-gray-700 mb-6">
                  The filter press operates by applying mechanical pressure on a suspension containing solids and
                  liquids, forcing the liquid to pass through filter plates while retaining the solids.
                </p>

                <h4 className="text-xl font-semibold text-[#435a52] mb-3">Process Stages</h4>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">1</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Feeding:</strong> The suspension is pumped into the filter press.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">2</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Filtration:</strong> The liquid passes through the filter plates, while the solids are
                      retained.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">3</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Compression:</strong> Pressure is maintained to maximize liquid removal.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">4</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Discharge:</strong> The plates are separated and the filter cake (solid material) is
                      removed.
                    </span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Main Components</h3>
                <p className="text-gray-700 mb-6">
                  Our filter presses are composed of high-quality components, designed to ensure durability and
                  operational efficiency.
                </p>

                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Filter Plates:</strong>
                      <p className="text-gray-700">
                        Made of high-strength polypropylene, with optimized design for maximum filtration efficiency.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Support Structure:</strong>
                      <p className="text-gray-700">
                        Built in carbon steel with epoxy paint or stainless steel, ensuring corrosion resistance and
                        durability.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Hydraulic System:</strong>
                      <p className="text-gray-700">
                        Provides the necessary pressure for closing and operating the filter, with automated controls
                        for greater safety.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Filter Cloths:</strong>
                      <p className="text-gray-700">
                        Available in different materials and openings, adapted to the specific needs of each
                        application.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="grid grid-cols-2 gap-4">
                <Image
                  src="/images/filtro-prensa-1.jpeg"
                  alt="Filter Plate"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/filtro-prensa-2.jpeg"
                  alt="Filter Plate Detail"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/filtro-prensa-5.png"
                  alt="Filter Cloths"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/filtro-prensa-6.png"
                  alt="Filter Press Structure"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Benefits and Advantages
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Filter className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">High Filtration Efficiency</h3>
                <p className="text-gray-700">
                  Provides efficient separation of solids and liquids, with the capacity to achieve up to 80% drying in
                  the filter cake.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Droplets className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Water Savings</h3>
                <p className="text-gray-700">
                  Allows recovery and reuse of filtered water, contributing to sustainability and reducing operational
                  costs.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Recycle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Waste Management</h3>
                <p className="text-gray-700">
                  Facilitates the handling and disposal of solid waste, reducing transportation and final disposal
                  costs.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Settings className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Automated Operation</h3>
                <p className="text-gray-700">
                  Systems with automated control that reduce the need for manual intervention and increase operational
                  safety.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <BarChart className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Low Operational Cost</h3>
                <p className="text-gray-700">
                  Lower energy consumption and chemical inputs compared to other dewatering systems, resulting in
                  significant savings.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <CheckCircle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Versatility</h3>
                <p className="text-gray-700">
                  Adaptable to different types of sludge and industrial applications, with the possibility of
                  customization to meet specific needs.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Applications</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Effluent Treatment</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Dewatering of treatment plant sludge</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Separation of solids in industrial effluents</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Water recovery for reuse</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Chemical Industry</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Filtration of chemical products</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recovery of raw materials</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Separation of crystals and precipitates</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Electroplating</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Treatment of effluents with heavy metals</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recovery of valuable metals</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Reduction of waste volume for disposal</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Mining</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Tailings dewatering</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Process water recovery</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Ore concentration</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Technical Specifications
            </h2>
          </ScrollAnimation>

          <ScrollAnimation animation="animate-zoomIn">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse serious-table rounded-xl overflow-hidden shadow-lg">
                <thead>
                  <tr>
                    <th className="text-left bg-[#435a52] text-white">Model</th>
                    <th className="text-center bg-[#435a52] text-white">Filtration Area</th>
                    <th className="text-center bg-[#435a52] text-white">Number of Plates</th>
                    <th className="text-center bg-[#435a52] text-white">Operating Pressure</th>
                    <th className="text-center bg-[#435a52] text-white">Capacity</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="font-medium">FP-400</td>
                    <td className="text-center">4 m²</td>
                    <td className="text-center">20</td>
                    <td className="text-center">Up to 10 bar</td>
                    <td className="text-center">100-200 kg/cycle</td>
                  </tr>
                  <tr>
                    <td className="font-medium">FP-800</td>
                    <td className="text-center">8 m²</td>
                    <td className="text-center">40</td>
                    <td className="text-center">Up to 12 bar</td>
                    <td className="text-center">200-400 kg/cycle</td>
                  </tr>
                  <tr>
                    <td className="font-medium">FP-1200</td>
                    <td className="text-center">12 m²</td>
                    <td className="text-center">60</td>
                    <td className="text-center">Up to 15 bar</td>
                    <td className="text-center">300-600 kg/cycle</td>
                  </tr>
                  <tr>
                    <td className="font-medium">FP-2000</td>
                    <td className="text-center">20 m²</td>
                    <td className="text-center">100</td>
                    <td className="text-center">Up to 15 bar</td>
                    <td className="text-center">500-1000 kg/cycle</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-sm text-gray-500 mt-4 text-center">
              * Specifications may vary according to the specific needs of each project.
            </p>
          </ScrollAnimation>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Request a Customized Filter Press</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Contact us for a personalized assessment and discover which Filter Press model is most suitable for your
              company's needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/en/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Request a quote
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </main>
  )
}
