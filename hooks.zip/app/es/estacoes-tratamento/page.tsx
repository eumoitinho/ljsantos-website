import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Droplets, Recycle, Shield, BarChart, Settings } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Estaciones de Tratamiento de Efluentes | LJ Santos",
  description:
    "Soluciones completas y eficientes para el tratamiento de efluentes industriales, garantizando el cumplimiento ambiental y el ahorro de recursos.",
  keywords:
    "estación de tratamiento de efluentes, ETE, tratamiento de efluentes industriales, sistema por lotes, sistema continuo",
}

export default function SpanishTreatmentStations() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-50"></div>
          <Image
            src="/images/estacao-tratamento-hero.jpg"
            alt="Estaciones de Tratamiento de Efluentes"
            fill
            className="object-cover"
            priority
          />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Estaciones de Tratamiento de Efluentes</h1>
              <p className="text-lg text-white mb-8">
                Soluciones completas y eficientes para el tratamiento de efluentes industriales, garantizando el
                cumplimiento ambiental y el ahorro de recursos.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/es/solicite-orcamento"
                  className="inline-block bg-white text-[#435a52] font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:bg-gray-100"
                >
                  Solicitar presupuesto
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">
                  Tratamiento de Efluentes de Alta Eficiencia
                </h2>
                <p className="text-gray-700 mb-4">
                  LJ Santos desarrolla Estaciones de Tratamiento de Efluentes (ETEs) con alta tecnología y eficiencia,
                  diseñadas para satisfacer las necesidades específicas de cada cliente y garantizar el cumplimiento de
                  las normas ambientales vigentes.
                </p>
                <p className="text-gray-700 mb-4">
                  Ofrecemos dos sistemas principales de tratamiento: el sistema por Lotes y el sistema Continuo. Cada
                  uno tiene características específicas que los hacen más adecuados para diferentes aplicaciones y
                  volúmenes de efluentes.
                </p>
                <p className="text-gray-700">
                  Nuestras soluciones se desarrollan con un enfoque en la sostenibilidad, la eficiencia operativa y la
                  facilidad de mantenimiento, garantizando el mejor costo-beneficio para nuestros clientes.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/estacao-tratamento-hero.jpg"
                  alt="Estaciones de Tratamiento de Efluentes LJ Santos"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Systems Comparison */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Conozca Nuestros Sistemas
            </h2>
          </ScrollAnimation>

          <Tabs defaultValue="batelada" className="w-full">
            <ScrollAnimation animation="animate-zoomIn">
              <TabsList className="grid w-full grid-cols-2 mb-8 bg-white shadow-lg rounded-xl overflow-hidden">
                <TabsTrigger
                  value="batelada"
                  className="text-lg py-4 data-[state=active]:bg-[#435a52] data-[state=active]:text-white transition-all duration-300"
                >
                  Sistema por Lotes
                </TabsTrigger>
                <TabsTrigger
                  value="continuo"
                  className="text-lg py-4 data-[state=active]:bg-[#435a52] data-[state=active]:text-white transition-all duration-300"
                >
                  Sistema Continuo
                </TabsTrigger>
              </TabsList>
            </ScrollAnimation>

            {/* Batelada Content */}
            <TabsContent value="batelada" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <ScrollAnimation animation="animate-fadeInRight">
                  <div>
                    <Image
                      src="/images/estacao-batelada-1.jpeg"
                      alt="Estación de Tratamiento por Lotes"
                      width={600}
                      height={400}
                      className="rounded-2xl shadow-lg"
                    />
                  </div>
                </ScrollAnimation>
                <ScrollAnimation animation="animate-fadeInLeft">
                  <div>
                    <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Sistema por Lotes</h3>
                    <p className="text-gray-700 mb-6">
                      El sistema de tratamiento por Lotes opera en ciclos completos, tratando lotes específicos de
                      efluentes. Este método permite un control preciso de cada etapa del proceso, desde la ecualización
                      hasta la clarificación final.
                    </p>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Etapas del Proceso</h4>
                    <ul className="space-y-3 mb-6">
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">1</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Ecualización:</strong> Homogeneización de los efluentes para garantizar uniformidad.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">2</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Reacción:</strong> Adición controlada de reactivos químicos para el tratamiento.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">3</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Floculación:</strong> Formación de flóculos para la separación de contaminantes.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">4</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Clarificación:</strong> Separación del agua tratada del lodo formado.
                        </span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Ideal para:</h4>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Volúmenes menores de efluentes</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Efluentes con alta variabilidad de características</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Procesos que requieren un control riguroso de cada lote</span>
                      </li>
                    </ul>
                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Galería de Imágenes</h4>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <Image
                        src="/images/estacao-batelada-2.jpeg"
                        alt="Estación por Lotes - Detalle 1"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-batelada-3.jpeg"
                        alt="Estación por Lotes - Detalle 2"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-batelada-4.png"
                        alt="Estación por Lotes - Detalle 3"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-batelada-5.jpeg"
                        alt="Estación por Lotes - Detalle 4"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                    </div>
                  </div>
                </ScrollAnimation>
              </div>
            </TabsContent>

            {/* Contínuo Content */}
            <TabsContent value="continuo" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <ScrollAnimation animation="animate-fadeInRight">
                  <div>
                    <Image
                      src="/images/estacao-continua-1.jpeg"
                      alt="Estación de Tratamiento Continua"
                      width={600}
                      height={400}
                      className="rounded-2xl shadow-lg"
                    />
                  </div>
                </ScrollAnimation>
                <ScrollAnimation animation="animate-fadeInLeft">
                  <div>
                    <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Sistema Continuo</h3>
                    <p className="text-gray-700 mb-6">
                      El sistema de tratamiento Continuo opera ininterrumpidamente, recibiendo y tratando los efluentes
                      de forma constante. Este método es ideal para procesos industriales que generan efluentes
                      continuamente y en grandes volúmenes.
                    </p>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Etapas del Proceso</h4>
                    <ul className="space-y-3 mb-6">
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">1</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Recepción continua:</strong> Entrada constante de efluentes en el sistema.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">2</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Tratamiento físico-químico:</strong> Adición automática de reactivos.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">3</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Decantación:</strong> Separación continua de sólidos y líquidos.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">4</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Descarte/reutilización:</strong> Salida constante de agua tratada.
                        </span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Ideal para:</h4>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Grandes volúmenes de efluentes</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Procesos industriales continuos</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Efluentes con características más constantes</span>
                      </li>
                    </ul>
                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Galería de Imágenes</h4>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <Image
                        src="/images/estacao-continua-2.png"
                        alt="Estación Continua - Detalle 1"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-continua-3.png"
                        alt="Estación Continua - Detalle 2"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-continua-4.png"
                        alt="Estación Continua - Detalle 3"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-continua-5.png"
                        alt="Estación Continua - Detalle 4"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                    </div>
                  </div>
                </ScrollAnimation>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Comparativa entre los Sistemas
            </h2>
          </ScrollAnimation>

          <ScrollAnimation animation="animate-zoomIn">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse serious-table rounded-xl overflow-hidden shadow-lg">
                <thead>
                  <tr>
                    <th className="text-left bg-[#435a52] text-white">Características</th>
                    <th className="text-center bg-[#435a52] text-white">Sistema por Lotes</th>
                    <th className="text-center bg-[#435a52] text-white">Sistema Continuo</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="font-medium">Volumen de Efluentes</td>
                    <td className="text-center">Pequeño a medio</td>
                    <td className="text-center">Medio a grande</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Operación</td>
                    <td className="text-center">Por ciclos</td>
                    <td className="text-center">Ininterrumpida</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Flexibilidad</td>
                    <td className="text-center">Alta</td>
                    <td className="text-center">Media</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Control de Proceso</td>
                    <td className="text-center">Preciso por lote</td>
                    <td className="text-center">Constante</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Espacio Necesario</td>
                    <td className="text-center">Menor</td>
                    <td className="text-center">Mayor</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Consumo de Energía</td>
                    <td className="text-center">Intermitente</td>
                    <td className="text-center">Constante</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Mantenimiento</td>
                    <td className="text-center">Más simple</td>
                    <td className="text-center">Más complejo</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Beneficios Comunes
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Droplets className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Ahorro de Agua</h3>
                <p className="text-gray-700">
                  Posibilidad de reutilización del agua tratada, reduciendo el consumo de recursos hídricos y los costos
                  operativos.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Shield className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Conformidad Legal</h3>
                <p className="text-gray-700">
                  Garantía de cumplimiento de la legislación ambiental vigente, evitando multas y sanciones.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Recycle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Sostenibilidad</h3>
                <p className="text-gray-700">
                  Contribución a la preservación del medio ambiente y a la imagen sostenible de la empresa.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Settings className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Automatización Avanzada</h3>
                <p className="text-gray-700">
                  Sistemas automatizados que garantizan precisión, repetibilidad y menor necesidad de intervención
                  manual.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <BarChart className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Alta Eficiencia</h3>
                <p className="text-gray-700">
                  Alta eficiencia en la eliminación de contaminantes, garantizando el cumplimiento de los estándares de
                  descarga.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <CheckCircle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Personalización</h3>
                <p className="text-gray-700">
                  Proyectos personalizados de acuerdo con las necesidades específicas de cada cliente y tipo de
                  efluente.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">¿Qué sistema es ideal para su empresa?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Contáctenos para una evaluación personalizada y descubra qué sistema de tratamiento de efluentes es más
              adecuado para las necesidades de su empresa.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/es/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Solicitar presupuesto
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </main>
  )
}
