import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Filter, Droplets, Recycle, Settings, BarChart } from "lucide-react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Filtro Prensa | LJ Santos",
  description:
    "Soluciones eficientes para la separación sólido-líquido, garantizando alto rendimiento y economía operativa para diversos procesos industriales.",
  keywords:
    "filtro prensa, separación sólido-líquido, deshidratación de lodos, tratamiento de efluentes, filtración industrial",
}

export default function SpanishFilterPress() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-50"></div>
          <Image src="/images/filtro-prensa-3.png" alt="Filtro Prensa" fill className="object-cover" priority />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Filtro Prensa</h1>
              <p className="text-lg text-white mb-8">
                Soluciones eficientes para la separación sólido-líquido, garantizando alto rendimiento y economía
                operativa para diversos procesos industriales.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/es/solicite-orcamento"
                  className="inline-block bg-white text-[#435a52] font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:bg-gray-100"
                >
                  Solicitar presupuesto
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">Tecnología Avanzada en Filtración</h2>
                <p className="text-gray-700 mb-4">
                  El Filtro Prensa de LJ Santos es un equipo de alta eficiencia diseñado para la separación de sólidos y
                  líquidos en diversos procesos industriales. Utilizando un sistema de placas y marcos, nuestro filtro
                  prensa proporciona una filtración de alto rendimiento con bajo costo operativo.
                </p>
                <p className="text-gray-700 mb-4">
                  Desarrollado con materiales de alta calidad y tecnología avanzada, nuestro filtro prensa es ideal para
                  aplicaciones en tratamiento de efluentes, industria química, minería, galvanoplastia y otros sectores
                  que requieren procesos eficientes de deshidratación de lodos.
                </p>
                <p className="text-gray-700">
                  Cada filtro prensa está diseñado de acuerdo con las necesidades específicas del cliente, garantizando
                  la mejor solución para cada aplicación y proporcionando resultados superiores en términos de
                  eficiencia y economía.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/filtro-prensa-3.png"
                  alt="Filtro Prensa LJ Santos"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Cómo Funciona</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <Image
                  src="/images/filtro-prensa-4.jpeg"
                  alt="Filtro Prensa en Operación"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Principio de Funcionamiento</h3>
                <p className="text-gray-700 mb-6">
                  El filtro prensa opera mediante la aplicación de presión mecánica sobre una suspensión que contiene
                  sólidos y líquidos, forzando al líquido a pasar a través de placas filtrantes mientras retiene los
                  sólidos.
                </p>

                <h4 className="text-xl font-semibold text-[#435a52] mb-3">Etapas del Proceso</h4>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">1</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Alimentación:</strong> La suspensión se bombea al interior del filtro prensa.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">2</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Filtración:</strong> El líquido pasa a través de las placas filtrantes, mientras los
                      sólidos quedan retenidos.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">3</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Compresión:</strong> Se mantiene la presión para maximizar la eliminación de líquidos.
                    </span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">4</span>
                    </div>
                    <span className="text-gray-700">
                      <strong>Descarga:</strong> Las placas se separan y la torta de filtro (material sólido) se retira.
                    </span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Componentes Principales</h3>
                <p className="text-gray-700 mb-6">
                  Nuestros filtros prensa están compuestos por componentes de alta calidad, diseñados para garantizar
                  durabilidad y eficiencia operativa.
                </p>

                <ul className="space-y-4">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Placas Filtrantes:</strong>
                      <p className="text-gray-700">
                        Fabricadas en polipropileno de alta resistencia, con diseño optimizado para máxima eficiencia de
                        filtración.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Estructura de Soporte:</strong>
                      <p className="text-gray-700">
                        Construida en acero al carbono con pintura epoxi o acero inoxidable, garantizando resistencia a
                        la corrosión y durabilidad.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Sistema Hidráulico:</strong>
                      <p className="text-gray-700">
                        Proporciona la presión necesaria para el cierre y operación del filtro, con controles
                        automatizados para mayor seguridad.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <div>
                      <strong className="text-[#435a52]">Telas Filtrantes:</strong>
                      <p className="text-gray-700">
                        Disponibles en diferentes materiales y aperturas, adaptadas a las necesidades específicas de
                        cada aplicación.
                      </p>
                    </div>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="grid grid-cols-2 gap-4">
                <Image
                  src="/images/filtro-prensa-1.jpeg"
                  alt="Placa Filtrante"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/filtro-prensa-2.jpeg"
                  alt="Detalle de Placa Filtrante"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/filtro-prensa-5.png"
                  alt="Telas Filtrantes"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
                <Image
                  src="/images/filtro-prensa-6.png"
                  alt="Estructura del Filtro Prensa"
                  width={300}
                  height={300}
                  className="rounded-lg shadow-md"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Beneficios y Ventajas
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Filter className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Alta Eficiencia de Filtración</h3>
                <p className="text-gray-700">
                  Proporciona una separación eficiente de sólidos y líquidos, con capacidad para alcanzar hasta un 80%
                  de secado en la torta de filtro.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Droplets className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Ahorro de Agua</h3>
                <p className="text-gray-700">
                  Permite la recuperación y reutilización del agua filtrada, contribuyendo a la sostenibilidad y
                  reducción de costos operativos.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Recycle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Gestión de Residuos</h3>
                <p className="text-gray-700">
                  Facilita el manejo y disposición de los residuos sólidos, reduciendo costos de transporte y
                  disposición final.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Settings className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Operación Automatizada</h3>
                <p className="text-gray-700">
                  Sistemas con control automatizado que reducen la necesidad de intervención manual y aumentan la
                  seguridad operativa.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <BarChart className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Bajo Costo Operativo</h3>
                <p className="text-gray-700">
                  Menor consumo de energía e insumos químicos en comparación con otros sistemas de deshidratación,
                  resultando en un ahorro significativo.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <CheckCircle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Versatilidad</h3>
                <p className="text-gray-700">
                  Adaptable a diferentes tipos de lodo y aplicaciones industriales, con posibilidad de personalización
                  para satisfacer necesidades específicas.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Aplicaciones</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Tratamiento de Efluentes</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Deshidratación de lodos de plantas de tratamiento</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Separación de sólidos en efluentes industriales</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recuperación de agua para reutilización</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Industria Química</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Filtración de productos químicos</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recuperación de materias primas</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Separación de cristales y precipitados</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInRight">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Galvanoplastia</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Tratamiento de efluentes con metales pesados</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recuperación de metales valiosos</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Reducción del volumen de residuos para disposición</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="serious-card p-6 rounded-xl">
                <h3 className="text-xl font-semibold text-[#435a52] mb-4">Minería</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Deshidratación de relaves</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Recuperación de agua de proceso</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Concentración de minerales</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Especificaciones Técnicas
            </h2>
          </ScrollAnimation>

          <ScrollAnimation animation="animate-zoomIn">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse serious-table rounded-xl overflow-hidden shadow-lg">
                <thead>
                  <tr>
                    <th className="text-left bg-[#435a52] text-white">Modelo</th>
                    <th className="text-center bg-[#435a52] text-white">Área de Filtración</th>
                    <th className="text-center bg-[#435a52] text-white">Número de Placas</th>
                    <th className="text-center bg-[#435a52] text-white">Presión de Operación</th>
                    <th className="text-center bg-[#435a52] text-white">Capacidad</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="font-medium">FP-400</td>
                    <td className="text-center">4 m²</td>
                    <td className="text-center">20</td>
                    <td className="text-center">Hasta 10 bar</td>
                    <td className="text-center">100-200 kg/ciclo</td>
                  </tr>
                  <tr>
                    <td className="font-medium">FP-800</td>
                    <td className="text-center">8 m²</td>
                    <td className="text-center">40</td>
                    <td className="text-center">Hasta 12 bar</td>
                    <td className="text-center">200-400 kg/ciclo</td>
                  </tr>
                  <tr>
                    <td className="font-medium">FP-1200</td>
                    <td className="text-center">12 m²</td>
                    <td className="text-center">60</td>
                    <td className="text-center">Hasta 15 bar</td>
                    <td className="text-center">300-600 kg/ciclo</td>
                  </tr>
                  <tr>
                    <td className="font-medium">FP-2000</td>
                    <td className="text-center">20 m²</td>
                    <td className="text-center">100</td>
                    <td className="text-center">Hasta 15 bar</td>
                    <td className="text-center">500-1000 kg/ciclo</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-sm text-gray-500 mt-4 text-center">
              * Las especificaciones pueden variar según las necesidades específicas de cada proyecto.
            </p>
          </ScrollAnimation>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Solicite un Filtro Prensa Personalizado</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Contáctenos para una evaluación personalizada y descubra qué modelo de Filtro Prensa es más adecuado para
              las necesidades de su empresa.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/es/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Solicitar presupuesto
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </main>
  )
}
