import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"

export default function SpanishHome() {
  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center">
        <video className="hero-video absolute inset-0 w-full h-full object-cover" autoPlay muted loop playsInline>
          <source src="https://ljsantos.com/wp-content/uploads/2024/02/Home-Site-LJ-Santos.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-black opacity-50"></div>

        <div className="container mx-auto px-6 text-center z-10">
          <ScrollAnimation animation="animate-fadeInUp">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-8 max-w-4xl mx-auto">
              Soluciones industriales sostenibles de calidad y confianza comprobada
            </h1>
          </ScrollAnimation>
          <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
            <Link
              href="/es/solicite-orcamento"
              className="inline-block bg-white text-[#435a52] font-bold py-3 px-6 rounded-xl hover:bg-gray-100 transition-all duration-300 hover:shadow-lg"
            >
              Solicite un presupuesto hoy
            </Link>
          </ScrollAnimation>
        </div>
      </section>

      {/* Trusted Brands Section */}
      <ScrollAnimation animation="animate-fadeInUp">
        <section className="py-12 bg-[#0e3b7c]">
          <div className="container mx-auto px-6">
            <div className="text-center mb-8">
              <p className="text-white text-xl font-medium">Marcas que confían</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 justify-items-center">
              <Image
                src="/brands/copacol.png"
                alt="Copacol"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/benteler.png"
                alt="Benteler"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/facchini.png"
                alt="Facchini"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/randon.png"
                alt="Randon"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/erzinger.png"
                alt="Erzinger"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/mahle.png"
                alt="Mahle"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
            </div>
          </div>
        </section>
      </ScrollAnimation>

      {/* Products Section */}
      <ScrollAnimation animation="animate-fadeInUp">
        <section className="py-16 bg-[#f2f7f5]">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <ScrollAnimation animation="animate-fadeInRight">
                <div>
                  <h2 className="text-3xl font-bold text-[#435a52] section-title">Conozca nuestros productos</h2>
                </div>
              </ScrollAnimation>

              <ScrollAnimation animation="animate-fadeInLeft">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Estaciones de Tratamiento de Efluentes</p>
                    <Link
                      href="/es/estacoes-tratamento"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Saber más
                    </Link>
                  </div>
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Tanques de Polipropileno</p>
                    <Link
                      href="/es/tanques-polipropileno"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Saber más
                    </Link>
                  </div>
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Filtro Prensa</p>
                    <Link
                      href="/es/filtro-prensa"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Saber más
                    </Link>
                  </div>
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Líneas de Galvanizado Electrolítico</p>
                    <Link
                      href="/es/zincagem"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Saber más
                    </Link>
                  </div>
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Líneas de Cromado</p>
                    <Link
                      href="/es/linha-de-cromagem"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Saber más
                    </Link>
                  </div>
                </div>
              </ScrollAnimation>
            </div>
          </div>
        </section>
      </ScrollAnimation>

      {/* Call to Action */}
      <ScrollAnimation animation="animate-zoomIn">
        <section
          className="relative py-24 bg-cover bg-center"
          style={{ backgroundImage: "url('/images/cta-background.png')" }}
        >
          <div className="absolute inset-0 bg-[#435a52] opacity-80"></div>

          <div className="container mx-auto px-6 relative z-10 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-8 max-w-4xl mx-auto">
              Nuestra experiencia e innovación nos convierten en la elección correcta para el tratamiento de efluentes
              industriales
            </h2>

            <Link
              href="/es/solicite-orcamento"
              className="cta-button inline-block rounded-xl hover:shadow-lg transition-all duration-300"
            >
              Solicite un presupuesto hoy
            </Link>
          </div>
        </section>
      </ScrollAnimation>

      {/* Stats Section */}
      <section id="stats-section" className="relative py-24">
        <video className="stats-video absolute inset-0 w-full h-full object-cover" autoPlay muted loop playsInline>
          <source
            src="https://ljsantos.com/wp-content/uploads/2024/02/Mapa-Interativo-LJ-Santos.mp4"
            type="video/mp4"
          />
        </video>
        <div className="absolute inset-0 bg-black opacity-60"></div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-12">
            <ScrollAnimation animation="animate-fadeInUp">
              <span className="text-white text-sm uppercase tracking-wider">GRANDES NÚMEROS</span>
              <h2 className="text-3xl md:text-4xl font-bold text-white mt-2">Números que hacen la diferencia</h2>
            </ScrollAnimation>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-zoomIn" delay="animate-delay-100">
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">25+</div>
                <div className="text-white text-sm uppercase tracking-wider">AÑOS DE EXPERIENCIA</div>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-zoomIn" delay="animate-delay-200">
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">60+</div>
                <div className="text-white text-sm uppercase tracking-wider">ETEs INSTALADAS</div>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-zoomIn" delay="animate-delay-300">
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">1000+</div>
                <div className="text-white text-sm uppercase tracking-wider">TANQUES INSTALADOS</div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>
    </main>
  )
}
