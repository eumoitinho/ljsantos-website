import Image from "next/image"
import { ScrollAnimation } from "@/components/scroll-animation"

export default function GalvanizadoElectrolitico() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      {/* Hero Section */}
      <section className="w-full bg-gradient-to-r from-gray-900 to-gray-800 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold text-white sm:text-5xl md:text-6xl">Galvanizado Electrolítico</h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-300 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Protección anticorrosiva de alta calidad para componentes metálicos
            </p>
          </div>
        </div>
      </section>

      {/* Visión General */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div>
              <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
                Galvanizado Electrolítico de Alto Rendimiento
              </h2>
              <p className="mt-4 text-lg text-gray-600">
                El galvanizado electrolítico es un proceso de recubrimiento que aplica una capa de zinc sobre
                superficies metálicas mediante electrodeposición, ofreciendo excelente protección contra la corrosión y
                un acabado estético superior.
              </p>
              <p className="mt-4 text-lg text-gray-600">
                En LJ Santos, utilizamos tecnología de punta y procesos rigurosamente controlados para garantizar
                recubrimientos uniformes, adherentes y de alta calidad, cumpliendo con las normas técnicas y ambientales
                más exigentes.
              </p>
            </div>
            <div className="mt-10 lg:mt-0 relative">
              <ScrollAnimation>
                <Image
                  src="/images/zincagem-4.png"
                  alt="Línea de Galvanizado Electrolítico LJ Santos"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl"
                />
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      {/* Características y Beneficios */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Características y Beneficios</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Nuestra línea de galvanizado electrolítico ofrece ventajas significativas para diversos sectores
              industriales.
            </p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Protección Anticorrosiva</h3>
              <p className="mt-2 text-gray-600">
                Excelente resistencia a la corrosión, prolongando significativamente la vida útil de los componentes
                metálicos.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Acabado Uniforme</h3>
              <p className="mt-2 text-gray-600">
                Recubrimiento homogéneo y controlado, garantizando un espesor uniforme en toda la superficie de la
                pieza.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Versatilidad</h3>
              <p className="mt-2 text-gray-600">
                Aplicable a una amplia variedad de piezas y componentes, desde pequeños tornillos hasta estructuras más
                grandes.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Pasivación Colorida</h3>
              <p className="mt-2 text-gray-600">
                Opciones de pasivación azul, amarilla, negra o transparente, atendiendo a diferentes requisitos
                estéticos y técnicos.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Conformidad Ambiental</h3>
              <p className="mt-2 text-gray-600">
                Procesos libres de cromo hexavalente, cumpliendo con las normas ambientales más rigurosas, incluyendo
                RoHS y REACH.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Control de Calidad</h3>
              <p className="mt-2 text-gray-600">
                Riguroso control de calidad en todas las etapas del proceso, garantizando resultados consistentes y
                confiables.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Proceso de Galvanizado */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Proceso de Galvanizado Electrolítico</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Conozca las etapas de nuestro proceso de galvanizado electrolítico de alta calidad.
            </p>
          </div>

          <div className="mt-12">
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="mt-10 lg:mt-0 relative order-first lg:order-last">
                <ScrollAnimation>
                  <Image
                    src="/images/zincagem-2.png"
                    alt="Línea de Galvanizado Electrolítico"
                    width={600}
                    height={400}
                    className="rounded-lg shadow-xl"
                  />
                </ScrollAnimation>
              </div>
              <div>
                <ol className="space-y-6">
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        1
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Preparación de la Superficie</h3>
                      <p className="mt-2 text-gray-600">
                        Limpieza, desengrase y decapado para eliminar impurezas y garantizar una perfecta adherencia del
                        recubrimiento.
                      </p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        2
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Electrodeposición</h3>
                      <p className="mt-2 text-gray-600">
                        Inmersión de las piezas en un baño electrolítico que contiene sales de zinc, donde ocurre la
                        deposición controlada del metal.
                      </p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        3
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Pasivación</h3>
                      <p className="mt-2 text-gray-600">
                        Tratamiento químico que aumenta la resistencia a la corrosión y puede conferir diferentes
                        coloraciones al recubrimiento.
                      </p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        4
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Secado y Finalización</h3>
                      <p className="mt-2 text-gray-600">
                        Secado controlado e inspección final para garantizar la calidad del recubrimiento y el
                        cumplimiento de las especificaciones.
                      </p>
                    </div>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Galería de Imágenes */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Nuestra Infraestructura</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Conozca nuestra moderna línea de galvanizado electrolítico, diseñada para ofrecer resultados
              excepcionales.
            </p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-2">
            <div className="relative">
              <ScrollAnimation>
                <Image
                  src="/images/zincagem-1.png"
                  alt="Tambor rotativo para galvanizado de piezas pequeñas"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl"
                />
                <p className="mt-2 text-sm text-gray-500 text-center">
                  Tambor rotativo para galvanizado en masa de piezas pequeñas
                </p>
              </ScrollAnimation>
            </div>
            <div className="relative">
              <ScrollAnimation>
                <Image
                  src="/images/zincagem-3.png"
                  alt="Sistema de tambor para galvanizado electrolítico"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl"
                />
                <p className="mt-2 text-sm text-gray-500 text-center">
                  Detalle del sistema de tambor para galvanizado electrolítico
                </p>
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      {/* Especificaciones Técnicas */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Especificaciones Técnicas</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Nuestra línea de galvanizado electrolítico cumple con los estándares de calidad más rigurosos.
            </p>
          </div>

          <div className="mt-12 bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Característica
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Especificación
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Espesor del Recubrimiento
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    5 a 25 μm (según especificación)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Tipos de Pasivación</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Azul, Amarilla, Negra, Transparente (Trivalente)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Resistencia a la Corrosión
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    96 a 720 horas en niebla salina (ASTM B117)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Capacidad de Producción
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Hasta 5 toneladas/día (dependiendo del tipo de pieza)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Dimensiones Máximas de las Piezas
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    2000 x 800 x 500 mm (largo x ancho x alto)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Conformidad</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    RoHS, REACH, ISO 9001, ISO 14001
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Aplicaciones */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Aplicaciones</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Nuestro galvanizado electrolítico se utiliza en diversos sectores industriales.
            </p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Industria Automotriz</h3>
              <p className="mt-2 text-gray-600">
                Componentes de fijación, piezas estructurales, sistemas de freno, elementos de suspensión y chasis.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Construcción Civil</h3>
              <p className="mt-2 text-gray-600">
                Tornillos, tuercas, arandelas, soportes, fijadores y elementos estructurales para construcción.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Electrodomésticos</h3>
              <p className="mt-2 text-gray-600">
                Componentes internos y externos de electrodomésticos que requieren protección contra la corrosión.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Industria Eléctrica</h3>
              <p className="mt-2 text-gray-600">
                Cajas de distribución, soportes, elementos de fijación y componentes de paneles eléctricos.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Máquinas y Equipos</h3>
              <p className="mt-2 text-gray-600">
                Piezas y componentes para máquinas industriales, agrícolas y de construcción.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Muebles Metálicos</h3>
              <p className="mt-2 text-gray-600">
                Componentes para muebles de oficina, hospitalarios e industriales que necesitan protección.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-green-700">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            ¿Necesita galvanizado electrolítico de alta calidad?
          </h2>
          <p className="mt-4 text-xl text-green-100">
            Contáctenos para discutir su proyecto y obtener una solución personalizada.
          </p>
          <div className="mt-8">
            <a
              href="#"
              className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-green-700 bg-white hover:bg-green-50"
            >
              Solicitar Presupuesto
            </a>
          </div>
        </div>
      </section>
    </main>
  )
}
