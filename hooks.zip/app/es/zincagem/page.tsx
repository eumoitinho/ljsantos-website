const ZincagemPage = () => {
  return (
    <div>
      <h1>Zincagem</h1>
      <p>This is the Zincagem page.</p>
    </div>
  )
}

export default ZincagemPage
