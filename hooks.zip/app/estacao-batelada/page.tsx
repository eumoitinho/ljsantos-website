import { redirect } from "next/navigation"

export default function EstacaoBatelada() {
  redirect("/estacoes-tratamento")
  return null
}
