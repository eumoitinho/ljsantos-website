import { redirect } from "next/navigation"

export default function EstacaoContinua() {
  redirect("/estacoes-tratamento")
  return null
}
