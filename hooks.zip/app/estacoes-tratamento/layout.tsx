import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "Estações de Tratamento de Efluentes | LJ Santos",
  description:
    "Soluções completas e eficientes para o tratamento de efluentes industriais, garantindo conformidade ambiental e economia de recursos.",
  keywords:
    "estação de tratamento de efluentes, ETE, tratamento de efluentes industriais, sistema batelada, sistema contínuo",
}

export default function EstacoesTratamentoLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}
