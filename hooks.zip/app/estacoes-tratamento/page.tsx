"use client"

import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Droplets, Recycle, Shield, BarChart, Settings } from "lucide-react"
import { useState } from "react"
import ImageGallery from "@/components/image-gallery"

export default function EstacoesTratamento() {
  // Imagens do Sistema Batelada
  const bateladaImages = [
    { src: "/images/estacao-batelada-1.jpeg", alt: "Sistema por Batelada Principal" },
    { src: "/images/estacao-batelada-2.jpeg", alt: "Detalhe Sistema Batelada" },
    { src: "/images/estacao-batelada-3.jpeg", alt: "Detalhe Sistema Batelada" },
    { src: "/images/estacao-batelada-4.png", alt: "Detalhe Sistema Batelada" },
  ]

  // Imagens do Sistema Contínuo
  const continuaImages = [
    { src: "/images/estacao-continua-1.jpeg", alt: "Sistema Contínuo Principal" },
    { src: "/images/estacao-continua-2.png", alt: "Detalhe Sistema Contínuo" },
    { src: "/images/estacao-continua-3.png", alt: "Detalhe Sistema Contínuo" },
    { src: "/images/estacao-continua-4.png", alt: "Detalhe Sistema Contínuo" },
  ]

  return (
    <main className="flex min-h-screen flex-col">
      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-50"></div>
          <Image
            src="/images/estacao-tratamento-hero.jpg"
            alt="Estações de Tratamento de Efluentes"
            fill
            className="object-cover"
            priority
          />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Estações de Tratamento de Efluentes</h1>
              <p className="text-lg text-white mb-8">
                Soluções completas e eficientes para o tratamento de efluentes industriais, garantindo conformidade
                ambiental e economia de recursos.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/solicite-orcamento"
                  className="inline-block bg-[#448b13] text-white font-bold py-3 px-6 rounded-xl transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:bg-[#3a7510]"
                >
                  Solicite um orçamento
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title mb-6">
                  Tratamento de Efluentes de Alta Eficiência
                </h2>
                <p className="text-gray-700 mb-4">
                  A LJ Santos desenvolve Estações de Tratamento de Efluentes (ETEs) com alta tecnologia e eficiência,
                  projetadas para atender às necessidades específicas de cada cliente e garantir a conformidade com as
                  normas ambientais vigentes.
                </p>
                <p className="text-gray-700 mb-4">
                  Oferecemos dois sistemas principais de tratamento: o sistema por Batelada e o sistema Contínuo. Cada
                  um possui características específicas que os tornam mais adequados para diferentes aplicações e
                  volumes de efluentes.
                </p>
                <p className="text-gray-700">
                  Nossas soluções são desenvolvidas com foco na sustentabilidade, eficiência operacional e facilidade de
                  manutenção, garantindo o melhor custo-benefício para nossos clientes.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="rounded-2xl overflow-hidden shadow-lg">
                <ImageGallery 
                  images={[{ src: "/images/estacao-tratamento-hero.jpg", alt: "Estações de Tratamento de Efluentes LJ Santos" }]} 
                  className="hidden"
                />
                <div className="relative aspect-video w-full cursor-pointer overflow-hidden rounded-2xl group">
                  <Image
                    src="/images/estacao-tratamento-hero.jpg"
                    alt="Estações de Tratamento de Efluentes LJ Santos"
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-20 transition-opacity duration-300"></div>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Redesigned Systems Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-12 text-center">Conheça Nossos Sistemas</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Sistema por Batelada Card */}
            <ScrollAnimation animation="animate-fadeInLeft">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden transition-transform duration-300 hover:shadow-xl hover:-translate-y-2">
                <div className="relative h-64 md:h-72 cursor-pointer group overflow-hidden">
                  <Image
                    src={bateladaImages[0].src}
                    alt={bateladaImages[0].alt}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-end">
                    <h3 className="text-2xl font-bold text-white p-6">Sistema por Batelada</h3>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-700 mb-6">
                    O sistema de tratamento por Batelada opera em ciclos completos, tratando lotes específicos de
                    efluentes. Este método permite um controle preciso de cada etapa do processo, desde a equalização
                    até a clarificação final.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                    <div className="bg-[#f2f7f5] p-4 rounded-lg">
                      <h4 className="font-semibold text-[#435a52] mb-2">Ideal para</h4>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Volumes menores de efluentes</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Alta variabilidade de características</span>
                        </li>
                      </ul>
                    </div>
                    <div className="bg-[#f2f7f5] p-4 rounded-lg">
                      <h4 className="font-semibold text-[#435a52] mb-2">Vantagens</h4>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Controle preciso por lote</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Alta flexibilidade operacional</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="mb-6">
                    <h4 className="font-semibold text-[#435a52] mb-3">Galeria de Imagens</h4>
                    <ImageGallery images={bateladaImages} />
                  </div>

                  <div className="flex justify-end">
                    <Link
                      href="/estacao-batelada"
                      className="inline-flex items-center text-[#448b13] font-semibold hover:text-[#3a7510] transition-colors"
                    >
                      Saiba mais
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 ml-1"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              </div>
            </ScrollAnimation>

            {/* Sistema Contínuo Card */}
            <ScrollAnimation animation="animate-fadeInRight">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden transition-transform duration-300 hover:shadow-xl hover:-translate-y-2">
                <div className="relative h-64 md:h-72 cursor-pointer group overflow-hidden">
                  <Image 
                    src={continuaImages[0].src} 
                    alt={continuaImages[0].alt} 
                    fill 
                    className="object-cover transition-transform duration-700 group-hover:scale-110" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-end">
                    <h3 className="text-2xl font-bold text-white p-6">Sistema Contínuo</h3>
                  </div>
                </div>
                <div className="p-6">
                  <p className="text-gray-700 mb-6">
                    O sistema de tratamento Contínuo opera ininterruptamente, recebendo e tratando os efluentes de forma
                    constante. Este método é ideal para processos industriais que geram efluentes continuamente e em
                    grandes volumes.
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                    <div className="bg-[#f2f7f5] p-4 rounded-lg">
                      <h4 className="font-semibold text-[#435a52] mb-2">Ideal para</h4>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Grandes volumes de efluentes</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Processos industriais contínuos</span>
                        </li>
                      </ul>
                    </div>
                    <div className="bg-[#f2f7f5] p-4 rounded-lg">
                      <h4 className="font-semibold text-[#435a52] mb-2">Vantagens</h4>
                      <ul className="space-y-2">
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Operação ininterrupta</span>
                        </li>
                        <li className="flex items-start">
                          <CheckCircle className="w-4 h-4 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                          <span className="text-sm">Maior capacidade de tratamento</span>
                        </li>
                      </ul>
                    </div>
                  </div>

                  <div className="mb-6">
                    <h4 className="font-semibold text-[#435a52] mb-3">Galeria de Imagens</h4>
                    <ImageGallery images={continuaImages} />
                  </div>

                  <div className="flex justify-end">
                    <Link
                      href="/estacao-continua"
                      className="inline-flex items-center text-[#448b13] font-semibold hover:text-[#3a7510] transition-colors"
                    >
                      Saiba mais
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-5 w-5 ml-1"
                        viewBox="0 0 20 20"
                        fill="currentColor"
                      >
                        <path
                          fillRule="evenodd"
                          d="M12.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-2.293-2.293a1 1 0 010-1.414z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </Link>
                  </div>
                </div>
              </div>
            </ScrollAnimation>
          </div>

          {/* Comparison Table */}
          <div className="mt-16">
            <ScrollAnimation animation="animate-fadeInUp">
              <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <div className="p-6 bg-[#435a52] text-white">
                  <h3 className="text-xl font-bold">Comparativo entre os Sistemas</h3>
                  <p className="text-white/80 mt-1">Escolha o sistema ideal para sua necessidade</p>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="text-left p-4 font-semibold text-[#435a52]">Características</th>
                        <th className="text-center p-4 font-semibold text-[#435a52]">Sistema por Batelada</th>
                        <th className="text-center p-4 font-semibold text-[#435a52]">Sistema Contínuo</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-t border-gray-100">
                        <td className="p-4 font-medium">Volume de Efluentes</td>
                        <td className="p-4 text-center">Pequeno a médio</td>
                        <td className="p-4 text-center">Médio a grande</td>
                      </tr>
                      <tr className="border-t border-gray-100 bg-gray-50">
                        <td className="p-4 font-medium">Operação</td>
                        <td className="p-4 text-center">Por ciclos</td>
                        <td className="p-4 text-center">Ininterrupta</td>
                      </tr>
                      <tr className="border-t border-gray-100">
                        <td className="p-4 font-medium">Flexibilidade</td>
                        <td className="p-4 text-center">Alta</td>
                        <td className="p-4 text-center">Média</td>
                      </tr>
                      <tr className="border-t border-gray-100 bg-gray-50">
                        <td className="p-4 font-medium">Controle de Processo</td>
                        <td className="p-4 text-center">Preciso por lote</td>
                        <td className="p-4 text-center">Constante</td>
                      </tr>
                      <tr className="border-t border-gray-100">
                        <td className="p-4 font-medium">Espaço Necessário</td>
                        <td className="p-4 text-center">Menor</td>
                        <td className="p-4 text-center">Maior</td>
                      </tr>
                      <tr className="border-t border-gray-100 bg-gray-50">
                        <td className="p-4 font-medium">Consumo de Energia</td>
                        <td className="p-4 text-center">Intermitente</td>
                        <td className="p-4 text-center">Constante</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center">Benefícios Comuns</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <Droplets className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Economia de Água</h3>
                <p className="text-gray-700">
                  Possibilidade de reuso da água tratada, reduzindo o consumo de recursos hídricos e os custos
                  operacionais.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <Shield className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Conformidade Legal</h3>
                <p className="text-gray-700">
                  Garantia de cumprimento da legislação ambiental vigente, evitando multas e sanções.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <Recycle className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Sustentabilidade</h3>
                <p className="text-gray-700">
                  Contribuição para a preservação do meio ambiente e para a imagem sustentável da empresa.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <Settings className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Automação Avançada</h3>
                <p className="text-gray-700">
                  Sistemas automatizados que garantem precisão, repetibilidade e menor necessidade de intervenção
                  manual.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <BarChart className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Alta Eficiência</h3>
                <p className="text-gray-700">
                  Alta eficiência na remoção de contaminantes, garantindo o cumprimento dos padrões de descarte.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="bg-[#f2f7f5] p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-white p-3 rounded-full inline-block mb-4 shadow-md">
                  <CheckCircle className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Personalização</h3>
                <p className="text-gray-700">
                  Projetos personalizados de acordo com as necessidades específicas de cada cliente e tipo de efluente.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Qual sistema é ideal para sua empresa?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Entre em contato conosco para uma avaliação personalizada e descubra qual sistema de tratamento de
              efluentes é mais adequado para as necessidades da sua empresa.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Solicitar orçamento
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>
    </main>
  )
}
