import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Outfit, Poppins, Open_Sans } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import Script from "next/script"
import Header from "@/components/header"
import Footer from "@/components/footer"
import WhatsAppButton from "@/components/whatsapp-button"

const outfit = Outfit({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-outfit",
})

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-poppins",
})

const openSans = Open_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-open-sans",
})

export const metadata: Metadata = {
  title: "Santos - Soluções Industriais Sustentáveis",
  description:
    "Soluções industriais sustentáveis de qualidade e confiança comprovada. Estações de tratamento de efluentes, tanques de polipropileno, filtro prensa e mais.",
  keywords:
    "tratamento de efluentes, tanques polipropileno, filtro prensa, zincagem eletrolítica, cromagem, soluções industriais, sustentabilidade",
  generator: "v0.dev",
  openGraph: {
    title: "Santos - Soluções Industriais Sustentáveis",
    description: "Soluções industriais sustentáveis de qualidade e confiança comprovada",
    url: "https://ljsantos.com",
    siteName: "LJ Santos",
    locale: "pt_BR",
    type: "website",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <Script id="google-tag-manager" strategy="afterInteractive">
        {`
          (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
          new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
          j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
          'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
          })(window,document,'script','dataLayer','GTM-XXXXXXX');
        `}
      </Script>
      <body className={`${outfit.variable} ${poppins.variable} ${openSans.variable}`}>
        <noscript>
          <iframe
            src="https://www.googletagmanager.com/ns.html?id=GTM-XXXXXXX"
            height="0"
            width="0"
            style={{ display: "none", visibility: "hidden" }}
          ></iframe>
        </noscript>
        <ThemeProvider attribute="class" defaultTheme="light">
          <Header />
          <main>{children}</main>
          <Footer />
          <WhatsAppButton />
        </ThemeProvider>
      </body>
    </html>
  )
}
