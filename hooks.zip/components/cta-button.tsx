import type React from "react"
import Link from "next/link"

interface CTAButtonProps {
  href: string
  variant?: "primary" | "outline" | "ghost"
  className?: string
  children: React.ReactNode
}

const CTAButton: React.FC<CTAButtonProps> = ({ href, variant = "primary", className = "", children }) => {
  let buttonClass = ""

  switch (variant) {
    case "primary":
      buttonClass = "request-button"
      break
    case "outline":
      buttonClass = "product-button"
      break
    case "ghost":
      buttonClass =
        "text-green-600 hover:bg-green-50 hover:scale-105 inline-block px-6 py-3 rounded-xl font-medium transition-all duration-300"
      break
    default:
      buttonClass = "request-button"
  }

  return (
    <Link href={href} className={`${buttonClass} ${className}`}>
      {children}
    </Link>
  )
}

export default CTAButton
