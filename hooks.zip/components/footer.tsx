"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone } from "lucide-react"

export default function Footer() {
  const [mounted, setMounted] = useState(false)
  const [currentYear, setCurrentYear] = useState(2023)

  useEffect(() => {
    setMounted(true)
    setCurrentYear(new Date().getFullYear())
  }, [])

  if (!mounted) return null

  return (
    <footer className="bg-[#435a52] text-white">
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo e Informações */}
          <div className="space-y-4">
            <Link href="/" className="inline-block">
              <Image src="/images/logo-white.png" alt="LJ Santos Logo" width={150} height={50} className="h-12 w-auto" />
            </Link>
            <p className="text-white/80 mt-4">
              Soluções completas para tratamento de efluentes e equipamentos para galvanoplastia.
            </p>
            <div className="flex space-x-4 mt-6">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links Rápidos */}
          <div>
            <h3 className="text-lg font-bold mb-4 border-b border-white/20 pb-2">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-white/80 hover:text-white transition-colors inline-block py-1">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/quem-somos" className="text-white/80 hover:text-white transition-colors inline-block py-1">
                  Quem Somos
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-white/80 hover:text-white transition-colors inline-block py-1">
                  Blog
                </Link>
              </li>
              <li>
                <Link
                  href="/solicite-orcamento"
                  className="text-white/80 hover:text-white transition-colors inline-block py-1"
                >
                  Solicite Orçamento
                </Link>
              </li>
            </ul>
          </div>

          {/* Produtos */}
          <div>
            <h3 className="text-lg font-bold mb-4 border-b border-white/20 pb-2">Produtos</h3>
            <ul className="space-y-2">
              <li>
                <Link
                  href="/estacoes-tratamento"
                  className="text-white/80 hover:text-white transition-colors inline-block py-1"
                >
                  Estações de Tratamento
                </Link>
              </li>
              <li>
                <Link
                  href="/filtro-prensa"
                  className="text-white/80 hover:text-white transition-colors inline-block py-1"
                >
                  Filtro Prensa
                </Link>
              </li>
              <li>
                <Link
                  href="/tanques-polipropileno"
                  className="text-white/80 hover:text-white transition-colors inline-block py-1"
                >
                  Tanques de Polipropileno
                </Link>
              </li>
              <li>
                <Link
                  href="/linha-de-cromagem"
                  className="text-white/80 hover:text-white transition-colors inline-block py-1"
                >
                  Linha de Cromagem
                </Link>
              </li>
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h3 className="text-lg font-bold mb-4 border-b border-white/20 pb-2">Contato</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mr-3 mt-0.5 flex-shrink-0 text-[#8cc63f]" />
                <span className="text-white/80">
                  Rua Exemplo, 123 - Bairro Industrial
                  <br />
                  Cidade - Estado, CEP 00000-000
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="h-5 w-5 mr-3 flex-shrink-0 text-[#8cc63f]" />
                <a href="tel:+551199999999" className="text-white/80 hover:text-white transition-colors">
                  (11) 9999-9999
                </a>
              </li>
              <li className="flex items-center">
                <Mail className="h-5 w-5 mr-3 flex-shrink-0 text-[#8cc63f]" />
                <a href="mailto:contato@ljsantos.com.br" className="text-white/80 hover:text-white transition-colors">
                  contato@ljsantos.com.br
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/20 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center">
          <p className="text-white/60 text-sm">
            © {currentYear} LJ Santos. Todos os direitos reservados.
          </p>
          <div className="mt-4 md:mt-0">
            <Link href="/politica-de-privacidade" className="text-white/60 hover:text-white text-sm transition-colors">
              Política de Privacidade
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
