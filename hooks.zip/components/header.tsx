"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, X } from "lucide-react"
import LanguageSwitcher from "./language-switcher"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setScrolled(true)
      } else {
        setScrolled(false)
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  if (!mounted) return null

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-white shadow-md py-2" : "bg-transparent py-4"
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center">
          <Link href="/" className="relative z-10">
            <Image
              src="/images/logo.png"
              alt="LJ Santos Logo"
              width={150}
              height={50}
              className={`transition-all duration-300 ${scrolled ? "h-10 w-auto" : "h-12 w-auto"}`}
            />
          </Link>

          {/* Menu para desktop */}
          <nav className="hidden lg:flex items-center space-x-8">
            <Link
              href="/"
              className={`font-medium transition-colors hover:text-[#448b13] ${
                scrolled ? "text-gray-800" : "text-white"
              }`}
            >
              Home
            </Link>
            <div className="relative group">
              <button
                className={`font-medium transition-colors hover:text-[#448b13] flex items-center ${
                  scrolled ? "text-gray-800" : "text-white"
                }`}
              >
                Produtos
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 ml-1"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <div className="absolute left-0 mt-2 w-56 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 transform origin-top-left">
                <div className="bg-white rounded-xl shadow-lg overflow-hidden p-2">
                  <Link
                    href="/estacoes-tratamento"
                    className="block px-4 py-2 text-gray-800 hover:bg-[#f2f7f5] hover:text-[#448b13] rounded-lg transition-colors"
                  >
                    Estações de Tratamento
                  </Link>
                  <Link
                    href="/filtro-prensa"
                    className="block px-4 py-2 text-gray-800 hover:bg-[#f2f7f5] hover:text-[#448b13] rounded-lg transition-colors"
                  >
                    Filtro Prensa
                  </Link>
                  <Link
                    href="/tanques-polipropileno"
                    className="block px-4 py-2 text-gray-800 hover:bg-[#f2f7f5] hover:text-[#448b13] rounded-lg transition-colors"
                  >
                    Tanques de Polipropileno
                  </Link>
                  <Link
                    href="/linha-de-cromagem"
                    className="block px-4 py-2 text-gray-800 hover:bg-[#f2f7f5] hover:text-[#448b13] rounded-lg transition-colors"
                  >
                    Linha de Cromagem
                  </Link>
                  <Link
                    href="/zincagem"
                    className="block px-4 py-2 text-gray-800 hover:bg-[#f2f7f5] hover:text-[#448b13] rounded-lg transition-colors"
                  >
                    Zincagem
                  </Link>
                  <Link
                    href="/zincagem-eletrolitica"
                    className="block px-4 py-2 text-gray-800 hover:bg-[#f2f7f5] hover:text-[#448b13] rounded-lg transition-colors"
                  >
                    Zincagem Eletrolítica
                  </Link>
                </div>
              </div>
            </div>
            <Link
              href="/quem-somos"
              className={`font-medium transition-colors hover:text-[#448b13] ${
                scrolled ? "text-gray-800" : "text-white"
              }`}
            >
              Quem Somos
            </Link>
            <Link
              href="/blog"
              className={`font-medium transition-colors hover:text-[#448b13] ${
                scrolled ? "text-gray-800" : "text-white"
              }`}
            >
              Blog
            </Link>
            <Link
              href="/solicite-orcamento"
              className="bg-[#448b13] text-white font-medium py-2 px-4 rounded-lg hover:bg-[#3a7510] transition-colors"
            >
              Solicite Orçamento
            </Link>
            <LanguageSwitcher textColor={scrolled ? "text-gray-800" : "text-white"} />
          </nav>

          {/* Botão do menu mobile */}
          <div className="flex items-center lg:hidden">
            <LanguageSwitcher textColor={scrolled ? "text-gray-800" : "text-white"} />
            <button
              onClick={toggleMenu}
              className={`ml-4 focus:outline-none transition-colors ${
                scrolled ? "text-gray-800" : "text-white"
              }`}
              aria-label="Menu"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Menu mobile */}
      <div
        className={`fixed inset-0 bg-white z-40 transform transition-transform duration-300 lg:hidden ${
          isMenuOpen ? "translate-x-0" : "translate-x-full"
        }`}
        style={{ top: "0", paddingTop: "5rem" }}
      >
        <div className="container mx-auto px-6 py-8">
          <nav className="flex flex-col space-y-4">
            <Link
              href="/"
              className="text-gray-800 font-medium py-2 hover:text-[#448b13] transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <div className="border-t border-gray-100 pt-2">
              <h3 className="text-gray-500 text-sm font-medium mb-2">Produtos</h3>
              <div className="pl-4 flex flex-col space-y-2">
                <Link
                  href="/estacoes-tratamento"
                  className="text-gray-800 py-1 hover:text-[#448b13] transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Estações de Tratamento
                </Link>
                <Link
                  href="/filtro-prensa"
                  className="text-gray-800 py-1 hover:text-[#448b13] transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Filtro Prensa
                </Link>
                <Link
                  href="/tanques-polipropileno"
                  className="text-gray-800 py-1 hover:text-[#448b13] transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Tanques de Polipropileno
                </Link>
                <Link
                  href="/linha-de-cromagem"
                  className="text-gray-800 py-1 hover:text-[#448b13] transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Linha de Cromagem
                </Link>
                <Link
                  href="/zincagem"
                  className="text-gray-800 py-1 hover:text-[#448b13] transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Zincagem
                </Link>
                <Link
                  href="/zincagem-eletrolitica"
                  className="text-gray-800 py-1 hover:text-[#448b13] transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Zincagem Eletrolítica
                </Link>
              </div>
            </div>
            <Link
              href="/quem-somos"
              className="text-gray-800 font-medium py-2 hover:text-[#448b13] transition-colors border-t border-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Quem Somos
            </Link>
            <Link
              href="/blog"
              className="text-gray-800 font-medium py-2 hover:text-[#448b13] transition-colors border-t border-gray-100"
              onClick={() => setIsMenuOpen(false)}
            >
              Blog
            </Link>
            <div className="pt-4 border-t border-gray-100">
              <Link
                href="/solicite-orcamento"
                className="bg-[#448b13] text-white font-medium py-3 px-6 rounded-lg hover:bg-[#3a7510] transition-colors inline-block w-full text-center"
                onClick={() => setIsMenuOpen(false)}
              >
                Solicite Orçamento
              </Link>
            </div>
          </nav>
        </div>
      </div>
    </header>
  )
}
