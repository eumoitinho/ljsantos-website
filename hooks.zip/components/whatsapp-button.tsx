import { MessageCircle } from "lucide-react"

const WhatsAppButton = () => {
  return (
    <a
      href="https://wa.me/5547999830386?text=Olá%20LJ%20Santos!%20Estou%20no%20site%20e%20gostaria%20de%20mais%20informações%20sobre..."
      target="_blank"
      rel="noopener noreferrer"
      className="whatsapp-button"
      aria-label="Abrir WhatsApp"
    >
      <MessageCircle className="w-8 h-8 text-white" />
    </a>
  )
}

export default WhatsAppButton
