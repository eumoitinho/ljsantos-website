"use server"

import { redirect } from "next/navigation"

interface FormData {
  name: string
  email: string
  phone: string
  company: string
  message: string
  product?: string
}

export async function submitForm(formData: FormData) {
  try {
    // Send to RD Station
    await sendToRDStation(formData)

    // Send to Google Sheets
    await sendToGoogleSheets(formData)

    // Redirect to thank you page
    redirect("/obrigado")
  } catch (error) {
    console.error("Error submitting form:", error)
    throw new Error("Failed to submit form. Please try again later.")
  }
}

async function sendToRDStation(formData: FormData) {
  const RD_STATION_API_KEY = process.env.RD_STATION_API_KEY

  if (!RD_STATION_API_KEY) {
    console.error("RD Station API key not found")
    return
  }

  const payload = {
    event_type: "CONVERSION",
    event_family: "CDP",
    payload: {
      conversion_identifier: "formulario-de-contato",
      name: formData.name,
      email: formData.email,
      cf_telefone: formData.phone,
      cf_empresa: formData.company,
      cf_mensagem: formData.message,
      cf_produto: formData.product || "Não especificado",
    },
  }

  const response = await fetch("https://api.rd.services/platform/conversions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${RD_STATION_API_KEY}`,
    },
    body: JSON.stringify(payload),
  })

  if (!response.ok) {
    throw new Error(`RD Station API error: ${response.status}`)
  }

  return response.json()
}

async function sendToGoogleSheets(formData: FormData) {
  const GOOGLE_SHEETS_URL = process.env.GOOGLE_SHEETS_URL

  if (!GOOGLE_SHEETS_URL) {
    console.error("Google Sheets URL not found")
    return
  }

  const payload = {
    name: formData.name,
    email: formData.email,
    phone: formData.phone,
    company: formData.company,
    message: formData.message,
    product: formData.product || "Não especificado",
    date: new Date().toISOString(),
  }

  const response = await fetch(GOOGLE_SHEETS_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  })

  if (!response.ok) {
    throw new Error(`Google Sheets API error: ${response.status}`)
  }

  return response.json()
}
