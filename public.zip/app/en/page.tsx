import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"

export default function EnglishHome() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center">
        <video className="hero-video" autoPlay muted loop playsInline>
          <source src="/videos/hero-background.mp4" type="video/mp4" />
        </video>
        <div className="hero-overlay"></div>

        <div className="container mx-auto px-6 text-center z-10">
          <ScrollAnimation animation="animate-fadeInUp">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-8 max-w-4xl mx-auto">
              Sustainable industrial solutions with proven quality and reliability
            </h1>
          </ScrollAnimation>
          <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
            <Link
              href="/en/solicite-orcamento"
              className="inline-block bg-white text-[#435a52] font-bold py-3 px-6 rounded-xl hover:bg-gray-100 transition-all duration-300 hover:shadow-lg"
            >
              Request a quote today
            </Link>
          </ScrollAnimation>
        </div>
      </section>

      {/* Trusted Brands Section */}
      <ScrollAnimation animation="animate-fadeInUp">
        <section className="py-12 bg-[#0e3b7c]">
          <div className="container mx-auto px-6">
            <div className="text-center mb-8">
              <p className="text-white text-xl font-medium">Trusted by</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-8 justify-items-center">
              <Image
                src="/brands/copacol.png"
                alt="Copacol"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/benteler.png"
                alt="Benteler"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/facchini.png"
                alt="Facchini"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/randon.png"
                alt="Randon"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/erzinger.png"
                alt="Erzinger"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
              <Image
                src="/brands/mahle.png"
                alt="Mahle"
                width={120}
                height={60}
                className="filter brightness-0 invert"
              />
            </div>
          </div>
        </section>
      </ScrollAnimation>

      {/* Products Section */}
      <ScrollAnimation animation="animate-fadeInUp">
        <section className="py-16 bg-[#f2f7f5]">
          <div className="container mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <ScrollAnimation animation="animate-fadeInRight">
                <div>
                  <h2 className="text-3xl font-bold text-[#435a52] section-title">Discover our products</h2>
                </div>
              </ScrollAnimation>

              <ScrollAnimation animation="animate-fadeInLeft">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Effluent Treatment Stations</p>
                    <Link
                      href="/en/estacoes-tratamento"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Learn more
                    </Link>
                  </div>
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Polypropylene Tanks</p>
                    <Link
                      href="/en/tanques-polipropileno"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Learn more
                    </Link>
                  </div>
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Filter Press</p>
                    <Link
                      href="/en/filtro-prensa"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Learn more
                    </Link>
                  </div>
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Electrolytic Zinc Plating Lines</p>
                    <Link
                      href="/en/zincagem"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Learn more
                    </Link>
                  </div>
                  <div className="mb-6">
                    <p className="font-medium text-[#435a52] mb-2">Chrome Plating Lines</p>
                    <Link
                      href="/en/linha-de-cromagem"
                      className="product-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                    >
                      Learn more
                    </Link>
                  </div>
                </div>
              </ScrollAnimation>
            </div>
          </div>
        </section>
      </ScrollAnimation>

      {/* Call to Action */}
      <ScrollAnimation animation="animate-zoomIn">
        <section
          className="relative py-24 bg-cover bg-center"
          style={{ backgroundImage: "url('/images/cta-background.png')" }}
        >
          <div className="absolute inset-0 bg-[#435a52] opacity-80"></div>

          <div className="container mx-auto px-6 relative z-10 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-8 max-w-4xl mx-auto">
              Our experience and innovation make us the right choice for industrial effluent treatment
            </h2>

            <Link
              href="/en/solicite-orcamento"
              className="cta-button inline-block rounded-xl hover:shadow-lg transition-all duration-300"
            >
              Request a quote today
            </Link>
          </div>
        </section>
      </ScrollAnimation>

      <Footer />
    </main>
  )
}
