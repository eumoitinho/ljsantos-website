import Image from "next/image"
import ScrollAnimation from "@/components/scroll-animation"
import ImageCarousel from "@/components/image-carousel"
import SectionTitle from "@/components/section-title"
import CTAButton from "@/components/cta-button"
import AnimatedCounter from "@/components/animated-counter"
import Header from "@/components/header"
import Footer from "@/components/footer"

export default function PolypropylenesTanks() {
  // Images for carousel
  const carouselImages = [
    { src: "/images/tanques-pp-1.jpeg", alt: "Horizontal polypropylene tanks" },
    { src: "/images/tanques-pp-2.jpeg", alt: "Polypropylene tanks in transport" },
    { src: "/images/tanques-pp-3.jpeg", alt: "Interior of tank with baffles" },
    { src: "/images/tanques-pp-4.jpeg", alt: "Front view of tank with partitions" },
    { src: "/images/tanques-pp-5.jpeg", alt: "Aerial view of polypropylene tanks" },
    { src: "/images/tanques-pp-6.jpeg", alt: "Installed horizontal tanks" },
    { src: "/images/tanques-pp-7.png", alt: "Cylindrical polypropylene tank" },
    { src: "/images/tanques-pp-8.png", alt: "Process polypropylene tank" },
    { src: "/images/tanques-pp-9.png", alt: "Vertical polypropylene tanks" },
  ]

  // Images for each tank type
  const horizontalTankImages = [
    { src: "/images/tanques-pp-1.jpeg", alt: "Horizontal polypropylene tanks" },
    { src: "/images/tanques-pp-2.jpeg", alt: "Polypropylene tanks in transport" },
    { src: "/images/tanques-pp-6.jpeg", alt: "Installed horizontal tanks" },
  ]

  const verticalTankImages = [
    { src: "/images/tanques-pp-9.png", alt: "Vertical polypropylene tanks" },
    { src: "/images/tanques-pp-7.png", alt: "Cylindrical polypropylene tank" },
  ]

  const processTankImages = [{ src: "/images/tanques-pp-8.png", alt: "Process polypropylene tank" }]

  const specialTankImages = [
    { src: "/images/tanques-pp-3.jpeg", alt: "Interior of tank with baffles" },
    { src: "/images/tanques-pp-4.jpeg", alt: "Front view of tank with partitions" },
  ]

  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-green-800 to-green-600 text-white">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute inset-0 bg-black opacity-30"></div>
          <Image src="/images/tanques-pp-5.jpeg" alt="Polypropylene Tanks" fill className="object-cover" priority />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">Polypropylene Tanks</h1>
              <p className="text-xl text-white/90 mb-8">
                Durable and resistant solutions for chemical storage and processing, with high corrosion resistance and
                excellent cost-benefit ratio.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-wrap gap-4">
                <CTAButton href="#contact" variant="primary">
                  Request a Quote
                </CTAButton>
                <CTAButton
                  href="#specifications"
                  variant="outline"
                  className="border-white text-white hover:bg-white/20"
                >
                  Technical Specifications
                </CTAButton>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Overview */}
      <section className="py-16 px-4 md:px-8 lg:px-16 bg-white">
        <div className="container mx-auto">
          <SectionTitle
            title="High-Performance Polypropylene Tanks"
            subtitle="Developed to meet the most demanding industrial requirements with durability and safety."
            centered
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <ScrollAnimation animation="animate-fadeInRight">
                <p className="text-lg text-gray-700 mb-6">
                  LJ Santos develops and manufactures high-quality polypropylene (PP) tanks designed to meet the most
                  demanding industrial requirements. Our tanks are ideal for storing and processing aggressive
                  chemicals, industrial effluents, and treated water.
                </p>
                <p className="text-lg text-gray-700 mb-6">
                  Polypropylene is a thermoplastic material with excellent chemical resistance, especially against
                  acids, bases, and solvents, making it the ideal choice for applications where corrosion resistance is
                  essential.
                </p>

                <div className="grid grid-cols-2 gap-6 mt-8">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <AnimatedCounter end={25} suffix="+" className="text-3xl text-green-600" />
                    <p className="text-gray-700">Years of experience</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <AnimatedCounter end={5000} suffix="+" className="text-3xl text-green-600" />
                    <p className="text-gray-700">Tanks installed</p>
                  </div>
                </div>
              </ScrollAnimation>
            </div>

            <ScrollAnimation animation="animate-fadeInLeft">
              <ImageCarousel images={carouselImages.slice(0, 4)} autoPlay={true} interval={4000} aspectRatio="video" />
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Features and Benefits */}
      <section className="py-16 px-4 md:px-8 lg:px-16 bg-gray-50">
        <div className="container mx-auto">
          <SectionTitle
            title="Features and Benefits"
            subtitle="Our polypropylene tanks offer significant advantages compared to conventional tanks."
            centered
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">High Chemical Resistance</h3>
                <p className="text-gray-600">
                  Excellent resistance to acids, bases, salts, and organic solvents, allowing for the safe storage of
                  aggressive chemicals.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Superior Durability</h3>
                <p className="text-gray-600">
                  Extended service life even in adverse conditions, with excellent impact and fatigue resistance,
                  reducing maintenance and replacement costs.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 6l3 1m0 0l-3 9a5.002 5.002 0 006.001 0M6 7l3 9M6 7l6-2m6 2l3-1m-3 1l-3 9a5.002 5.002 0 006.001 0M18 7l3 9m-3-9l-6-2m0-2v2m0 16V5m0 16H9m3 0h3"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Reduced Weight</h3>
                <p className="text-gray-600">
                  Significantly lighter than metal or concrete tanks, facilitating transport, installation, and reducing
                  structural costs.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Complete Customization</h3>
                <p className="text-gray-600">
                  Custom-made with different shapes, sizes, connections, and accessories to meet the specific needs of
                  each application.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Low Maintenance</h3>
                <p className="text-gray-600">
                  Do not corrode, do not require painting, and are easy to clean, resulting in reduced operating costs
                  throughout their service life.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="bg-white p-8 rounded-lg shadow-md h-full transform transition-transform duration-300 hover:-translate-y-2 hover:shadow-lg">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-6">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-8 w-8 text-green-600"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Excellent Cost-Benefit</h3>
                <p className="text-gray-600">
                  Ideal combination of competitive initial investment with low maintenance costs and long service life,
                  resulting in excellent return on investment.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Tank Types */}
      <section id="types" className="py-16 px-4 md:px-8 lg:px-16 bg-white">
        <div className="container mx-auto">
          <SectionTitle
            title="Types of Polypropylene Tanks"
            subtitle="We offer a wide variety of tanks to meet the specific needs of each application."
            centered
          />

          <div className="space-y-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <ScrollAnimation animation="animate-fadeInRight">
                <ImageCarousel images={horizontalTankImages} autoPlay={true} interval={5000} />
              </ScrollAnimation>

              <ScrollAnimation animation="animate-fadeInLeft">
                <div>
                  <h3 className="text-2xl font-semibold text-gray-800 mb-4">Horizontal Tanks</h3>
                  <p className="text-gray-600 mb-4">
                    Ideal for storing large volumes with height limitations. Available with or without support cradles,
                    in various diameters and lengths.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Capacities from 1,000 to 50,000 liters</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Options with internal compartments</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Possibility of underground installation</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Customizable connections and accessories</span>
                    </li>
                  </ul>

                  <CTAButton href="#contact" variant="outline" className="mt-6">
                    Request Information
                  </CTAButton>
                </div>
              </ScrollAnimation>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <ScrollAnimation animation="animate-fadeInRight" className="order-2 lg:order-1">
                <div>
                  <h3 className="text-2xl font-semibold text-gray-800 mb-4">Vertical Tanks</h3>
                  <p className="text-gray-600 mb-4">
                    Efficient solution for space optimization. Manufactured with flat, conical, or inclined bottom, with
                    or without lid, according to the application.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Capacities from 100 to 25,000 liters</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Options with stairs and access platforms</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Agitation and mixing systems</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Level indicators and automated controls</span>
                    </li>
                  </ul>

                  <CTAButton href="#contact" variant="outline" className="mt-6">
                    Request Information
                  </CTAButton>
                </div>
              </ScrollAnimation>

              <ScrollAnimation animation="animate-fadeInLeft" className="order-1 lg:order-2">
                <ImageCarousel images={verticalTankImages} autoPlay={true} interval={5000} />
              </ScrollAnimation>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <ScrollAnimation animation="animate-fadeInRight">
                <ImageCarousel images={processTankImages.concat(specialTankImages)} autoPlay={true} interval={5000} />
              </ScrollAnimation>

              <ScrollAnimation animation="animate-fadeInLeft">
                <div>
                  <h3 className="text-2xl font-semibold text-gray-800 mb-4">Process and Special Tanks</h3>
                  <p className="text-gray-600 mb-4">
                    Designed for specific chemical processes, such as neutralization, flocculation, decantation, and
                    controlled chemical reactions. We also offer customized solutions for special applications.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Complete systems with instrumentation</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Tanks with internal baffles and partitions</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Integrated filtration systems</span>
                    </li>
                    <li className="flex items-start">
                      <svg
                        className="w-5 h-5 text-green-600 mr-2 mt-1"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                      </svg>
                      <span className="text-gray-700">Special projects according to needs</span>
                    </li>
                  </ul>

                  <CTAButton href="#contact" variant="outline" className="mt-6">
                    Request Information
                  </CTAButton>
                </div>
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Specifications */}
      <section id="specifications" className="py-16 px-4 md:px-8 lg:px-16 bg-gray-50">
        <div className="container mx-auto">
          <SectionTitle
            title="Technical Specifications"
            subtitle="Our polypropylene tanks are manufactured following rigorous quality standards."
            centered
          />

          <ScrollAnimation animation="animate-fadeInUp">
            <div className="overflow-x-auto bg-white rounded-xl shadow-lg">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-green-700 text-white">
                    <th className="p-4 text-left rounded-tl-xl">Characteristic</th>
                    <th className="p-4 text-left">Specification</th>
                    <th className="p-4 text-left rounded-tr-xl">Notes</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Material</td>
                    <td className="p-4">Virgin Polypropylene (PP)</td>
                    <td className="p-4">Industrial grade, with UV additives when necessary</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Wall thickness</td>
                    <td className="p-4">6mm to 25mm</td>
                    <td className="p-4">Varies according to dimensions and application</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Operating temperature</td>
                    <td className="p-4">0°C to 90°C</td>
                    <td className="p-4">Consult for applications with specific temperatures</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Chemical resistance</td>
                    <td className="p-4">Acids, bases, salts, and solvents</td>
                    <td className="p-4">Consult specific chemical compatibility table</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Available capacities</td>
                    <td className="p-4">100L to 50,000L</td>
                    <td className="p-4">Larger volumes upon request</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Manufacturing methods</td>
                    <td className="p-4">Extrusion welding and thermofusion</td>
                    <td className="p-4">According to international standards</td>
                  </tr>
                  <tr className="border-b border-gray-200 hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium">Connections</td>
                    <td className="p-4">Flanges, threads, nozzles</td>
                    <td className="p-4">In PP, PVDF, or other compatible materials</td>
                  </tr>
                  <tr className="hover:bg-gray-50 transition-colors">
                    <td className="p-4 font-medium rounded-bl-xl">Applicable standards</td>
                    <td className="p-4">ASTM, DVS, ISO</td>
                    <td className="p-4 rounded-br-xl">Certifications available upon request</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Call to Action */}
      <section id="contact" className="py-16 bg-green-700 text-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl mx-auto text-center">
            <ScrollAnimation animation="animate-fadeInUp">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Need polypropylene tanks for your industry?</h2>
              <p className="text-xl mb-8">
                Contact us to develop a customized solution that meets your specific needs.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <CTAButton
                  href="/en/solicite-orcamento"
                  variant="primary"
                  className="bg-white text-green-700 hover:bg-gray-100"
                >
                  Request a Quote
                </CTAButton>
                <CTAButton
                  href="tel:+551140028922"
                  variant="outline"
                  className="border-white text-white hover:bg-white/20"
                >
                  Contact Us
                </CTAButton>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
