import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle } from "lucide-react"

export default function ElectrolyticZincPlating() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-[#435a52] mb-6">Electrolytic Zinc Plating</h1>
              <p className="text-lg text-gray-700 mb-8">
                High-quality anticorrosive protection for metal components, ensuring durability and resistance.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/en/solicite-orcamento"
                  className="request-button inline-block rounded-xl hover:shadow-lg transition-all duration-300"
                >
                  Request a quote
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Overview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">
                  High-Performance Electrolytic Zinc Plating
                </h2>
                <p className="text-gray-700 mb-4">
                  Electrolytic zinc plating is a coating process that applies a layer of zinc to metal surfaces through
                  electrodeposition, offering excellent corrosion protection and superior aesthetic finish.
                </p>
                <p className="text-gray-700 mb-4">
                  At LJ Santos, we use cutting-edge technology and rigorously controlled processes to ensure uniform,
                  adherent, and high-quality coatings that meet the most demanding technical and environmental
                  standards.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/zincagem-4.png"
                  alt="LJ Santos Electrolytic Zinc Plating Line"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Features and Benefits */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Features and Benefits
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Anticorrosive Protection</h3>
                <p className="text-gray-700">
                  Excellent corrosion resistance, significantly extending the service life of metal components.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Uniform Finish</h3>
                <p className="text-gray-700">
                  Homogeneous and controlled coating, ensuring uniform thickness across the entire surface of the part.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Versatility</h3>
                <p className="text-gray-700">
                  Applicable to a wide variety of parts and components, from small screws to larger structures.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Colored Passivation</h3>
                <p className="text-gray-700">
                  Options for blue, yellow, black, or clear passivation, meeting different aesthetic and technical
                  requirements.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Environmental Compliance</h3>
                <p className="text-gray-700">
                  Hexavalent chromium-free processes, meeting the most stringent environmental standards, including RoHS
                  and REACH.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Quality Control</h3>
                <p className="text-gray-700">
                  Rigorous quality control at all stages of the process, ensuring consistent and reliable results.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Zinc Plating Process */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Electrolytic Zinc Plating Process
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <ol className="space-y-6">
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">1</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-[#435a52] mb-2">Surface Preparation</h3>
                      <p className="text-gray-700">
                        Cleaning, degreasing, and pickling to remove impurities and ensure perfect coating adhesion.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">2</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-[#435a52] mb-2">Electrodeposition</h3>
                      <p className="text-gray-700">
                        Immersion of parts in an electrolytic bath containing zinc salts, where controlled metal
                        deposition occurs.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">3</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-[#435a52] mb-2">Passivation</h3>
                      <p className="text-gray-700">
                        Chemical treatment that increases corrosion resistance and can give different colors to the
                        coating.
                      </p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                      <span className="text-white text-xs font-bold">4</span>
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-[#435a52] mb-2">Drying and Finishing</h3>
                      <p className="text-gray-700">
                        Controlled drying and final inspection to ensure coating quality and compliance with
                        specifications.
                      </p>
                    </div>
                  </li>
                </ol>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/zincagem-2.png"
                  alt="Electrolytic Zinc Plating Line"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Image Gallery */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Our Infrastructure
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <Image
                  src="/images/zincagem-1.png"
                  alt="Rotating barrel for zinc plating of small parts"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
                <p className="mt-4 text-center text-gray-700">Rotating barrel for bulk zinc plating of small parts</p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/zincagem-3.png"
                  alt="Barrel system for electrolytic zinc plating"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
                <p className="mt-4 text-center text-gray-700">
                  Detail of the barrel system for electrolytic zinc plating
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Applications */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">Applications</h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Automotive Industry</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Fasteners</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Structural parts</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Brake systems</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Construction</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Screws and nuts</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Brackets and fasteners</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Structural elements</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Home Appliances</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Internal components</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Fastening elements</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                    <span className="text-gray-700">Structural parts</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Need high-quality electrolytic zinc plating?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Contact us for a personalized assessment and discover how our zinc plating services can meet your
              company's needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/en/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Request a quote
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      <Footer />
    </main>
  )
}
