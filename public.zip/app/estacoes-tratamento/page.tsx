import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Droplets, Recycle, Shield, BarChart, Settings } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function EstacoesTratamento() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-[#435a52] mb-6">
                Estações de Tratamento de Efluentes
              </h1>
              <p className="text-lg text-gray-700 mb-8">
                Soluções completas e eficientes para o tratamento de efluentes industriais, garantindo conformidade
                ambiental e economia de recursos.
              </p>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  href="/solicite-orcamento"
                  className="request-button inline-block rounded-xl hover:shadow-lg transition-all duration-300"
                >
                  Solicite um orçamento
                </Link>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Introduction */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">
                  Tratamento de Efluentes de Alta Eficiência
                </h2>
                <p className="text-gray-700 mb-4">
                  A LJ Santos desenvolve Estações de Tratamento de Efluentes (ETEs) com alta tecnologia e eficiência,
                  projetadas para atender às necessidades específicas de cada cliente e garantir a conformidade com as
                  normas ambientais vigentes.
                </p>
                <p className="text-gray-700 mb-4">
                  Oferecemos dois sistemas principais de tratamento: o sistema por Batelada e o sistema Contínuo. Cada
                  um possui características específicas que os tornam mais adequados para diferentes aplicações e
                  volumes de efluentes.
                </p>
                <p className="text-gray-700">
                  Nossas soluções são desenvolvidas com foco na sustentabilidade, eficiência operacional e facilidade de
                  manutenção, garantindo o melhor custo-benefício para nossos clientes.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/estacao-tratamento-hero.jpg"
                  alt="Estações de Tratamento de Efluentes LJ Santos"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Systems Comparison */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Conheça Nossos Sistemas
            </h2>
          </ScrollAnimation>

          <Tabs defaultValue="batelada" className="w-full">
            <ScrollAnimation animation="animate-zoomIn">
              <TabsList className="grid w-full grid-cols-2 mb-8 bg-white shadow-lg rounded-xl overflow-hidden">
                <TabsTrigger
                  value="batelada"
                  className="text-lg py-4 data-[state=active]:bg-[#435a52] data-[state=active]:text-white transition-all duration-300"
                >
                  Sistema por Batelada
                </TabsTrigger>
                <TabsTrigger
                  value="continuo"
                  className="text-lg py-4 data-[state=active]:bg-[#435a52] data-[state=active]:text-white transition-all duration-300"
                >
                  Sistema Contínuo
                </TabsTrigger>
              </TabsList>
            </ScrollAnimation>

            {/* Batelada Content */}
            <TabsContent value="batelada" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <ScrollAnimation animation="animate-fadeInRight">
                  <div>
                    <Image
                      src="/images/estacao-batelada-1.jpeg"
                      alt="Estação de Tratamento por Batelada"
                      width={600}
                      height={400}
                      className="rounded-2xl shadow-lg"
                    />
                  </div>
                </ScrollAnimation>
                <ScrollAnimation animation="animate-fadeInLeft">
                  <div>
                    <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Sistema por Batelada</h3>
                    <p className="text-gray-700 mb-6">
                      O sistema de tratamento por Batelada opera em ciclos completos, tratando lotes específicos de
                      efluentes. Este método permite um controle preciso de cada etapa do processo, desde a equalização
                      até a clarificação final.
                    </p>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Etapas do Processo</h4>
                    <ul className="space-y-3 mb-6">
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">1</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Equalização:</strong> Homogeneização dos efluentes para garantir uniformidade.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">2</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Reação:</strong> Adição controlada de reagentes químicos para tratamento.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">3</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Floculação:</strong> Formação de flocos para separação de contaminantes.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">4</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Clarificação:</strong> Separação da água tratada do lodo formado.
                        </span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Ideal para:</h4>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Volumes menores de efluentes</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Efluentes com alta variabilidade de características</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Processos que exigem controle rigoroso de cada lote</span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Galeria de Imagens</h4>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <Image
                        src="/images/estacao-batelada-2.jpeg"
                        alt="Estação Batelada - Detalhe 1"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-batelada-3.jpeg"
                        alt="Estação Batelada - Detalhe 2"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-batelada-4.png"
                        alt="Estação Batelada - Detalhe 3"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-batelada-5.jpeg"
                        alt="Estação Batelada - Detalhe 4"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                    </div>
                  </div>
                </ScrollAnimation>
              </div>
            </TabsContent>

            {/* Contínuo Content */}
            <TabsContent value="continuo" className="mt-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <ScrollAnimation animation="animate-fadeInRight">
                  <div>
                    <Image
                      src="/images/estacao-continua-1.jpeg"
                      alt="Estação de Tratamento Contínua"
                      width={600}
                      height={400}
                      className="rounded-2xl shadow-lg"
                    />
                  </div>
                </ScrollAnimation>
                <ScrollAnimation animation="animate-fadeInLeft">
                  <div>
                    <h3 className="text-2xl font-bold text-[#435a52] mb-4 section-title">Sistema Contínuo</h3>
                    <p className="text-gray-700 mb-6">
                      O sistema de tratamento Contínuo opera ininterruptamente, recebendo e tratando os efluentes de
                      forma constante. Este método é ideal para processos industriais que geram efluentes continuamente
                      e em grandes volumes.
                    </p>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Etapas do Processo</h4>
                    <ul className="space-y-3 mb-6">
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">1</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Recepção contínua:</strong> Entrada constante de efluentes no sistema.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">2</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Tratamento físico-químico:</strong> Adição automática de reagentes.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">3</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Decantação:</strong> Separação contínua de sólidos e líquidos.
                        </span>
                      </li>
                      <li className="flex items-start">
                        <div className="bg-[#435a52] rounded-full p-1 mr-3 mt-1 w-6 h-6 flex items-center justify-center">
                          <span className="text-white text-xs font-bold">4</span>
                        </div>
                        <span className="text-gray-700">
                          <strong>Descarte/reuso:</strong> Saída constante de água tratada.
                        </span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Ideal para:</h4>
                    <ul className="space-y-2 mb-6">
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Grandes volumes de efluentes</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Processos industriais contínuos</span>
                      </li>
                      <li className="flex items-start">
                        <CheckCircle className="w-5 h-5 text-[#435a52] mr-3 mt-1" />
                        <span className="text-gray-700">Efluentes com características mais constantes</span>
                      </li>
                    </ul>

                    <h4 className="text-xl font-semibold text-[#435a52] mb-3">Galeria de Imagens</h4>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <Image
                        src="/images/estacao-continua-2.png"
                        alt="Estação Contínua - Detalhe 1"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-continua-3.png"
                        alt="Estação Contínua - Detalhe 2"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-continua-4.png"
                        alt="Estação Contínua - Detalhe 3"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                      <Image
                        src="/images/estacao-continua-5.png"
                        alt="Estação Contínua - Detalhe 4"
                        width={300}
                        height={300}
                        className="rounded-lg shadow-md"
                      />
                    </div>
                  </div>
                </ScrollAnimation>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Comparison Table */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Comparativo entre os Sistemas
            </h2>
          </ScrollAnimation>

          <ScrollAnimation animation="animate-zoomIn">
            <div className="overflow-x-auto">
              <table className="w-full border-collapse serious-table rounded-xl overflow-hidden shadow-lg">
                <thead>
                  <tr>
                    <th className="text-left bg-[#435a52] text-white">Características</th>
                    <th className="text-center bg-[#435a52] text-white">Sistema por Batelada</th>
                    <th className="text-center bg-[#435a52] text-white">Sistema Contínuo</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="font-medium">Volume de Efluentes</td>
                    <td className="text-center">Pequeno a médio</td>
                    <td className="text-center">Médio a grande</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Operação</td>
                    <td className="text-center">Por ciclos</td>
                    <td className="text-center">Ininterrupta</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Flexibilidade</td>
                    <td className="text-center">Alta</td>
                    <td className="text-center">Média</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Controle de Processo</td>
                    <td className="text-center">Preciso por lote</td>
                    <td className="text-center">Constante</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Espaço Necessário</td>
                    <td className="text-center">Menor</td>
                    <td className="text-center">Maior</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Consumo de Energia</td>
                    <td className="text-center">Intermitente</td>
                    <td className="text-center">Constante</td>
                  </tr>
                  <tr>
                    <td className="font-medium">Manutenção</td>
                    <td className="text-center">Mais simples</td>
                    <td className="text-center">Mais complexa</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-[#435a52] mb-8 text-center section-title centered">
              Benefícios Comuns
            </h2>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Droplets className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Economia de Água</h3>
                <p className="text-gray-700">
                  Possibilidade de reuso da água tratada, reduzindo o consumo de recursos hídricos e os custos
                  operacionais.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Shield className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Conformidade Legal</h3>
                <p className="text-gray-700">
                  Garantia de atendimento às legislações ambientais vigentes, evitando multas e penalidades.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Recycle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Sustentabilidade</h3>
                <p className="text-gray-700">
                  Contribuição para a preservação do meio ambiente e para a imagem sustentável da empresa.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Settings className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Automação Avançada</h3>
                <p className="text-gray-700">
                  Sistemas automatizados que garantem precisão, repetibilidade e menor necessidade de intervenção
                  manual.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <BarChart className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Alta Eficiência</h3>
                <p className="text-gray-700">
                  Elevada eficiência na remoção de contaminantes, garantindo o atendimento aos padrões de lançamento.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="serious-card p-6 rounded-2xl hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <CheckCircle className="w-6 h-6 text-[#435a52]" />
                </div>
                <h3 className="text-xl font-semibold text-[#435a52] mb-3">Customização</h3>
                <p className="text-gray-700">
                  Projetos personalizados de acordo com as necessidades específicas de cada cliente e tipo de efluente.
                </p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52] rounded-t-3xl">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Qual sistema é ideal para sua empresa?</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Entre em contato conosco para uma avaliação personalizada e descubra qual sistema de tratamento de
              efluentes é mais adequado para as necessidades da sua empresa.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Solicite um orçamento
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      <Footer />
    </main>
  )
}
