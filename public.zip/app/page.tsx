import Header from "@/components/header"
import HeroSection from "@/components/hero-section"
import TrustedBrands from "@/components/trusted-brands"
import ProductsSection from "@/components/products-section"
import QualitySection from "@/components/quality-section"
import CallToAction from "@/components/call-to-action"
import StatsSection from "@/components/stats-section"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />
      <HeroSection />

      <ScrollAnimation animation="animate-fadeInUp">
        <TrustedBrands />
      </ScrollAnimation>

      <ScrollAnimation animation="animate-fadeInUp">
        <ProductsSection />
      </ScrollAnimation>

      <div className="relative">
        <ScrollAnimation animation="animate-fadeInRight">
          <QualitySection />
        </ScrollAnimation>
      </div>

      <ScrollAnimation animation="animate-zoomIn">
        <CallToAction />
      </ScrollAnimation>

      <ScrollAnimation animation="animate-fadeInUp">
        <StatsSection />
      </ScrollAnimation>

      <Footer />
    </main>
  )
}
