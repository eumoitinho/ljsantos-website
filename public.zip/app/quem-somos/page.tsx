import Header from "@/components/header"
import Footer from "@/components/footer"
import ScrollAnimation from "@/components/scroll-animation"
import Image from "next/image"
import Link from "next/link"
import { CheckCircle, Award, Users, Clock, Target, Lightbulb } from "lucide-react"

export default function QuemSomos() {
  return (
    <main className="flex min-h-screen flex-col">
      <Header />

      {/* Hero Section */}
      <section className="relative pt-32 pb-16 bg-gradient-to-b from-[#f2f7f5] to-white">
        <div className="container mx-auto px-6">
          <div className="max-w-4xl">
            <ScrollAnimation animation="animate-fadeInUp">
              <h1 className="text-4xl md:text-5xl font-bold text-[#435a52] mb-6">Quem Somos</h1>
              <p className="text-lg text-gray-700 mb-8">
                Conheça a história, valores e compromissos da LJ Santos, uma empresa dedicada a oferecer soluções
                industriais sustentáveis com qualidade e confiança comprovada.
              </p>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <h2 className="text-3xl font-bold text-[#435a52] section-title">Nossa História</h2>
                <p className="text-gray-700 mb-4">
                  Fundada há mais de 25 anos, a LJ Santos nasceu com o propósito de desenvolver soluções industriais
                  inovadoras e sustentáveis. Desde o início, nossa empresa se destacou pela qualidade e confiabilidade
                  de seus produtos e serviços.
                </p>
                <p className="text-gray-700 mb-4">
                  Ao longo dos anos, expandimos nossa atuação e hoje somos referência no mercado de tratamento de
                  efluentes industriais, fabricação de tanques em polipropileno, filtros prensa e linhas de
                  galvanoplastia.
                </p>
                <p className="text-gray-700 mb-4">
                  Nossa trajetória é marcada por constante evolução tecnológica e compromisso com a sustentabilidade,
                  sempre buscando oferecer soluções que atendam às necessidades específicas de cada cliente e contribuam
                  para um futuro mais sustentável.
                </p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/industrial-facility.png"
                  alt="Instalações da LJ Santos"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg"
                />
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#435a52] mb-4 section-title centered">Missão, Visão e Valores</h2>
              <p className="text-gray-700 max-w-3xl mx-auto">
                Nossos princípios fundamentais guiam todas as nossas ações e decisões, definindo quem somos e como
                trabalhamos.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-100">
              <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Target className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-bold text-[#435a52] mb-4">Missão</h3>
                <p className="text-gray-700">
                  Desenvolver e fornecer soluções industriais sustentáveis que contribuam para o sucesso de nossos
                  clientes, respeitando o meio ambiente e promovendo o desenvolvimento econômico e social.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-200">
              <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Lightbulb className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-bold text-[#435a52] mb-4">Visão</h3>
                <p className="text-gray-700">
                  Ser reconhecida como referência nacional em soluções industriais sustentáveis, inovadoras e de alta
                  qualidade, expandindo nossa atuação para novos mercados e contribuindo para um futuro mais
                  sustentável.
                </p>
              </div>
            </ScrollAnimation>

            <ScrollAnimation animation="animate-fadeInUp" delay="animate-delay-300">
              <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
                <div className="bg-[#f2f7f5] p-3 rounded-full inline-block mb-4">
                  <Award className="w-6 h-6 text-[#448b13]" />
                </div>
                <h3 className="text-xl font-bold text-[#435a52] mb-4">Valores</h3>
                <ul className="text-gray-700 space-y-2">
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                    <span>Compromisso com a qualidade e excelência</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                    <span>Inovação e melhoria contínua</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                    <span>Responsabilidade socioambiental</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                    <span>Ética e transparência</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="w-5 h-5 text-[#448b13] mr-2 mt-1 flex-shrink-0" />
                    <span>Valorização das pessoas</span>
                  </li>
                </ul>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* Our Team */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#435a52] mb-4 section-title centered">Nossa Equipe</h2>
              <p className="text-gray-700 max-w-3xl mx-auto">
                Contamos com profissionais altamente qualificados e comprometidos com a excelência, formando uma equipe
                multidisciplinar capaz de desenvolver soluções inovadoras para os mais diversos desafios.
              </p>
            </div>
          </ScrollAnimation>

          <ScrollAnimation animation="animate-fadeInUp">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
              <div className="flex items-start">
                <div className="bg-[#f2f7f5] p-3 rounded-full mr-4">
                  <Users className="w-6 h-6 text-[#448b13]" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-[#435a52] mb-2">Equipe Técnica Especializada</h3>
                  <p className="text-gray-700">
                    Nossa equipe técnica é formada por engenheiros, técnicos e especialistas com vasta experiência no
                    setor industrial, capazes de projetar, desenvolver e implementar soluções personalizadas para cada
                    cliente.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-[#f2f7f5] p-3 rounded-full mr-4">
                  <Clock className="w-6 h-6 text-[#448b13]" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-[#435a52] mb-2">Suporte Contínuo</h3>
                  <p className="text-gray-700">
                    Oferecemos suporte técnico em todas as etapas do projeto, desde a concepção até a implementação e
                    manutenção, garantindo o funcionamento eficiente e duradouro de nossos produtos e soluções.
                  </p>
                </div>
              </div>
            </div>
          </ScrollAnimation>

          <ScrollAnimation animation="animate-fadeInUp">
            <div className="bg-[#f2f7f5] p-8 rounded-xl text-center">
              <h3 className="text-2xl font-bold text-[#435a52] mb-4">Junte-se à Nossa Equipe</h3>
              <p className="text-gray-700 mb-6 max-w-3xl mx-auto">
                Estamos sempre em busca de talentos que compartilhem nossos valores e queiram contribuir para o
                desenvolvimento de soluções industriais sustentáveis e inovadoras.
              </p>
              <Link
                href="/contato"
                className="inline-block bg-[#448b13] text-white font-semibold py-3 px-6 rounded-lg hover:bg-[#3a7510] transition-colors"
              >
                Trabalhe Conosco
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      {/* Our Facilities */}
      <section className="py-16 bg-[#f2f7f5]">
        <div className="container mx-auto px-6">
          <ScrollAnimation animation="animate-fadeInUp">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-[#435a52] mb-4 section-title centered">Nossas Instalações</h2>
              <p className="text-gray-700 max-w-3xl mx-auto">
                Contamos com instalações modernas e bem equipadas, que nos permitem desenvolver produtos de alta
                qualidade e oferecer o melhor atendimento aos nossos clientes.
              </p>
            </div>
          </ScrollAnimation>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ScrollAnimation animation="animate-fadeInRight">
              <div>
                <Image
                  src="/images/exhibition-stand.jpeg"
                  alt="Estande da LJ Santos na Feira"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg mb-4"
                />
                <p className="text-sm text-gray-600 text-center">Estande da LJ Santos na Feira da Metalurgia</p>
              </div>
            </ScrollAnimation>
            <ScrollAnimation animation="animate-fadeInLeft">
              <div>
                <Image
                  src="/images/industrial-facility.png"
                  alt="Instalações Industriais da LJ Santos"
                  width={600}
                  height={400}
                  className="rounded-2xl shadow-lg mb-4"
                />
                <p className="text-sm text-gray-600 text-center">Instalações Industriais da LJ Santos</p>
              </div>
            </ScrollAnimation>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#435a52]">
        <div className="container mx-auto px-6 text-center">
          <ScrollAnimation animation="animate-fadeInUp">
            <h2 className="text-3xl font-bold text-white mb-6">Conheça nossas soluções</h2>
            <p className="text-white mb-8 max-w-3xl mx-auto">
              Descubra como a LJ Santos pode ajudar sua empresa com soluções industriais sustentáveis e de alta
              qualidade.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                href="/solucoes"
                className="text-base font-bold py-3 px-6 rounded-xl bg-white text-[#435a52] hover:bg-gray-100 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Nossas Soluções
              </Link>
              <Link
                href="/solicite-orcamento"
                className="text-base font-bold py-3 px-6 rounded-xl bg-transparent border border-white text-white hover:bg-white/10 transition-all duration-300 hover:shadow-lg inline-block"
              >
                Solicite um Orçamento
              </Link>
            </div>
          </ScrollAnimation>
        </div>
      </section>

      <Footer />
    </main>
  )
}
