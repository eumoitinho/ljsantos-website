import Image from "next/image"
import { ScrollAnimation } from "@/components/scroll-animation"

export default function ZincagemEletrolitica() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between">
      {/* Hero Section */}
      <section className="w-full bg-gradient-to-r from-gray-900 to-gray-800 py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold text-white sm:text-5xl md:text-6xl">Zincagem Eletrolítica</h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-300 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Proteção anticorrosiva de alta qualidade para componentes metálicos
            </p>
          </div>
        </div>
      </section>

      {/* Visão Geral */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
            <div>
              <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
                Zincagem Eletrolítica de Alta Performance
              </h2>
              <p className="mt-4 text-lg text-gray-600">
                A zincagem eletrolítica é um processo de revestimento que aplica uma camada de zinco sobre superfícies
                metálicas através de eletrodeposição, oferecendo excelente proteção contra corrosão e um acabamento
                estético superior.
              </p>
              <p className="mt-4 text-lg text-gray-600">
                Na LJ Santos, utilizamos tecnologia de ponta e processos rigorosamente controlados para garantir
                revestimentos uniformes, aderentes e de alta qualidade, atendendo às mais exigentes normas técnicas e
                ambientais.
              </p>
            </div>
            <div className="mt-10 lg:mt-0 relative">
              <ScrollAnimation>
                <Image
                  src="/images/zincagem-4.png"
                  alt="Linha de Zincagem Eletrolítica LJ Santos"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl"
                />
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      {/* Características e Benefícios */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Características e Benefícios</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Nossa linha de zincagem eletrolítica oferece vantagens significativas para diversos setores industriais.
            </p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Proteção Anticorrosiva</h3>
              <p className="mt-2 text-gray-600">
                Excelente resistência à corrosão, prolongando significativamente a vida útil dos componentes metálicos.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Acabamento Uniforme</h3>
              <p className="mt-2 text-gray-600">
                Revestimento homogêneo e controlado, garantindo espessura uniforme em toda a superfície da peça.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Versatilidade</h3>
              <p className="mt-2 text-gray-600">
                Aplicável a uma ampla variedade de peças e componentes, desde pequenos parafusos até estruturas maiores.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Passivação Colorida</h3>
              <p className="mt-2 text-gray-600">
                Opções de passivação azul, amarela, preta ou transparente, atendendo a diferentes requisitos estéticos e
                técnicos.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Conformidade Ambiental</h3>
              <p className="mt-2 text-gray-600">
                Processos livres de cromo hexavalente, atendendo às normas ambientais mais rigorosas, incluindo RoHS e
                REACH.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Controle de Qualidade</h3>
              <p className="mt-2 text-gray-600">
                Rigoroso controle de qualidade em todas as etapas do processo, garantindo resultados consistentes e
                confiáveis.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Processo de Zincagem */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Processo de Zincagem Eletrolítica</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Conheça as etapas do nosso processo de zincagem eletrolítica de alta qualidade.
            </p>
          </div>

          <div className="mt-12">
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="mt-10 lg:mt-0 relative order-first lg:order-last">
                <ScrollAnimation>
                  <Image
                    src="/images/zincagem-2.png"
                    alt="Linha de Zincagem Eletrolítica"
                    width={600}
                    height={400}
                    className="rounded-lg shadow-xl"
                  />
                </ScrollAnimation>
              </div>
              <div>
                <ol className="space-y-6">
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        1
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Preparação da Superfície</h3>
                      <p className="mt-2 text-gray-600">
                        Limpeza, desengraxe e decapagem para remover impurezas e garantir aderência perfeita do
                        revestimento.
                      </p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        2
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Eletrodeposição</h3>
                      <p className="mt-2 text-gray-600">
                        Imersão das peças em banho eletrolítico contendo sais de zinco, onde ocorre a deposição
                        controlada do metal.
                      </p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        3
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Passivação</h3>
                      <p className="mt-2 text-gray-600">
                        Tratamento químico que aumenta a resistência à corrosão e pode conferir diferentes colorações ao
                        revestimento.
                      </p>
                    </div>
                  </li>
                  <li className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-green-600 text-white">
                        4
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-lg font-medium text-gray-900">Secagem e Finalização</h3>
                      <p className="mt-2 text-gray-600">
                        Secagem controlada e inspeção final para garantir a qualidade do revestimento e o atendimento às
                        especificações.
                      </p>
                    </div>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Galeria de Imagens */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Nossa Infraestrutura</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Conheça nossa moderna linha de zincagem eletrolítica, projetada para oferecer resultados excepcionais.
            </p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-2">
            <div className="relative">
              <ScrollAnimation>
                <Image
                  src="/images/zincagem-1.png"
                  alt="Tambor rotativo para zincagem de pequenas peças"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl"
                />
                <p className="mt-2 text-sm text-gray-500 text-center">
                  Tambor rotativo para zincagem de pequenas peças em massa
                </p>
              </ScrollAnimation>
            </div>
            <div className="relative">
              <ScrollAnimation>
                <Image
                  src="/images/zincagem-3.png"
                  alt="Sistema de tambor para zincagem eletrolítica"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-xl"
                />
                <p className="mt-2 text-sm text-gray-500 text-center">
                  Detalhe do sistema de tambor para zincagem eletrolítica
                </p>
              </ScrollAnimation>
            </div>
          </div>
        </div>
      </section>

      {/* Especificações Técnicas */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Especificações Técnicas</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Nossa linha de zincagem eletrolítica atende aos mais rigorosos padrões de qualidade.
            </p>
          </div>

          <div className="mt-12 bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Característica
                  </th>
                  <th
                    scope="col"
                    className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                  >
                    Especificação
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Espessura do Revestimento
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    5 a 25 μm (conforme especificação)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Tipos de Passivação</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Azul, Amarela, Preta, Transparente (Trivalente)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Resistência à Corrosão
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    96 a 720 horas em névoa salina (ASTM B117)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Capacidade de Produção
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Até 5 toneladas/dia (dependendo do tipo de peça)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    Dimensões Máximas das Peças
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    2000 x 800 x 500 mm (comprimento x largura x altura)
                  </td>
                </tr>
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Conformidade</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    RoHS, REACH, ISO 9001, ISO 14001
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* Aplicações */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Aplicações</h2>
            <p className="mt-4 max-w-2xl text-xl text-gray-600 mx-auto">
              Nossa zincagem eletrolítica é utilizada em diversos setores industriais.
            </p>
          </div>

          <div className="mt-12 grid gap-8 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Indústria Automotiva</h3>
              <p className="mt-2 text-gray-600">
                Componentes de fixação, peças estruturais, sistemas de freio, elementos de suspensão e chassis.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Construção Civil</h3>
              <p className="mt-2 text-gray-600">
                Parafusos, porcas, arruelas, suportes, fixadores e elementos estruturais para construção.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Eletrodomésticos</h3>
              <p className="mt-2 text-gray-600">
                Componentes internos e externos de eletrodomésticos que requerem proteção contra corrosão.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Indústria Elétrica</h3>
              <p className="mt-2 text-gray-600">
                Caixas de distribuição, suportes, elementos de fixação e componentes de painéis elétricos.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Máquinas e Equipamentos</h3>
              <p className="mt-2 text-gray-600">
                Peças e componentes para máquinas industriais, agrícolas e de construção.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-xl font-bold text-gray-900">Móveis Metálicos</h3>
              <p className="mt-2 text-gray-600">
                Componentes para móveis de escritório, hospitalares e industriais que necessitam de proteção.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-green-700">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-3xl font-extrabold text-white sm:text-4xl">
            Precisa de zincagem eletrolítica de alta qualidade?
          </h2>
          <p className="mt-4 text-xl text-green-100">
            Entre em contato conosco para discutir seu projeto e obter uma solução personalizada.
          </p>
          <div className="mt-8">
            <a
              href="#"
              className="inline-flex items-center justify-center px-5 py-3 border border-transparent text-base font-medium rounded-md text-green-700 bg-white hover:bg-green-50"
            >
              Solicitar Orçamento
            </a>
          </div>
        </div>
      </section>
    </main>
  )
}
