"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import LanguageSwitcher from "./language-switcher"
import { usePathname } from "next/navigation"

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const pathname = usePathname()

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen)
  }

  // Determine language prefix for links
  const getPrefix = (): string => {
    if (pathname.startsWith("/en")) return "/en"
    if (pathname.startsWith("/es")) return "/es"
    return ""
  }

  const prefix = getPrefix()

  // Translations for menu items
  const translations = {
    "": {
      home: "Home",
      about: "Quem Somos",
      solutions: "Soluções",
      cases: "Cases",
      blog: "Blog",
      quote: "Solicite orçamento",
      treatmentStations: "Estações de Tratamento",
      polypropyleneTanks: "Tanques em Polipropileno",
      filterPress: "Filtro Prensa",
      zincPlating: "Linhas de Zincagem Eletrolítica",
      chromePlating: "Linhas de Cromagem",
    },
    "/en": {
      home: "Home",
      about: "About Us",
      solutions: "Solutions",
      cases: "Cases",
      blog: "Blog",
      quote: "Request a quote",
      treatmentStations: "Treatment Stations",
      polypropyleneTanks: "Polypropylene Tanks",
      filterPress: "Filter Press",
      zincPlating: "Electrolytic Zinc Plating Lines",
      chromePlating: "Chrome Plating Lines",
    },
    "/es": {
      home: "Inicio",
      about: "Quiénes Somos",
      solutions: "Soluciones",
      cases: "Casos",
      blog: "Blog",
      quote: "Solicitar presupuesto",
      treatmentStations: "Estaciones de Tratamiento",
      polypropyleneTanks: "Tanques de Polipropileno",
      filterPress: "Filtro Prensa",
      zincPlating: "Líneas de Galvanizado Electrolítico",
      chromePlating: "Líneas de Cromado",
    },
  }

  const t = translations[prefix as keyof typeof translations]

  return (
    <header className="bg-white py-4 px-6 fixed w-full z-50 shadow-sm">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex-1">
          <Link href={`${prefix}/`}>
            <Image src="/logo.png" alt="Santos Logo" width={262} height={75} className="h-12 w-auto" />
          </Link>
        </div>

        <nav className="hidden md:flex flex-1 justify-center">
          <ul className="flex space-x-6">
            <li>
              <Link href={`${prefix}/`} className="text-[#3e483c] font-semibold hover:text-[#297d53] transition-colors">
                {t.home}
              </Link>
            </li>
            <li>
              <Link
                href={`${prefix}/quem-somos`}
                className="text-[#3e483c] font-semibold hover:text-[#297d53] transition-colors"
              >
                {t.about}
              </Link>
            </li>
            <li className="relative group">
              <Link
                href={`${prefix}/solucoes`}
                className="text-[#3e483c] font-semibold hover:text-[#297d53] flex items-center transition-colors"
              >
                {t.solutions}
                <svg
                  className="w-4 h-4 ml-1"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </Link>
              <ul className="absolute hidden group-hover:block bg-white shadow-lg rounded-xl py-2 w-64 z-10 overflow-hidden">
                <li>
                  <Link
                    href={`${prefix}/estacoes-tratamento`}
                    className="block px-4 py-2 text-[#3e483c] hover:text-[#297d53] hover:bg-gray-50 transition-colors"
                  >
                    {t.treatmentStations}
                  </Link>
                </li>
                <li>
                  <Link
                    href={`${prefix}/estacao-continua`}
                    className="block px-4 py-2 text-[#3e483c] hover:text-[#297d53] hover:bg-gray-50 transition-colors"
                  >
                    {t.continuousTreatment}
                  </Link>
                </li>
                <li>
                  <Link
                    href={`${prefix}/tanques-polipropileno`}
                    className="block px-4 py-2 text-[#3e483c] hover:text-[#297d53] hover:bg-gray-50 transition-colors"
                  >
                    {t.polypropyleneTanks}
                  </Link>
                </li>
                <li>
                  <Link
                    href={`${prefix}/filtro-prensa`}
                    className="block px-4 py-2 text-[#3e483c] hover:text-[#297d53] hover:bg-gray-50 transition-colors"
                  >
                    {t.filterPress}
                  </Link>
                </li>
                <li>
                  <Link
                    href={`${prefix}/zincagem`}
                    className="block px-4 py-2 text-[#3e483c] hover:text-[#297d53] hover:bg-gray-50 transition-colors"
                  >
                    {t.zincPlating}
                  </Link>
                </li>
                <li>
                  <Link
                    href={`${prefix}/linha-de-cromagem`}
                    className="block px-4 py-2 text-[#3e483c] hover:text-[#297d53] hover:bg-gray-50 transition-colors"
                  >
                    {t.chromePlating}
                  </Link>
                </li>
              </ul>
            </li>
            <li>
              <Link
                href={`${prefix}/cases`}
                className="text-[#3e483c] font-semibold hover:text-[#297d53] transition-colors"
              >
                {t.cases}
              </Link>
            </li>
            <li>
              <Link
                href={`${prefix}/blog`}
                className="text-[#3e483c] font-semibold hover:text-[#297d53] transition-colors"
              >
                {t.blog}
              </Link>
            </li>
            <li className="relative group">
              <LanguageSwitcher />
            </li>
          </ul>
        </nav>

        <div className="flex-1 flex justify-end">
          <Link
            href={`${prefix}/solicite-orcamento`}
            className="hidden md:block request-button rounded-xl hover:shadow-md transition-all duration-300"
          >
            {t.quote}
          </Link>
          <button className="md:hidden" onClick={toggleMenu}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden absolute top-20 left-0 right-0 bg-white shadow-lg z-50 rounded-b-xl overflow-hidden">
          <ul className="flex flex-col p-4">
            <li className="py-2 border-b">
              <Link href={`${prefix}/`} className="text-[#3e483c] font-semibold" onClick={() => setIsMenuOpen(false)}>
                {t.home}
              </Link>
            </li>
            <li className="py-2 border-b">
              <Link
                href={`${prefix}/quem-somos`}
                className="text-[#3e483c] font-semibold"
                onClick={() => setIsMenuOpen(false)}
              >
                {t.about}
              </Link>
            </li>
            <li className="py-2 border-b">
              <Link
                href={`${prefix}/solucoes`}
                className="text-[#3e483c] font-semibold"
                onClick={() => setIsMenuOpen(false)}
              >
                {t.solutions}
              </Link>
            </li>
            <li className="py-2 border-b">
              <Link
                href={`${prefix}/cases`}
                className="text-[#3e483c] font-semibold"
                onClick={() => setIsMenuOpen(false)}
              >
                {t.cases}
              </Link>
            </li>
            <li className="py-2 border-b">
              <Link
                href={`${prefix}/blog`}
                className="text-[#3e483c] font-semibold"
                onClick={() => setIsMenuOpen(false)}
              >
                {t.blog}
              </Link>
            </li>
            <li className="py-2 border-b">
              <LanguageSwitcher />
            </li>
            <li className="py-2">
              <Link
                href={`${prefix}/solicite-orcamento`}
                className="request-button inline-block rounded-xl hover:shadow-md transition-all duration-300"
                onClick={() => setIsMenuOpen(false)}
              >
                {t.quote}
              </Link>
            </li>
          </ul>
        </div>
      )}
    </header>
  )
}

export default Header
