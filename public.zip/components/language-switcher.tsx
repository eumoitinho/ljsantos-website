"use client"

import type React from "react"

import { useState } from "react"
import { usePathname, useRouter } from "next/navigation"

interface Language {
  code: string
  name: string
  icon: React.ReactNode
  path: string
}

const LanguageSwitcher = () => {
  const [isOpen, setIsOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()

  // Ícones de bandeiras
  const BrazilFlag = () => (
    <div className="w-5 h-4 relative overflow-hidden rounded-sm">
      <div className="absolute inset-0 bg-[#009c3b]"></div>
      <div className="absolute inset-[15%] transform rotate-45">
        <div className="absolute inset-0 bg-[#ffdf00]"></div>
      </div>
      <div className="absolute inset-[30%] rounded-full bg-[#002776]"></div>
    </div>
  )

  const USAFlag = () => (
    <div className="w-5 h-4 relative overflow-hidden rounded-sm">
      <div className="absolute inset-0 bg-white"></div>
      <div className="absolute inset-0 flex flex-col justify-between">
        <div className="h-[8%] bg-[#b22234]"></div>
        <div className="h-[8%] bg-[#b22234]"></div>
        <div className="h-[8%] bg-[#b22234]"></div>
        <div className="h-[8%] bg-[#b22234]"></div>
        <div className="h-[8%] bg-[#b22234]"></div>
        <div className="h-[8%] bg-[#b22234]"></div>
        <div className="h-[8%] bg-[#b22234]"></div>
      </div>
      <div className="absolute top-0 left-0 w-[40%] h-[53%] bg-[#3c3b6e]"></div>
    </div>
  )

  const SpainFlag = () => (
    <div className="w-5 h-4 relative overflow-hidden rounded-sm">
      <div className="absolute inset-0 flex flex-col">
        <div className="h-1/4 bg-[#c60b1e]"></div>
        <div className="h-2/4 bg-[#ffc400]"></div>
        <div className="h-1/4 bg-[#c60b1e]"></div>
      </div>
    </div>
  )

  const languages: Language[] = [
    { code: "pt-BR", name: "Português", icon: <BrazilFlag />, path: "" },
    { code: "en", name: "English", icon: <USAFlag />, path: "/en" },
    { code: "es", name: "Español", icon: <SpainFlag />, path: "/es" },
  ]

  // Determine current language based on pathname
  const getCurrentLanguage = (): Language => {
    if (pathname.startsWith("/en")) {
      return languages[1]
    } else if (pathname.startsWith("/es")) {
      return languages[2]
    }
    return languages[0]
  }

  const currentLanguage = getCurrentLanguage()

  // Get equivalent page in other language
  const getEquivalentPath = (langPath: string): string => {
    // Remove current language prefix if any
    let path = pathname
    if (pathname.startsWith("/en")) {
      path = pathname.substring(3) // Remove /en
    } else if (pathname.startsWith("/es")) {
      path = pathname.substring(3) // Remove /es
    }

    // If path is empty or just "/", it means we're at the root
    if (path === "" || path === "/") {
      return langPath === "" ? "/" : langPath
    }

    // Combine new language path with current path
    return `${langPath}${path}`
  }

  const handleLanguageChange = (lang: Language) => {
    setIsOpen(false)
    const newPath = getEquivalentPath(lang.path)
    router.push(newPath)
  }

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1 text-[#3e483c] font-semibold hover:text-[#448b13] transition-colors"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <span className="mr-1">{currentLanguage.icon}</span>
        <span className="hidden md:inline">{currentLanguage.name}</span>
        <svg
          className="w-4 h-4 ml-1 transition-transform duration-200"
          style={{ transform: isOpen ? "rotate(180deg)" : "rotate(0)" }}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
        </svg>
      </button>

      {isOpen && (
        <ul className="absolute right-0 mt-2 bg-white shadow-lg rounded-xl py-2 w-36 z-10 overflow-hidden transition-all duration-200 ease-in-out">
          {languages.map((lang) => (
            <li key={lang.code} className="hover:bg-gray-50 transition-colors">
              <button
                onClick={() => handleLanguageChange(lang)}
                className="flex items-center w-full px-4 py-2 text-left text-[#3e483c] hover:text-[#448b13]"
              >
                <span className="mr-2">{lang.icon}</span>
                {lang.name}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

export default LanguageSwitcher
