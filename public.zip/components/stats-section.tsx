"use client"

import { useState, useEffect } from "react"
import ScrollAnimation from "@/components/scroll-animation"

const stats = [
  { value: 25, suffix: "+", label: "ANOS DE EXPERIÊNCIA" },
  { value: 60, suffix: "+", label: "ETE'S INSTALADAS" },
  { value: 1000, suffix: "+", label: "TANQUES INSTALADOS" },
]

const StatsSection = () => {
  const [counters, setCounters] = useState(stats.map(() => 0))
  const [hasAnimated, setHasAnimated] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById("stats-section")
      if (element && !hasAnimated) {
        const position = element.getBoundingClientRect()

        // If the element is in the viewport and hasn't animated yet
        if (position.top < window.innerHeight && position.bottom >= 0) {
          setHasAnimated(true)

          stats.forEach((stat, index) => {
            const duration = 2000 // 2 seconds
            const steps = 50
            const stepValue = stat.value / steps
            let currentStep = 0

            const interval = setInterval(() => {
              if (currentStep < steps) {
                setCounters((prev) => {
                  const newCounters = [...prev]
                  newCounters[index] = Math.round(stepValue * currentStep)
                  return newCounters
                })
                currentStep++
              } else {
                setCounters((prev) => {
                  const newCounters = [...prev]
                  newCounters[index] = stat.value
                  return newCounters
                })
                clearInterval(interval)
              }
            }, duration / steps)
          })
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    handleScroll() // Check on initial load

    return () => {
      window.removeEventListener("scroll", handleScroll)
    }
  }, [hasAnimated])

  return (
    <section id="stats-section" className="relative py-24">
      <video className="stats-video" autoPlay muted loop playsInline>
        <source src="/videos/map-background.mp4" type="video/mp4" />
      </video>
      <div className="stats-overlay"></div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-12">
          <ScrollAnimation animation="animate-fadeInUp">
            <span className="text-white text-sm uppercase tracking-wider">BIG NUMBERS</span>
            <h2 className="text-3xl md:text-4xl font-bold text-white mt-2">Números que fazem diferença</h2>
          </ScrollAnimation>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <ScrollAnimation key={index} animation="animate-zoomIn" delay={`animate-delay-${index * 100}`}>
              <div className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-white mb-2">
                  {counters[index]}
                  {stat.suffix}
                </div>
                <div className="text-white text-sm uppercase tracking-wider">{stat.label}</div>
              </div>
            </ScrollAnimation>
          ))}
        </div>
      </div>
    </section>
  )
}

export default StatsSection
